function bind(id, evento, handler){
  const el = document.getElementById(id);

  if (!el){
    console.warn(`[Elegance] No existe el elemento con id="${id}" en el HTML.`);
    return null;
  }

  el.addEventListener(evento, handler);
  return el;
}

function mostrarErrorEnPagina(mensaje){
  const cont = document.getElementById('catalogo') || document.body;

  const aviso = document.createElement('div');

  aviso.style.cssText =
    'background:#fff3f3;border:2px solid #A6274C;color:#7C1B38;padding:20px;border-radius:14px;margin:20px auto;max-width:700px;font-family:sans-serif;line-height:1.6';

  aviso.innerHTML =
    `<strong>No se pudo cargar el catalogo.</strong><br>${mensaje}`;

  cont.appendChild(aviso);
}

window.addEventListener('error', e => {
  console.error('[Elegance] Error de JavaScript:', e.message);
});


/* ============================================================
   JOYERÍA ELEGANCE — script.js
   Catálogo + carrito + WhatsApp + animaciones
   PHP + MySQL
   ============================================================ */

const RUTA_IMG = 'img/';


/* ============================================================
   DATOS LOCALES DE RESPALDO
   ============================================================ */

const PRODUCTS_LOCAL = [

  // ===== COLLARES =====

  {
    id:1,
    cat:'collares',
    name:'Collar Solara',
    price:129,
    images:[
      RUTA_IMG+'collarsalara2.jpg',
      RUTA_IMG+'collar.jpg',
      RUTA_IMG+'collarsalara1.jpg'
    ],
    variants:[
      {
        title:'Collar Solara',
        medida:'Cadena 45 cm + extensión 5 cm',
        material:'Bañado en oro / zirconias',
        colors:['blanco','rojo']
      },
      {
        title:'Collar Solara (Variante)',
        medida:'Dije 1.2 cm',
        material:'Bañado en oro rosa / zirconias',
        colors:['blanco']
      },
      {
        title:'Collar Solara (Variante)',
        medida:'Cadena 50 cm',
        material:'Plata 925 / zirconias',
        colors:['gris','blanco']
      }
    ]
  },

  {
    id:5,
    cat:'collares',
    name:'Collar Luna Llena',
    price:119,
    images:[
      RUTA_IMG+'collarlunallena1.jpg',
      RUTA_IMG+'collarlunallena2.jpg',
      RUTA_IMG+'collarlunallena3.jpg'
    ],
    variants:[
      {
        title:'Collar Luna Llena',
        medida:'Cadena 40 cm',
        material:'Plata 925 / nácar',
        colors:['gris','blanco']
      },
      {
        title:'Collar Luna Llena (Variante)',
        medida:'Cadena 42 cm',
        material:'Bañado en oro / nácar',
        colors:['blanco']
      },
      {
        title:'Collar Luna Llena (Variante)',
        medida:'Cadena 45 cm',
        material:'Acero dorado / nácar rosado',
        colors:['blanco','rojo']
      }
    ]
  },

  {
    id:9,
    cat:'collares',
    name:'Collar Cometa',
    price:115,
    images:[
      RUTA_IMG+'cometa1.jpg',
      RUTA_IMG+'cometa2.jpg',
      RUTA_IMG+'cometa3.jpg'
    ],
    variants:[
      {
        title:'Collar Cometa',
        medida:'Cadena 48 cm',
        material:'Bañado en oro / dije circonia',
        colors:['blanco']
      },
      {
        title:'Collar Cometa (Variante)',
        medida:'Cadena 46 cm',
        material:'Plata 925 / dije circonia azul',
        colors:['gris','azul']
      },
      {
        title:'Collar Cometa (Variante)',
        medida:'Cadena 50 cm',
        material:'Baño oro rosa / dije circonia rosa',
        colors:['rojo']
      }
    ]
  },

  {
    id:13,
    cat:'collares',
    name:'Collar Perla del Mar',
    price:149,
    images:[
      RUTA_IMG+'perla1.jpg',
      RUTA_IMG+'perla2.jpg',
      RUTA_IMG+'perla3.jpg'
    ],
    variants:[
      {
        title:'Collar Perla del Mar',
        medida:'Cadena 42 cm',
        material:'Plata 925 / perla cultivada',
        colors:['gris','blanco']
      },
      {
        title:'Collar Perla del Mar (Variante)',
        medida:'Cadena 44 cm',
        material:'Bañado en oro / perla cultivada',
        colors:['blanco']
      },
      {
        title:'Collar Perla del Mar (Variante)',
        medida:'Cadena 40 cm',
        material:'Baño oro rosa / perla barroca',
        colors:['rojo','blanco']
      }
    ]
  },

  {
    id:17,
    cat:'collares',
    name:'Collar Corazón Eterno',
    price:135,
    images:[
      RUTA_IMG+'coraeterno1.jpg',
      RUTA_IMG+'coraeterno2.jpg',
      RUTA_IMG+'coraeterno3.jpg'
    ],
    variants:[
      {
        title:'Collar Corazón Eterno',
        medida:'Cadena 43 cm + dije 1.5 cm',
        material:'Bañado en oro / circonia corazón',
        colors:['blanco','rojo']
      },
      {
        title:'Collar Corazón Eterno (Variante)',
        medida:'Cadena 45 cm',
        material:'Plata 925 / circonia corazón',
        colors:['gris','blanco']
      },
      {
        title:'Collar Corazón Eterno (Variante)',
        medida:'Cadena 41 cm',
        material:'Baño oro rosa / circonia corazón rosa',
        colors:['rojo']
      }
    ]
  },


  // ===== ARETES =====

  {
    id:2,
    cat:'aretes',
    name:'Aretes Nébula',
    price:79,
    images:[
      RUTA_IMG+'aretesnebula1.jpg',
      RUTA_IMG+'aretesnebula2.jpg',
      RUTA_IMG+'aretesnebula3.jpg'
    ],
    variants:[
      {
        title:'Aretes Nébula',
        medida:'4.5 cm',
        material:'Plata 925 / ópalos sintéticos',
        colors:['azul','blanco']
      },
      {
        title:'Aretes Nébula (Variante)',
        medida:'',
        material:'Acero inoxidable / cristal arcoíris',
        colors:['gris','azul','rojo']
      },
      {
        title:'Aretes Nébula (Variante)',
        medida:'',
        material:'Baño oro rosa / resina efecto cielo',
        colors:['blanco','azul']
      }
    ]
  },

  {
    id:6,
    cat:'aretes',
    name:'Aretes Estrella Fugaz',
    price:69,
    images:[
      RUTA_IMG+'fugaz1.jpg',
      RUTA_IMG+'fugaz2.jpg',
      RUTA_IMG+'fugaz3.jpg'
    ],
    variants:[
      {
        title:'Aretes Estrella Fugaz',
        medida:'3.8 cm',
        material:'Bañado en oro / circonias',
        colors:['blanco']
      },
      {
        title:'Aretes Estrella Fugaz (Variante)',
        medida:'3.2 cm',
        material:'Plata 925 / circonias',
        colors:['gris','blanco']
      },
      {
        title:'Aretes Estrella Fugaz (Variante)',
        medida:'4 cm',
        material:'Acero inoxidable / cristal azul',
        colors:['azul']
      }
    ]
  },

  {
    id:10,
    cat:'aretes',
    name:'Aretes Galaxia',
    price:75,
    images:[
      RUTA_IMG+'galaxia1.jpg',
      RUTA_IMG+'galaxia2.jpg',
      RUTA_IMG+'galaxia3.jpg'
    ],
    variants:[
      {
        title:'Aretes Galaxia',
        medida:'5 cm colgantes',
        material:'Plata 925 / cristal morado',
        colors:['gris','azul']
      },
      {
        title:'Aretes Galaxia (Variante)',
        medida:'4.5 cm',
        material:'Bañado en oro / cristal azul',
        colors:['blanco','azul']
      },
      {
        title:'Aretes Galaxia (Variante)',
        medida:'5.5 cm',
        material:'Acero inoxidable / cristal multicolor',
        colors:['gris','rojo','azul']
      }
    ]
  },

  {
    id:14,
    cat:'aretes',
    name:'Aretes Gota de Cristal',
    price:65,
    images:[
      RUTA_IMG+'gota1.jpg',
      RUTA_IMG+'gota2.jpg',
      RUTA_IMG+'gota3.jpg'
    ],
    variants:[
      {
        title:'Aretes Gota de Cristal',
        medida:'3.5 cm',
        material:'Bañado en oro / cristal transparente',
        colors:['blanco']
      },
      {
        title:'Aretes Gota de Cristal (Variante)',
        medida:'3 cm',
        material:'Plata 925 / cristal transparente',
        colors:['gris','blanco']
      },
      {
        title:'Aretes Gota de Cristal (Variante)',
        medida:'3.8 cm',
        material:'Acero dorado / cristal rosado',
        colors:['blanco','rojo']
      }
    ]
  },

  {
    id:18,
    cat:'aretes',
    name:'Aretes Aro Dorado',
    price:59,
    images:[
      RUTA_IMG+'aro1.jpg',
      RUTA_IMG+'aro2.jpg',
      RUTA_IMG+'aro3.jpg'
    ],
    variants:[
      {
        title:'Aretes Aro Dorado',
        medida:'Diámetro 2.5 cm',
        material:'Bañado en oro 18k',
        colors:['blanco']
      },
      {
        title:'Aretes Aro Dorado (Variante)',
        medida:'Diámetro 3.5 cm',
        material:'Bañado en oro 18k',
        colors:['blanco']
      },
      {
        title:'Aretes Aro Dorado (Variante)',
        medida:'Diámetro 2 cm',
        material:'Plata 925',
        colors:['gris']
      }
    ]
  },


  // ===== ANILLOS =====

  {
    id:3,
    cat:'anillos',
    name:'Anillo Aurora',
    price:99,
    images:[
      RUTA_IMG+'anillo1.jpg',
      RUTA_IMG+'anillo2.jpg',
      RUTA_IMG+'anillo3.jpg'
    ],
    variants:[
      {
        title:'Anillo Aurora',
        medida:'Ajustable talla 6-8',
        material:'Bañado en oro 18k / circonia central',
        colors:['blanco']
      },
      {
        title:'Anillo Aurora (Variante)',
        medida:'Talla 7 fija',
        material:'Plata 925 / circonia azul',
        colors:['gris','azul']
      },
      {
        title:'Anillo Aurora (Variante)',
        medida:'Ajustable',
        material:'Baño oro rosa / circonia rosa',
        colors:['blanco','rojo']
      }
    ]
  },

  {
    id:7,
    cat:'anillos',
    name:'Anillo Eclipse',
    price:109,
    images:[
      RUTA_IMG+'eclipse1.jpg',
      RUTA_IMG+'eclipse2.jpg',
      RUTA_IMG+'eclipse3.jpg'
    ],
    variants:[
      {
        title:'Anillo Eclipse',
        medida:'Talla 6',
        material:'Plata 925 / ónix negro',
        colors:['gris']
      },
      {
        title:'Anillo Eclipse (Variante)',
        medida:'Talla 7',
        material:'Bañado en oro / ónix negro',
        colors:['gris','blanco']
      },
      {
        title:'Anillo Eclipse (Variante)',
        medida:'Ajustable',
        material:'Baño oro rosa / madreperla',
        colors:['blanco']
      }
    ]
  },

  {
    id:11,
    cat:'anillos',
    name:'Anillo Zafiro Real',
    price:179,
    images:[
      RUTA_IMG+'zafiro1.jpg',
      RUTA_IMG+'zafiro2.jpg',
      RUTA_IMG+'zafiro3.jpg'
    ],
    variants:[
      {
        title:'Anillo Zafiro Real',
        medida:'Talla 6',
        material:'Bañado en oro blanco / zafiro sintético',
        colors:['blanco','azul']
      },
      {
        title:'Anillo Zafiro Real (Variante)',
        medida:'Talla 7',
        material:'Plata 925 / zafiro sintético',
        colors:['gris','azul']
      },
      {
        title:'Anillo Zafiro Real (Variante)',
        medida:'Ajustable',
        material:'Bañado en oro amarillo / zafiro sintético',
        colors:['blanco','azul']
      }
    ]
  },

  {
    id:15,
    cat:'anillos',
    name:'Anillo Trinity',
    price:159,
    images:[
      RUTA_IMG+'trinity1.jpg',
      RUTA_IMG+'trinity2.jpg',
      RUTA_IMG+'trinity3.jpg'
    ],
    variants:[
      {
        title:'Anillo Trinity',
        medida:'Talla 6',
        material:'Tres tonos: oro, oro rosa y plata',
        colors:['blanco','rojo','gris']
      },
      {
        title:'Anillo Trinity (Variante)',
        medida:'Talla 7',
        material:'Tres tonos: oro, oro rosa y plata',
        colors:['blanco','rojo','gris']
      },
      {
        title:'Anillo Trinity (Variante)',
        medida:'Ajustable',
        material:'Baño oro 18k liso',
        colors:['blanco']
      }
    ]
  },

  {
    id:19,
    cat:'anillos',
    name:'Anillo Flor de Loto',
    price:95,
    images:[
      RUTA_IMG+'loto1.jpg',
      RUTA_IMG+'loto2.jpg',
      RUTA_IMG+'loto3.jpg'
    ],
    variants:[
      {
        title:'Anillo Flor de Loto',
        medida:'Talla 6',
        material:'Plata 925 / esmalte blanco',
        colors:['gris','blanco']
      },
      {
        title:'Anillo Flor de Loto (Variante)',
        medida:'Talla 7',
        material:'Bañado en oro / esmalte blanco',
        colors:['blanco']
      },
      {
        title:'Anillo Flor de Loto (Variante)',
        medida:'Ajustable',
        material:'Baño oro rosa / esmalte rosa',
        colors:['rojo']
      }
    ]
  },


  // ===== PULSERAS =====

  {
    id:4,
    cat:'pulseras',
    name:'Pulsera Celeste',
    price:89,
    images:[
      RUTA_IMG+'pulsera1.jpg',
      RUTA_IMG+'pulsera2.jpg',
      RUTA_IMG+'pulsera3.jpg'
    ],
    variants:[
      {
        title:'Pulsera Celeste',
        medida:'18 cm + extensión 3 cm',
        material:'Plata 925 / dije luna',
        colors:['gris','blanco']
      },
      {
        title:'Pulsera Celeste (Variante)',
        medida:'19 cm',
        material:'Bañada en oro / dije estrella',
        colors:['blanco']
      },
      {
        title:'Pulsera Celeste (Variante)',
        medida:'17 cm ajustable',
        material:'Baño oro rosa / dije sol',
        colors:['rojo']
      }
    ]
  },

  {
    id:8,
    cat:'pulseras',
    name:'Pulsera Constelación',
    price:99,
    images:[
      RUTA_IMG+'constelacion1.jpg',
      RUTA_IMG+'constelacion2.jpg',
      RUTA_IMG+'constelacion3.jpg'
    ],
    variants:[
      {
        title:'Pulsera Constelación',
        medida:'17 cm + extensión 4 cm',
        material:'Plata 925 / puntos de circonia',
        colors:['gris','blanco']
      },
      {
        title:'Pulsera Constelación (Variante)',
        medida:'18 cm',
        material:'Bañada en oro / puntos de circonia',
        colors:['blanco']
      },
      {
        title:'Pulsera Constelación (Variante)',
        medida:'16 cm ajustable',
        material:'Acero dorado / cristal multicolor',
        colors:['rojo','azul','gris']
      }
    ]
  },

  {
    id:12,
    cat:'pulseras',
    name:'Pulsera Infinito',
    price:85,
    images:[
      RUTA_IMG+'infinito1.jpg',
      RUTA_IMG+'infinito2.jpg',
      RUTA_IMG+'infinito3.jpg'
    ],
    variants:[
      {
        title:'Pulsera Infinito',
        medida:'17 cm',
        material:'Plata 925 / dije infinito',
        colors:['gris']
      },
      {
        title:'Pulsera Infinito (Variante)',
        medida:'18 cm',
        material:'Bañada en oro / dije infinito',
        colors:['blanco']
      },
      {
        title:'Pulsera Infinito (Variante)',
        medida:'16.5 cm',
        material:'Baño oro rosa / dije infinito',
        colors:['rojo']
      }
    ]
  },

  {
    id:16,
    cat:'pulseras',
    name:'Pulsera Tenis Brillante',
    price:169,
    images:[
      RUTA_IMG+'tenis1.jpg',
      RUTA_IMG+'tenis2.jpg',
      RUTA_IMG+'tenis3.jpg'
    ],
    variants:[
      {
        title:'Pulsera Tenis Brillante',
        medida:'18 cm',
        material:'Plata 925 / circonias en línea',
        colors:['gris','blanco']
      },
      {
        title:'Pulsera Tenis Brillante (Variante)',
        medida:'19 cm',
        material:'Bañada en oro / circonias en línea',
        colors:['blanco']
      },
      {
        title:'Pulsera Tenis Brillante (Variante)',
        medida:'17.5 cm',
        material:'Baño oro blanco / circonias en línea',
        colors:['blanco']
      }
    ]
  },

  {
    id:20,
    cat:'pulseras',
    name:'Pulsera Dijes Charm',
    price:89,
    images:[
      RUTA_IMG+'charm1.jpg',
      RUTA_IMG+'charm2.jpg',
      RUTA_IMG+'charm3.jpg'
    ],
    variants:[
      {
        title:'Pulsera Dijes Charm',
        medida:'19 cm + extensión 3 cm',
        material:'Plata 925 / dijes variados',
        colors:['gris','blanco','rojo']
      },
      {
        title:'Pulsera Dijes Charm (Variante)',
        medida:'18 cm',
        material:'Bañada en oro / dijes variados',
        colors:['blanco']
      },
      {
        title:'Pulsera Dijes Charm (Variante)',
        medida:'20 cm',
        material:'Acero dorado / dijes multicolor',
        colors:['rojo','azul','gris']
      }
    ]
  }
];


let PRODUCTS = [];


const CATEGORIAS = [
  {
    key:'collares',
    label:'Collares',
    eyebrow:'Cadenas & dijes'
  },
  {
    key:'aretes',
    label:'Aretes',
    eyebrow:'Para cada look'
  },
  {
    key:'anillos',
    label:'Anillos',
    eyebrow:'El detalle final'
  },
  {
    key:'pulseras',
    label:'Pulseras',
    eyebrow:'Para el día a día'
  }
];


/* ============================================================
   CARGAR PRODUCTOS DESDE MYSQL
   ============================================================ */

async function cargarCatalogoDesdeApi(){

  const respuesta = await fetch('api/productos.php');

  if (!respuesta.ok){
    throw new Error('La API no pudo cargar los productos.');
  }

  PRODUCTS = await respuesta.json();

  console.log(
    '[Elegance] Productos recibidos desde MySQL:',
    PRODUCTS
  );

  renderCatalogo();

  console.log(
    `[Elegance] Catálogo cargado desde MySQL: ${PRODUCTS.length} productos.`
  );
}


/* ============================================================
   WHATSAPP
   ============================================================ */

const NUMERO_WHATSAPP = '51966376986';


/* ============================================================
   MONEDA Y TIPO DE CAMBIO
   ============================================================ */

const EXCHANGE_API =
  'https://open.er-api.com/v6/latest/PEN';

const MONEDAS = [

  {
    code:'PEN',
    symbol:'S/',
    label:'Peru - Sol (S/)',
    fallback:1
  },

  {
    code:'USD',
    symbol:'US$',
    label:'Estados Unidos - Dolar (US$)',
    fallback:0.27
  },

  {
    code:'EUR',
    symbol:'€',
    label:'Europa - Euro (€)',
    fallback:0.25
  },

  {
    code:'MXN',
    symbol:'MX$',
    label:'Mexico - Peso (MX$)',
    fallback:4.90
  },

  {
    code:'COP',
    symbol:'COL$',
    label:'Colombia - Peso (COL$)',
    fallback:1080
  },

  {
    code:'CLP',
    symbol:'CLP$',
    label:'Chile - Peso (CLP$)',
    fallback:255
  },

  {
    code:'ARS',
    symbol:'AR$',
    label:'Argentina - Peso (AR$)',
    fallback:290
  },

  {
    code:'BRL',
    symbol:'R$',
    label:'Brasil - Real (R$)',
    fallback:1.45
  },

  {
    code:'BOB',
    symbol:'Bs',
    label:'Bolivia - Boliviano (Bs)',
    fallback:1.85
  },

  {
    code:'ECU',
    symbol:'US$',
    label:'Ecuador - Dolar (US$)',
    fallback:0.27,
    aliasDe:'USD'
  }

];


let currentCurrency = 'PEN';

let rates = {};

let rateIsLive = false;


MONEDAS.forEach(m => {
  rates[m.code] = m.fallback;
});


function monedaActual(){

  return MONEDAS.find(
    m => m.code === currentCurrency
  ) || MONEDAS[0];

}


function currencySymbol(){

  return monedaActual().symbol;

}


function tasaActual(){

  const m = monedaActual();

  const code = m.aliasDe || m.code;

  return rates[code] != null
    ? rates[code]
    : m.fallback;

}


function convertPrice(penAmount){

  return penAmount * tasaActual();

}


function formatPrecio(penAmount){

  return `${currencySymbol()} ${montoFormateado(penAmount)}`;

}


const MONEDAS_SIN_DECIMALES = [
  'CLP',
  'COP',
  'ARS'
];


function montoFormateado(penAmount){

  const valor = convertPrice(penAmount);

  if (
    MONEDAS_SIN_DECIMALES.includes(
      currentCurrency
    )
  ){

    return Math.round(valor)
      .toLocaleString('es-PE');

  }

  return valor.toLocaleString(
    'es-PE',
    {
      minimumFractionDigits:2,
      maximumFractionDigits:2
    }
  );

}


function poblarSelectorMoneda(){

  const select =
    document.getElementById('currencySelect');

  if (!select) return;

  select.innerHTML =
    MONEDAS.map(m =>

      `<option value="${m.code}"
        ${m.code === currentCurrency ? 'selected' : ''}>
        ${m.label}
      </option>`

    ).join('');

}


async function fetchExchangeRate(){

  try{

    const res =
      await fetch(EXCHANGE_API);

    const data =
      await res.json();

    if (
      data &&
      data.result === 'success' &&
      data.rates
    ){

      MONEDAS.forEach(m => {

        const code =
          m.aliasDe || m.code;

        if (
          data.rates[code] != null
        ){

          rates[code] =
            data.rates[code];

        }

      });

      rates['PEN'] = 1;

      rateIsLive = true;

    }

  }catch(e){

    rateIsLive = false;

  }

  updateRateBadge();

  refreshCardPrices();

  renderCart();

}


function updateRateBadge(){

  const badge =
    document.getElementById('monedaBadge');

  if (!badge) return;

  if (currentCurrency === 'PEN'){

    badge.textContent =
      rateIsLive
        ? 'Precios en soles peruanos - tipo de cambio actualizado'
        : 'Precios en soles peruanos';

    return;
  }

  const tasa = tasaActual();

  const porUnidad =
    (1 / tasa);

  const texto =
    porUnidad >= 1
      ? porUnidad.toFixed(2)
      : porUnidad.toFixed(4);

  badge.textContent =
    rateIsLive
      ? `Tipo de cambio actual: 1 ${currencySymbol().trim()} = S/ ${texto}`
      : `Tipo de cambio aproximado: 1 ${currencySymbol().trim()} = S/ ${texto}`;

}


function refreshCardPrices(){

  document
    .querySelectorAll('.price-row[data-price-pen]')
    .forEach(row => {

      const pen =
        parseFloat(
          row.dataset.pricePen
        );

      row.querySelector(
        '.price-currency'
      ).textContent =
        currencySymbol();

      row.querySelector(
        '.price-amount'
      ).textContent =
        montoFormateado(pen);

    });

}


function setCurrency(currency){

  if (
    currency === currentCurrency
  ) return;

  currentCurrency = currency;

  refreshCardPrices();

  renderCart();

  updateRateBadge();

  renderPedidos();

}


/* ============================================================
   CARRITO
   ============================================================ */

/*
  IMPORTANTE:

  Cada producto del carrito tiene:

  {
    id: producto_id,
    variante_id: variante_id,
    qty: cantidad
  }

  Esto permite que PHP sepa exactamente
  qué variante se está comprando.
*/

let cart = [];


function getProduct(id){

  return PRODUCTS.find(
    p => Number(p.id) === Number(id)
  );

}


/* ============================================================
   AGREGAR AL CARRITO
   ============================================================ */

function addToCart(
  id,
  qty,
  varianteId
){

  qty =
    Number(qty) || 1;

  varianteId =
    Number(varianteId) || 0;


  /*
    Si no existe variante_id,
    NO agregamos el producto.

    Esto evita volver a enviar:
    {id:5, qty:1}

    y obliga a enviar:
    {id:5, variante_id:123, qty:1}
  */

  if (!varianteId){

    console.error(
      '[Elegance] ERROR: No se recibió variante_id.'
    );

    alert(
      'No se pudo identificar la variante del producto. Recarga la página e inténtalo nuevamente.'
    );

    return;
  }


  const producto =
    getProduct(id);


  if (!producto){

    console.error(
      '[Elegance] Producto no encontrado:',
      id
    );

    return;
  }


  const variante =
    producto.variants?.find(
      v =>
        Number(v.id) ===
        Number(varianteId)
    );


  if (!variante){

    console.error(
      '[Elegance] Variante no encontrada:',
      varianteId,
      producto
    );

    alert(
      'No se pudo identificar la variante seleccionada.'
    );

    return;
  }


  const existing =
    cart.find(
      item =>
        Number(item.id) === Number(id) &&
        Number(item.variante_id) ===
        Number(varianteId)
    );


  if (existing){

    existing.qty += qty;

  }else{

    cart.push({

      id:Number(id),

      variante_id:Number(varianteId),

      qty:qty

    });

  }


  console.log(
    '[Elegance] Carrito:',
    cart
  );


  renderCart();

  openCart();

}


/* ============================================================
   ELIMINAR DEL CARRITO
   ============================================================ */

function removeFromCart(
  id,
  varianteId
){

  cart =
    cart.filter(
      item =>
        !(
          Number(item.id) === Number(id) &&
          Number(item.variante_id) ===
          Number(varianteId)
        )
    );

  renderCart();

}


/* ============================================================
   CAMBIAR CANTIDAD
   ============================================================ */

function changeCartQty(
  id,
  varianteId,
  delta
){

  const item =
    cart.find(
      item =>
        Number(item.id) === Number(id) &&
        Number(item.variante_id) ===
        Number(varianteId)
    );


  if (!item) return;


  item.qty += delta;


  if (item.qty <= 0){

    removeFromCart(
      id,
      varianteId
    );

  }else{

    renderCart();

  }

}


/* ============================================================
   VACIAR CARRITO
   ============================================================ */

function clearCart(){

  cart = [];

  renderCart();

}


/* ============================================================
   TOTAL DEL CARRITO
   ============================================================ */

function cartTotal(){

  return cart.reduce(
    (sum, item) => {

      const p =
        getProduct(item.id);

      if (!p) return sum;


      const v =
        p.variants?.find(
          variante =>
            Number(variante.id) ===
            Number(item.variante_id)
        );


      if (!v) return sum;


      return sum +
        (
          Number(v.price) *
          Number(item.qty)
        );

    },
    0
  );

}


/* ============================================================
   CANTIDAD TOTAL DE PRODUCTOS
   ============================================================ */

function cartCount(){

  return cart.reduce(
    (sum, item) =>
      sum + Number(item.qty || 0),
    0
  );

}


/* ============================================================
   RENDER DEL CARRITO
   ============================================================ */

function renderCart(){

  const itemsEl =
    document.getElementById('cartItems');

  const totalEl =
    document.getElementById('cartTotal');

  const countEl =
    document.getElementById('cartCount');

  const checkoutBtn =
    document.getElementById('cartCheckout');


  if (
    !itemsEl ||
    !totalEl ||
    !countEl ||
    !checkoutBtn
  ){

    return;
  }


  countEl.textContent =
    cartCount();


  /* ---------- CARRITO VACÍO ---------- */

  if (cart.length === 0){

    itemsEl.innerHTML =
      '<p class="cart-empty">Tu joyero está vacío por ahora. Explora el catálogo y añade tus piezas favoritas ✧</p>';

    totalEl.textContent =
      formatPrecio(0);

    checkoutBtn.disabled =
      true;

    return;
  }


  checkoutBtn.disabled =
    false;


  /* ---------- PRODUCTOS DEL CARRITO ---------- */

  itemsEl.innerHTML =
    cart.map(item => {

      const p =
        getProduct(item.id);


      if (!p) return '';


      const v =
        p.variants?.find(
          variante =>
            Number(variante.id) ===
            Number(item.variante_id)
        );


      if (!v){

        console.warn(
          '[Elegance] No se encontró la variante del carrito:',
          item
        );

        return '';

      }


      const imagen =
        p.images?.[0] || '';


      return `

        <div class="cart-item">

          <img
            src="${imagen}"
            alt="${p.name}"
          >

          <div class="cart-item-info">

            <h5>
              ${p.name}
            </h5>

            <div>
              ${v.title}
            </div>

            <div class="cart-item-price">
              ${formatPrecio(v.price)} c/u
            </div>

            <div class="cart-item-qty">

              <button
                onclick="changeCartQty(${p.id}, ${v.id}, -1)"
              >
                −
              </button>

              <span>
                ${item.qty}
              </span>

              <button
                onclick="changeCartQty(${p.id}, ${v.id}, 1)"
              >
                +
              </button>

              <button
                class="cart-item-remove"
                onclick="removeFromCart(${p.id}, ${v.id})"
              >
                Eliminar
              </button>

            </div>

          </div>

        </div>

      `;

    }).join('');


  totalEl.textContent =
    formatPrecio(cartTotal());

}


/* ============================================================
   ABRIR CARRITO
   ============================================================ */

function openCart(){

  const drawer =
    document.getElementById('cartDrawer');

  const overlay =
    document.getElementById('cartOverlay');


  if (!drawer || !overlay) return;


  drawer.classList.add('open');

  overlay.classList.add('open');

  drawer.setAttribute(
    'aria-hidden',
    'false'
  );

}


/* ============================================================
   CERRAR CARRITO
   ============================================================ */

function closeCart(){

  const drawer =
    document.getElementById('cartDrawer');

  const overlay =
    document.getElementById('cartOverlay');


  if (!drawer || !overlay) return;


  drawer.classList.remove('open');

  overlay.classList.remove('open');

  drawer.setAttribute(
    'aria-hidden',
    'true'
  );

}


/* ============================================================
   ENVIAR CARRITO A PHP
   ============================================================ */

function checkoutWhatsApp(){

  if (!cart.length){

    console.warn(
      '[Elegance] No hay productos en el carrito.'
    );

    return;
  }


  /*
    ESTE CONSOLE.LOG ES IMPORTANTE
    PARA COMPROBAR EL VARIANTE_ID.
  */

  console.log(
    '[Elegance] Enviando carrito:',
    cart
  );


  /*
    Verificación antes de enviar.
  */

  const carritoInvalido =
    cart.some(
      item =>
        !item.id ||
        !item.variante_id ||
        !item.qty
    );


  if (carritoInvalido){

    console.error(
      '[Elegance] El carrito tiene productos sin variante_id:',
      cart
    );

    alert(
      'Uno de los productos no tiene una variante identificada. Recarga la página e inténtalo nuevamente.'
    );

    return;
  }


  const form =
    document.createElement('form');

  form.method =
    'POST';

  form.action =
    'checkout/checkout.php';


  const input =
    document.createElement('input');

  input.type =
    'hidden';

  input.name =
    'carrito';

  input.value =
    JSON.stringify(cart);


  form.appendChild(input);

  document.body.appendChild(form);

  form.submit();

}


/* ============================================================
   PEDIDOS
   ============================================================ */

let contadorPedidos = 0;

let pedidos = [];


function registrarPedido(){

  contadorPedidos++;


  const ahora =
    new Date();


  const pedido = {

    codigo:
      `PED-${String(ahora.getFullYear()).slice(2)}${String(ahora.getMonth()+1).padStart(2,'0')}-${String(contadorPedidos).padStart(3,'0')}`,

    fecha:
      ahora,

    estado:
      'Enviado por WhatsApp',

    totalPen:
      cartTotal(),

    items:
      cart.map(item => {

        const p =
          getProduct(item.id);

        const v =
          p?.variants?.find(
            variante =>
              Number(variante.id) ===
              Number(item.variante_id)
          );


        return {

          id:
            p?.id || item.id,

          variante_id:
            item.variante_id,

          nombre:
            p?.name || '',

          variante:
            v?.title || '',

          qty:
            item.qty,

          precioPen:
            v?.price || 0

        };

      })

  };


  pedidos.unshift(
    pedido
  );


  renderPedidos();


  return pedido;

}


/* ============================================================
   MOSTRAR PEDIDOS
   ============================================================ */

function renderPedidos(){

  const cont =
    document.getElementById('pedidosList');

  const navBadge =
    document.getElementById('navPedidosCount');


  if (!cont) return;


  if (navBadge){

    navBadge.textContent =
      pedidos.length;

    navBadge.hidden =
      pedidos.length === 0;

  }


  if (pedidos.length === 0){

    cont.innerHTML =
      '<p class="pedidos-empty">Todavía no has enviado ningún pedido. Cuando finalices una compra desde el carrito, aparecerá aquí. ✧</p>';

    return;

  }


  cont.innerHTML =
    pedidos.map(
      (ped, idx) => `

      <div class="pedido-card">

        <div class="pedido-head">

          <span class="pedido-codigo">
            ${ped.codigo}
          </span>

          <span class="pedido-fecha">
            ${ped.fecha.toLocaleDateString('es-PE')}
            ·
            ${ped.fecha.toLocaleTimeString(
              'es-PE',
              {
                hour:'2-digit',
                minute:'2-digit'
              }
            )}
          </span>

          <span class="pedido-estado">
            ${ped.estado}
          </span>

        </div>


        ${ped.items.map(
          it => `

          <div class="pedido-linea">

            <span>
              ${it.nombre}

              ${it.variante
                ? ` - ${it.variante}`
                : ''
              }

              × ${it.qty}
            </span>

            <span>
              ${formatPrecio(
                it.precioPen * it.qty
              )}
            </span>

          </div>

        `).join('')}


        <div class="pedido-total">

          <span>
            Total
          </span>

          <span>
            ${formatPrecio(
              ped.totalPen
            )}
          </span>

        </div>


        <div class="pedido-actions">

          <button
            class="pedido-btn"
            onclick="repetirPedido(${idx})"
          >
            Volver a pedir
          </button>

          <button
            class="pedido-btn ghost"
            onclick="consultarPedido(${idx})"
          >
            Consultar estado
          </button>

        </div>

      </div>

    `
    ).join('');

}


/* ============================================================
   REPETIR PEDIDO
   ============================================================ */

function repetirPedido(idx){

  const ped =
    pedidos[idx];


  if (!ped) return;


  ped.items.forEach(it => {

    /*
      Los pedidos antiguos que no tengan
      variante_id no se vuelven a agregar,
      porque necesitamos una variante real.
    */

    if (!it.variante_id){

      console.warn(
        '[Elegance] Pedido antiguo sin variante_id:',
        it
      );

      return;
    }


    const existente =
      cart.find(
        c =>
          Number(c.id) === Number(it.id) &&
          Number(c.variante_id) ===
          Number(it.variante_id)
      );


    if (existente){

      existente.qty +=
        Number(it.qty);

    }else{

      cart.push({

        id:
          Number(it.id),

        variante_id:
          Number(it.variante_id),

        qty:
          Number(it.qty)

      });

    }

  });


  console.log(
    '[Elegance] Carrito después de repetir pedido:',
    cart
  );


  renderCart();

  openCart();

}


/* ============================================================
   CONSULTAR PEDIDO
   ============================================================ */

function consultarPedido(idx){

  const ped =
    pedidos[idx];


  if (!ped) return;


  const mensaje =
    encodeURIComponent(
      `Hola, quisiera consultar el estado de mi pedido ${ped.codigo}.`
    );


  window.open(
    `https://wa.me/${NUMERO_WHATSAPP}?text=${mensaje}`,
    '_blank'
  );

}


/* ============================================================
   RENDER DEL CATÁLOGO
   ============================================================ */

const WHATSAPP_ICON = `

<svg
  viewBox="0 0 24 24"
  xmlns="http://www.w3.org/2000/svg"
>
  <path
    d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347"
  ></path>
</svg>

`;


function colorDots(colors){

  return colors.map(
    c =>
      `<div class="color-dot color-${c}" title="${c}"></div>`
  ).join('');

}


/* ============================================================
   CREAR TARJETA DE PRODUCTO
   ============================================================ */

function buildCard(p){

  const imgsHtml =
    p.images.map(
      src => `

      <div class="card-carousel-item">

        <img
          loading="lazy"
          src="${src}"
          alt="${p.name}"
        >

      </div>

    `
    ).join('');


  const dotsHtml =
    p.images.map(
      (_, i) =>

      `<span class="card-carousel-dot ${i === 0 ? 'active' : ''}"></span>`

    ).join('');


  const infoHtml =
    p.variants.map(
      (v, i) => `

      <div class="card-info-item ${i === 0 ? 'active' : ''}">

        <h4>
          ${v.title}
        </h4>

        ${
          v.medida
            ? `<p class="meta">Medidas: ${v.medida}</p>`
            : ''
        }

        <p class="meta">
          Material: ${v.material}
        </p>

        <div class="colors">

          <span class="label">
            Colores:
          </span>

          ${colorDots(v.colors)}

        </div>

      </div>

    `
    ).join('');


  return `

    <div
      class="card"
      data-id="${p.id}"
    >

      <div class="card-carousel">

        <div class="card-carousel-inner">

          ${imgsHtml}

        </div>


        <button
          class="card-carousel-btn prev"
          aria-label="Anterior"
        >
          ‹
        </button>


        <button
          class="card-carousel-btn next"
          aria-label="Siguiente"
        >
          ›
        </button>


        <div class="card-carousel-dots">

          ${dotsHtml}

        </div>

      </div>


      <div class="info">

        ${infoHtml}


        <div
          class="price-row"
          data-price-pen="${p.price}"
        >

          <span class="price-currency">
            ${currencySymbol()}
          </span>

          <span class="price-amount">
            ${montoFormateado(p.price)}
          </span>

        </div>


        <div class="qty-row">

          <button
            class="qty-minus"
            aria-label="Reducir cantidad"
          >
            −
          </button>

          <span class="qty-value">
            1
          </span>

          <button
            class="qty-plus"
            aria-label="Aumentar cantidad"
          >
            +
          </button>

        </div>

      </div>


      <div class="card-actions">

        <button class="btn-add">
          Agregar al carrito
        </button>

        <button
          class="btn-whatsapp btn-consultar"
        >

          ${WHATSAPP_ICON}

          Consultar

        </button>

      </div>

    </div>

  `;

}


/* ============================================================
   MOSTRAR CATÁLOGO
   ============================================================ */

function renderCatalogo(){

  const cont =
    document.getElementById('catalogo');


  if (!cont){

    console.error(
      '[Elegance] No existe #catalogo.'
    );

    return;
  }


  cont.innerHTML =
    CATEGORIAS.map(
      cat => {

        const items =
          PRODUCTS.filter(
            p =>
              p.cat === cat.key
          );


        return `

          <div
            class="categoria"
            id="${cat.key}"
          >

            <div class="categoria-head">

              <span class="cat-eyebrow">
                ${cat.eyebrow}
              </span>

              <h3>
                ${cat.label}
              </h3>

              <span class="cat-count">
                ${items.length} piezas
              </span>

            </div>


            <div class="grid">

              ${items.map(buildCard).join('')}

            </div>

          </div>

        `;

      }
    ).join('');


  attachCardEvents();

}


/* ============================================================
   INTERACCIÓN DE TARJETAS
   ============================================================ */

function attachCardEvents(){

  document
    .querySelectorAll('.card')
    .forEach(card => {

      const id =
        parseInt(
          card.dataset.id,
          10
        );


      const p =
        getProduct(id);


      if (!p) return;


      const qtyValue =
        card.querySelector(
          '.qty-value'
        );


      /* ---------- CANTIDAD + ---------- */

      card
        .querySelector('.qty-plus')
        .addEventListener(
          'click',
          () => {

            qtyValue.textContent =
              parseInt(
                qtyValue.textContent,
                10
              ) + 1;

          }
        );


      /* ---------- CANTIDAD - ---------- */

      card
        .querySelector('.qty-minus')
        .addEventListener(
          'click',
          () => {

            const v =
              parseInt(
                qtyValue.textContent,
                10
              );


            if (v > 1){

              qtyValue.textContent =
                v - 1;

            }

          }
        );


      /* ======================================================
         AGREGAR AL CARRITO
         ====================================================== */

      card
        .querySelector('.btn-add')
        .addEventListener(
          'click',
          () => {

            const activeIdx =

              [
                ...card.querySelectorAll(
                  '.card-info-item'
                )
              ]

              .findIndex(
                el =>
                  el.classList.contains(
                    'active'
                  )
              );


            const variant =
              p.variants[
                activeIdx >= 0
                  ? activeIdx
                  : 0
              ];


            /*
              MUY IMPORTANTE:

              Aquí enviamos:

              id
              cantidad
              variante.id

              La variante viene directamente
              desde MySQL.
            */

            console.log(
              '[Elegance] Agregando producto:',
              {
                id:id,
                variante_id:variant.id,
                qty:parseInt(
                  qtyValue.textContent,
                  10
                )
              }
            );


            addToCart(

              id,

              parseInt(
                qtyValue.textContent,
                10
              ),

              variant.id

            );


            qtyValue.textContent =
              '1';

          }
        );


      /* ======================================================
         CONSULTAR POR WHATSAPP
         ====================================================== */

      card
        .querySelector('.btn-consultar')
        .addEventListener(
          'click',
          () => {

            const activeIdx =

              [
                ...card.querySelectorAll(
                  '.card-info-item'
                )
              ]

              .findIndex(
                el =>
                  el.classList.contains(
                    'active'
                  )
              );


            const variant =
              p.variants[
                activeIdx >= 0
                  ? activeIdx
                  : 0
              ];


            const mensaje =
              encodeURIComponent(

                `Hola, estoy interesado en: ${variant.title}` +

                `${
                  variant.medida
                    ? ' - ' + variant.medida
                    : ''
                }. ` +

                `¿Podrías darme más información?`

              );


            window.open(
              `https://wa.me/${NUMERO_WHATSAPP}?text=${mensaje}`,
              '_blank'
            );

          }
        );


      /* ======================================================
         CARRUSEL
         ====================================================== */

      card
        .querySelector(
          '.card-carousel-btn.prev'
        )
        .addEventListener(
          'click',
          () =>
            changeCardSlide(
              card,
              -1
            )
        );


      card
        .querySelector(
          '.card-carousel-btn.next'
        )
        .addEventListener(
          'click',
          () =>
            changeCardSlide(
              card,
              1
            )
        );


      card
        .querySelectorAll(
          '.card-carousel-dot'
        )
        .forEach(
          (dot, idx) => {

            dot.addEventListener(
              'click',
              () =>
                goToCardSlide(
                  card,
                  idx
                )
            );

          }
        );


      startCardAutoPlay(card);


      card.addEventListener(
        'mouseenter',
        () =>
          stopCardAutoPlay(card)
      );


      card.addEventListener(
        'mouseleave',
        () =>
          startCardAutoPlay(card)
      );

    });

}


/* ============================================================
   CARRUSEL DE TARJETAS
   ============================================================ */

function getCardIndex(card){

  const dots =
    card.querySelectorAll(
      '.card-carousel-dot'
    );


  let idx = 0;


  dots.forEach(
    (d, i) => {

      if (
        d.classList.contains(
          'active'
        )
      ){

        idx = i;

      }

    }
  );


  return idx;

}


function setCardSlide(
  card,
  index
){

  const inner =
    card.querySelector(
      '.card-carousel-inner'
    );


  const items =
    card.querySelectorAll(
      '.card-carousel-item'
    );


  const dots =
    card.querySelectorAll(
      '.card-carousel-dot'
    );


  const infoItems =
    card.querySelectorAll(
      '.card-info-item'
    );


  const total =
    items.length;


  if (!total) return;


  if (index >= total)
    index = 0;


  if (index < 0)
    index = total - 1;


  inner.style.transform =
    `translateX(${-index * 100}%)`;


  dots.forEach(
    (d, i) =>
      d.classList.toggle(
        'active',
        i === index
      )
  );


  infoItems.forEach(
    (el, i) =>
      el.classList.toggle(
        'active',
        i === index
      )
  );

}


function changeCardSlide(
  card,
  direction
){

  setCardSlide(
    card,
    getCardIndex(card) +
      direction
  );

}


function goToCardSlide(
  card,
  index
){

  setCardSlide(
    card,
    index
  );

}


const cardIntervals =
  new Map();


function startCardAutoPlay(card){

  const items =
    card.querySelectorAll(
      '.card-carousel-item'
    );


  if (
    items.length > 1 &&
    !cardIntervals.has(card)
  ){

    const interval =
      setInterval(
        () =>
          changeCardSlide(
            card,
            1
          ),
        4200
      );


    cardIntervals.set(
      card,
      interval
    );

  }

}


function stopCardAutoPlay(card){

  if (
    cardIntervals.has(card)
  ){

    clearInterval(
      cardIntervals.get(card)
    );


    cardIntervals.delete(card);

  }

}


/* ============================================================
   CARRUSEL PRINCIPAL
   ============================================================ */

let currentSlide = 0;

let autoSlideInterval;


function showSlide(index){

  const slides =
    document.querySelectorAll(
      '.carousel-item'
    );


  const indicators =
    document.querySelectorAll(
      '.indicator'
    );


  const total =
    slides.length;


  if (!total) return;


  if (index >= total)
    currentSlide = 0;

  else if (index < 0)
    currentSlide = total - 1;

  else
    currentSlide = index;


  const inner =
    document.querySelector(
      '.carousel-inner'
    );


  if (!inner) return;


  inner.style.transform =
    `translateX(${-currentSlide * 100}%)`;


  indicators.forEach(
    (ind, i) =>
      ind.classList.toggle(
        'active',
        i === currentSlide
      )
  );

}


function nextSlide(){

  showSlide(
    currentSlide + 1
  );

  resetAutoSlide();

}


function previousSlide(){

  showSlide(
    currentSlide - 1
  );

  resetAutoSlide();

}


function goToSlide(index){

  showSlide(index);

  resetAutoSlide();

}


function startAutoSlide(){

  clearInterval(
    autoSlideInterval
  );


  autoSlideInterval =
    setInterval(
      () =>
        showSlide(
          currentSlide + 1
        ),
      5000
    );

}


function resetAutoSlide(){

  clearInterval(
    autoSlideInterval
  );

  startAutoSlide();

}


/* ============================================================
   BOTÓN VOLVER AL INICIO
   ============================================================ */

function irAlInicio(){

  const target =
    document.querySelector(
      '#inicio'
    );


  if (!target) return;


  const nav =
    document.querySelector(
      'nav'
    );


  const navHeight =
    nav ? nav.offsetHeight : 0;


  const targetPosition =
    target.getBoundingClientRect().top +
    window.pageYOffset -
    navHeight;


  window.scrollTo({

    top:
      targetPosition,

    behavior:
      'smooth'

  });

}


/* ============================================================
   LLUVIA DE CORAZONES Y FLORES
   ============================================================ */

function crearLluviaDePiezas(
  cantidad
){

  const contenedor =
    document.getElementById(
      'lluviaContainer'
    );


  if (!contenedor) return;


  const formas = [

    `<svg viewBox="0 0 32 29" width="34" height="31">
      <path
        fill="currentColor"
        d="M16 28.5S1 19.6 1 9.9C1 4.9 4.9 1 9.7 1c2.8 0 5.4 1.4 6.3 3.6C17 2.4 19.6 1 22.4 1 27.2 1 31 4.9 31 9.9c0 9.7-15 18.6-15 18.6z"
      />
    </svg>`,

    `<svg viewBox="0 0 40 40" width="34" height="34">
      <g fill="currentColor">
        <circle cx="20" cy="10" r="7"/>
        <circle cx="30" cy="20" r="7"/>
        <circle cx="20" cy="30" r="7"/>
        <circle cx="10" cy="20" r="7"/>
        <circle
          cx="20"
          cy="20"
          r="5"
          fill="#fff"
          opacity=".5"
        />
      </g>
    </svg>`

  ];


  const colores = [
    '#D9A97A',
    '#A6274C',
    '#F3D9E4',
    '#C9A227'
  ];


  for (
    let i = 0;
    i < cantidad;
    i++
  ){

    const pieza =
      document.createElement(
        'div'
      );


    pieza.className =
      'pieza-flotante';


    pieza.style.left =
      Math.random() * 100 +
      '%';


    pieza.style.color =
      colores[
        Math.floor(
          Math.random() *
          colores.length
        )
      ];


    pieza.innerHTML =
      formas[
        Math.floor(
          Math.random() *
          formas.length
        )
      ];


    const escala =
      (
        Math.random() *
        0.9 +
        0.7
      ).toFixed(2);


    pieza.style.transform =
      `scale(${escala})`;


    const duracion =
      (
        Math.random() *
        8 +
        14
      ).toFixed(2);


    const retraso =
      (
        Math.random() *
        18
      ).toFixed(2);


    pieza.style.animationDuration =
      duracion + 's';


    pieza.style.animationDelay =
      retraso + 's';


    contenedor.appendChild(
      pieza
    );

  }

}


/* ============================================================
   POP-UP DE BIENVENIDA
   ============================================================ */

const PROMO_CODIGO =
  'ELEGANCE10';


let promoYaMostrado =
  false;


function abrirPromo(){

  const overlay =
    document.getElementById(
      'promoOverlay'
    );


  const modal =
    document.getElementById(
      'promoModal'
    );


  if (!overlay || !modal)
    return;


  overlay.classList.add(
    'open'
  );


  modal.classList.add(
    'open'
  );


  modal.setAttribute(
    'aria-hidden',
    'false'
  );

}


function cerrarPromo(){

  const overlay =
    document.getElementById(
      'promoOverlay'
    );


  const modal =
    document.getElementById(
      'promoModal'
    );


  if (!overlay || !modal)
    return;


  overlay.classList.remove(
    'open'
  );


  modal.classList.remove(
    'open'
  );


  modal.setAttribute(
    'aria-hidden',
    'true'
  );

}


function initPromo(){

  setTimeout(
    () => {

      if (!promoYaMostrado){

        promoYaMostrado =
          true;

        abrirPromo();

      }

    },
    6000
  );


  bind(
    'promoClose',
    'click',
    cerrarPromo
  );


  bind(
    'promoLater',
    'click',
    cerrarPromo
  );


  bind(
    'promoOverlay',
    'click',
    cerrarPromo
  );


  bind(
    'promoCta',
    'click',
    () => {

      const mensaje =
        encodeURIComponent(
          `Hola, quiero usar el codigo de descuento ${PROMO_CODIGO} en mi primera compra.`
        );


      window.open(
        `https://wa.me/${NUMERO_WHATSAPP}?text=${mensaje}`,
        '_blank'
      );


      cerrarPromo();

    }
  );


  document.addEventListener(
    'keydown',
    e => {

      if (
        e.key === 'Escape'
      ){

        cerrarPromo();

      }

    }
  );

}


/* ============================================================
   AVISOS DE PRUEBA SOCIAL
   ============================================================ */

const CIUDADES = [
  'Arequipa',
  'Lima',
  'Cusco',
  'Trujillo',
  'Piura',
  'Tacna',
  'Chiclayo',
  'Huancayo',
  'Ica',
  'Puno'
];


const NOMBRES = [
  'María',
  'Lucía',
  'Camila',
  'Valeria',
  'Andrea',
  'Fernanda',
  'Gabriela',
  'Daniela',
  'Rosa',
  'Carmen',
  'Paola',
  'Ximena'
];


let toastTimer =
  null;


let toastesMostrados =
  0;


function mostrarToastSocial(){

  const toast =
    document.getElementById(
      'socialToast'
    );


  if (!toast) return;


  if (!PRODUCTS.length)
    return;


  const producto =
    PRODUCTS[
      Math.floor(
        Math.random() *
        PRODUCTS.length
      )
    ];


  const nombre =
    NOMBRES[
      Math.floor(
        Math.random() *
        NOMBRES.length
      )
    ];


  const ciudad =
    CIUDADES[
      Math.floor(
        Math.random() *
        CIUDADES.length
      )
    ];


  const minutos =
    Math.floor(
      Math.random() * 25
    ) + 2;


  const title =
    document.getElementById(
      'socialToastTitle'
    );


  const msg =
    document.getElementById(
      'socialToastMsg'
    );


  if (title)
    title.textContent =
      `${nombre} de ${ciudad}`;


  if (msg)
    msg.textContent =
      `compro ${producto.name} hace ${minutos} minutos`;


  toast.classList.add(
    'show'
  );


  toast.setAttribute(
    'aria-hidden',
    'false'
  );


  clearTimeout(
    toastTimer
  );


  toastTimer =
    setTimeout(
      ocultarToastSocial,
      6000
    );


  toastesMostrados++;

}


function ocultarToastSocial(){

  const toast =
    document.getElementById(
      'socialToast'
    );


  if (!toast) return;


  toast.classList.remove(
    'show'
  );


  toast.setAttribute(
    'aria-hidden',
    'true'
  );

}


function initToastSocial(){

  bind(
    'socialToastClose',
    'click',
    () => {

      ocultarToastSocial();

      toastesMostrados =
        99;

    }
  );


  setTimeout(
    () => {

      mostrarToastSocial();


      const intervalo =
        setInterval(
          () => {

            if (
              toastesMostrados >= 6
            ){

              clearInterval(
                intervalo
              );

              return;
            }


            mostrarToastSocial();

          },
          22000
        );

    },
    14000
  );

}


/* ============================================================
   ASISTENTE VIRTUAL
   ============================================================ */

const FAQ = [
  

  {
    claves:[
      'envio',
      'envios',
      'enviar',
      'envian',
      'delivery',
      'llega',
      'llegada',
      'demora',
      'demoran',
      'tarda',
      'reparto',
      'provincia',
      'shipping'
    ],

    respuesta:
      'Hacemos envios a todo el Peru. En Arequipa llega en 24 a 48 horas y a provincias entre 3 y 5 dias habiles. El envio es GRATIS en compras mayores a S/ 300.'
  },


  {
    claves:[
      'pago',
      'pagar',
      'pagos',
      'yape',
      'plin',
      'tarjeta',
      'transferencia',
      'efectivo',
      'deposito'
    ],

    respuesta:
      'Aceptamos Yape, Plin, transferencia bancaria, tarjeta de credito/debito y efectivo contra entrega en Arequipa. El pago se coordina por WhatsApp al confirmar tu pedido.'
  },


  {
    claves:[
      'precio',
      'precios',
      'cuesta',
      'cuanto',
      'vale',
      'costo',
      'moneda',
      'dolar',
      'soles'
    ],

    respuesta:
      'Todos los precios estan en el catalogo, desde S/ 59 hasta S/ 179. Puedes cambiar la moneda con el selector que esta arriba, en la cabecera, para ver los precios en dolares, euros y otras monedas.'
  },


  {
    claves:[
      'material',
      'materiales',
      'plata',
      'oro',
      '925',
      '18k',
      'alergia',
      'alergica',
      'oxida',
      'ennegrece'
    ],

    respuesta:
      'Trabajamos plata 925, piezas banadas en oro 18k, oro rosa y acero inoxidable. La plata 925 y el acero son hipoalergenicos, ideales si tienes piel sensible.'
  },


  {
    claves:[
      'talla',
      'tallas',
      'medida',
      'medidas',
      'tamano',
      'largo',
      'ajustable',
      'anillo',
      'anillos',
      'cadena'
    ],

    respuesta:
      'Nuestros anillos vienen en tallas 6, 7 y tambien en version ajustable. Las medidas exactas de cada pieza aparecen en su tarjeta del catalogo, junto al material.'
  },


  {
    claves:[
      'garantia',
      'cambio',
      'cambios',
      'devolucion',
      'devolver',
      'roto',
      'defecto'
    ],

    respuesta:
      'Todas las piezas tienen 3 meses de garantia por defectos de fabricacion. Aceptamos cambios dentro de los 7 dias siguientes a la entrega, siempre que la pieza este sin uso y con su empaque.'
  },


  {
    claves:[
      'cuidado',
      'cuidar',
      'limpiar',
      'limpieza',
      'limpio',
      'limpia',
      'mantener',
      'conservar',
      'guardar',
      'oxida',
      'opaca',
      'brillo'
    ],

    respuesta:
      'Guarda tus piezas en un lugar seco y evita el contacto con perfumes, cremas y cloro. Limpialas con un pano suave y seco despues de usarlas: asi el bano de oro dura mucho mas.'
  },


  {
    claves:[
      'horario',
      'abren',
      'cierran',
      'tienda',
      'local',
      'direccion',
      'ubicacion',
      'donde'
    ],

    respuesta:
      'Atendemos de lunes a sabado de 10:00 a 20:00 y domingos de 11:00 a 17:00. Nuestra tienda fisica esta en Arequipa; escribenos por WhatsApp y te pasamos la ubicacion exacta.'
  },


  {
    claves:[
      'descuento',
      'promocion',
      'oferta',
      'cupon',
      'codigo',
      'rebaja'
    ],

    respuesta:
      'Tenemos 10% de descuento en tu primera compra con el codigo ELEGANCE10. Ademas, el envio es gratis desde S/ 300.'
  },


  {
    claves:[
      'pedido',
      'pedidos',
      'orden',
      'comprar',
      'carrito',
      'estado',
      'seguimiento'
    ],

    respuesta:
      'Puedes agregar piezas al carrito y el pedido por WhatsApp. Todos tus pedidos de esta visita quedan guardados en la seccion "Mis pedidos", donde puedes repetirlos o consultar su estado.'
  },


  {
    claves:[
      'regalo',
      'envolver',
      'empaque',
      'caja',
      'sorpresa',
      'cumpleanos',
      'aniversario'
    ],

    respuesta:
      'Todas las piezas se entregan en caja de regalo sin costo adicional. Si quieres, agregamos una tarjeta con tu mensaje personalizado: solo avisanos al confirmar el pedido.'
  },


  {
    claves:[
      'hola',
      'buenas',
      'buenos dias',
      'buenas tardes',
      'buenas noches',
      'hey',
      'saludos'
    ],

    respuesta:
      'Hola! Soy el asistente de Joyeria Elegance. Puedo ayudarte con envios, formas de pago, materiales, tallas, garantia y mas. Que necesitas saber?'
  },


  {
    claves:[
      'gracias',
      'muchas gracias',
      'thanks',
      'ok',
      'listo',
      'perfecto'
    ],

    respuesta:
      'Con mucho gusto! Si necesitas algo mas, aqui estoy. Y si prefieres hablar con una persona, escribenos por WhatsApp.'
  }

];
let FAQ_DB = [];
async function cargarFAQDesdeBD() {

  try {

    const respuesta = await fetch(
      'api/preguntas_frecuentes.php'
    );

    const datos =
      await respuesta.json();

    if (
      Array.isArray(datos)
    ) {

      FAQ_DB = datos;

      console.log(
        'Preguntas cargadas desde MySQL:',
        FAQ_DB
      );

    }

  } catch (error) {

    console.error(
      'Error al cargar las preguntas frecuentes:',
      error
    );

  }

}
cargarFAQDesdeBD();

const RESPUESTA_POR_DEFECTO =
  'Esa consulta prefiero pasarsela a nuestro equipo para darte una respuesta exacta. Escribenos por WhatsApp y te atendemos al toque. Mientras tanto, puedo ayudarte con envios, pagos, materiales, tallas, garantia o cuidados.';


const SUGERENCIAS = [
  'Como son los envios?',
  'Que formas de pago tienen?',
  'De que material son?',
  'Tienen garantia?',
  'Hablar por WhatsApp'
];


function normalizar(texto){

  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(
      /[\u0300-\u036f]/g,
      ''
    )
    .replace(
      /[^a-z0-9\s]/g,
      ' '
    );

}


function buscarRespuesta(pregunta) {

  const texto = normalizar(pregunta);

  let mejor = null;
  let mejorPuntaje = 0;

  // Primero buscamos en las preguntas que vienen de MySQL
  FAQ_DB.forEach(item => {

    const preguntaBD = normalizar(item.pregunta);

    let puntaje = 0;

    // Convertimos la pregunta de la BD en palabras
    const palabras = preguntaBD.split(/\s+/);

    palabras.forEach(palabra => {

      if (
        palabra.length > 2 &&
        texto.includes(palabra)
      ) {
        puntaje++;
      }

    });

    if (puntaje > mejorPuntaje) {

      mejorPuntaje = puntaje;
      mejor = item;

    }

  });


  // Si encontramos una coincidencia en MySQL
  if (mejor) {

    return mejor.respuesta;

  }


  // Si no encontramos coincidencia en MySQL,
  // por ahora seguimos usando las preguntas antiguas
  FAQ.forEach(item => {

    let puntaje = 0;

    item.claves.forEach(clave => {

      if (
        texto.includes(
          normalizar(clave)
        )
      ) {

        puntaje++;

      }

    });


    if (puntaje > mejorPuntaje) {

      mejorPuntaje = puntaje;
      mejor = item;

    }

  });


  return mejor
    ? mejor.respuesta
    : RESPUESTA_POR_DEFECTO;

}


function agregarMensaje(
  texto,
  tipo
){

  const cont =
    document.getElementById(
      'chatMessages'
    );


  if (!cont) return null;


  const div =
    document.createElement(
      'div'
    );


  div.className =
    `chat-msg ${tipo}`;


  div.textContent =
    texto;


  cont.appendChild(
    div
  );


  cont.scrollTop =
    cont.scrollHeight;


  return div;

}


function mostrarEscribiendo(){

  const cont =
    document.getElementById(
      'chatMessages'
    );


  if (!cont) return null;


  const div =
    document.createElement(
      'div'
    );


  div.className =
    'chat-msg bot typing';


  div.innerHTML =
    '<i></i><i></i><i></i>';


  cont.appendChild(
    div
  );


  cont.scrollTop =
    cont.scrollHeight;


  return div;

}


function responderBot(
  pregunta
){

  const escribiendo =
    mostrarEscribiendo();


  if (!escribiendo) return;


  setTimeout(
    () => {

      escribiendo.remove();

      agregarMensaje(
        buscarRespuesta(
          pregunta
        ),
        'bot'
      );

    },
    700
  );

}


function enviarPreguntaChat(
  texto
){

  if (!texto.trim())
    return;


  if (
    normalizar(texto)
      .includes('whatsapp')
  ){

    agregarMensaje(
      texto,
      'user'
    );


    const escribiendo =
      mostrarEscribiendo();


    if (!escribiendo) return;


    setTimeout(
      () => {

        escribiendo.remove();


        agregarMensaje(
          'Te abro WhatsApp para que hables directo con nuestro equipo.',
          'bot'
        );


        window.open(
          `https://wa.me/${NUMERO_WHATSAPP}?text=${encodeURIComponent('Hola, vengo desde la web y quisiera mas informacion.')}`,
          '_blank'
        );

      },
      700
    );


    return;
  }


  agregarMensaje(
    texto,
    'user'
  );


  responderBot(
    texto
  );

}


function renderSugerencias(){

  const cont =
    document.getElementById(
      'chatQuick'
    );


  if (!cont) return;


  cont.innerHTML =
    SUGERENCIAS
      .map(
        s =>
          `<button type="button">${s}</button>`
      )
      .join('');


  cont
    .querySelectorAll(
      'button'
    )
    .forEach(
      btn => {

        btn.addEventListener(
          'click',
          () =>
            enviarPreguntaChat(
              btn.textContent
            )
        );

      }
    );

}


function abrirChat(){

  const win =
    document.getElementById(
      'chatWindow'
    );


  if (!win) return;


  win.classList.add(
    'open'
  );


  win.setAttribute(
    'aria-hidden',
    'false'
  );


  const dot =
    document.getElementById(
      'chatDot'
    );


  if (dot)
    dot.classList.add(
      'hidden'
    );


  const cont =
    document.getElementById(
      'chatMessages'
    );


  if (
    cont &&
    !cont.children.length
  ){

    setTimeout(
      () => {

        agregarMensaje(
          'Hola! Soy el asistente virtual de Joyeria Elegance. ✧',
          'bot'
        );


        setTimeout(
          () => {

            agregarMensaje(
              'Puedo responderte al instante sobre envios, pagos, materiales, tallas, garantia y cuidados. Elige una opcion o escribeme tu pregunta.',
              'bot'
            );

          },
          600
        );

      },
      250
    );

  }


  setTimeout(
    () => {

      const input =
        document.getElementById(
          'chatInput'
        );

      if (input)
        input.focus();

    },
    400
  );

}


function cerrarChat(){

  const win =
    document.getElementById(
      'chatWindow'
    );


  if (!win) return;


  win.classList.remove(
    'open'
  );


  win.setAttribute(
    'aria-hidden',
    'true'
  );

}


function initChat(){

  renderSugerencias();


  bind(
    'chatFab',
    'click',
    () => {

      const win =
        document.getElementById(
          'chatWindow'
        );


      if (!win) return;


      win.classList.contains(
        'open'
      )
        ? cerrarChat()
        : abrirChat();

    }
  );


  bind(
    'chatClose',
    'click',
    cerrarChat
  );


  const form =
    document.getElementById(
      'chatForm'
    );


  if (form){

    form.addEventListener(
      'submit',
      e => {

        e.preventDefault();


        const input =
          document.getElementById(
            'chatInput'
          );


        if (!input) return;


        enviarPreguntaChat(
          input.value
        );


        input.value =
          '';

      }
    );

  }

}


/* ============================================================
   BUSCADOR
   ============================================================ */

let textoBusqueda =
  '';


function normalizarBusqueda(
  texto
){

  return texto
    .toLowerCase()
    .normalize('NFD')
    .replace(
      /[\u0300-\u036f]/g,
      ''
    )
    .trim();

}


function coincideBusqueda(
  producto,
  categoriaLabel
){

  if (!textoBusqueda)
    return true;


  const termino =
    normalizarBusqueda(
      textoBusqueda
    );


  const materiales =
    producto.variants
      .map(
        v => v.material
      )
      .join(' ');


  const medidas =
    producto.variants
      .map(
        v => v.medida || ''
      )
      .join(' ');


  const campo =
    normalizarBusqueda(

      `${producto.name} ${materiales} ${medidas} ${categoriaLabel}`

    );


  return campo.includes(
    termino
  );

}


function aplicarBusqueda(){

  let totalVisible =
    0;


  document
    .querySelectorAll(
      '.categoria'
    )
    .forEach(
      seccionCat => {

        const catKey =
          seccionCat.id;


        const catInfo =
          CATEGORIAS.find(
            c =>
              c.key === catKey
          );


        let visiblesEnCategoria =
          0;


        seccionCat
          .querySelectorAll(
            '.card'
          )
          .forEach(
            card => {

              const id =
                parseInt(
                  card.dataset.id,
                  10
                );


              const producto =
                getProduct(id);


              const visible =
                producto &&
                coincideBusqueda(
                  producto,
                  catInfo
                    ? catInfo.label
                    : ''
                );


              card.classList.toggle(
                'oculta-busqueda',
                !visible
              );


              if (visible){

                visiblesEnCategoria++;

                totalVisible++;

              }

            }
          );


        seccionCat.classList.toggle(
          'sin-resultados',
          visiblesEnCategoria === 0
        );

      }
    );


  mostrarResultadoBusqueda(
    totalVisible
  );

}


function mostrarResultadoBusqueda(
  totalVisible
){

  const aviso =
    document.getElementById(
      'buscadorResultado'
    );


  const catalogo =
    document.getElementById(
      'catalogo'
    );


  const limpiarBtn =
    document.getElementById(
      'buscadorLimpiar'
    );


  if (!aviso || !catalogo)
    return;


  if (limpiarBtn){

    limpiarBtn.hidden =
      textoBusqueda.length === 0;

  }


  let vacioExistente =
    document.getElementById(
      'buscadorSinNada'
    );


  if (vacioExistente)
    vacioExistente.remove();


  if (!textoBusqueda){

    aviso.hidden =
      true;

    return;
  }


  aviso.hidden =
    false;


  if (
    totalVisible === 0
  ){

    aviso.innerHTML =
      `Sin resultados para "<strong>${textoBusqueda}</strong>"`;


    const vacio =
      document.createElement(
        'div'
      );


    vacio.id =
      'buscadorSinNada';


    vacio.className =
      'buscador-sin-nada';


    vacio.innerHTML =
      `<strong>No encontramos piezas con "${textoBusqueda}"</strong>Prueba con otro nombre, material (plata, oro) o categoria (collar, arete, anillo, pulsera).`;


    catalogo.appendChild(
      vacio
    );

  }else{

    aviso.innerHTML =
      `<strong>${totalVisible}</strong> pieza${totalVisible === 1 ? '' : 's'} encontrada${totalVisible === 1 ? '' : 's'} para "<strong>${textoBusqueda}</strong>"`;

  }

}


function initBuscador(){

  const input =
    document.getElementById(
      'buscadorInput'
    );


  const limpiarBtn =
    document.getElementById(
      'buscadorLimpiar'
    );


  if (!input) return;


  let temporizador =
    null;


  input.addEventListener(
    'input',
    e => {

      clearTimeout(
        temporizador
      );


      temporizador =
        setTimeout(
          () => {

            textoBusqueda =
              e.target.value.trim();


            aplicarBusqueda();

          },
          200
        );

    }
  );


  if (limpiarBtn){

    limpiarBtn.addEventListener(
      'click',
      () => {

        input.value =
          '';

        textoBusqueda =
          '';

        aplicarBusqueda();

        input.focus();

      }
    );

  }

}


/* ============================================================
   INICIALIZACIÓN
   ============================================================ */

document.addEventListener(
  'DOMContentLoaded',
  async () => {


    /* ---------- CATÁLOGO ---------- */

    const contenedor =
      document.getElementById(
        'catalogo'
      );


    if (!contenedor){

      mostrarErrorEnPagina(
        'Falta el contenedor del catalogo. Revisa que tu index.html tenga la linea: <div id="catalogo"></div> dentro de la seccion de productos.'
      );


      return;

    }


    try{

      await cargarCatalogoDesdeApi();


      console.log(
        `[Elegance] Catálogo cargado: ${PRODUCTS.length} productos en ${CATEGORIAS.length} categorías.`
      );

    }catch(err){

      console.error(
        err
      );


      mostrarErrorEnPagina(
        'Ocurrió un error al cargar los productos: ' +
        err.message
      );


      return;

    }


    /* ---------- INICIALIZAR RESTO ---------- */

    const pasos = [

      [
        'carrito',
        () =>
          renderCart()
      ],

      [
        'monedas',
        () => {

          poblarSelectorMoneda();

          updateRateBadge();

          fetchExchangeRate();

          bind(
            'currencySelect',
            'change',
            e =>
              setCurrency(
                e.target.value
              )
          );

        }
      ],

      [
        'carrusel',
        () =>
          startAutoSlide()
      ],

      [
        'corazones',
        () =>
          crearLluviaDePiezas(
            18
          )
      ],

      [
        'mis pedidos',
        () =>
          renderPedidos()
      ],

      [
        'pop-up promo',
        () =>
          initPromo()
      ],

      [
        'avisos sociales',
        () =>
          initToastSocial()
      ],

      [
        'asistente',
        () =>
          initChat()
      ],

      [
        'buscador',
        () =>
          initBuscador()
      ]

    ];


    pasos.forEach(
      ([nombre, fn]) => {

        try{

          fn();

        }catch(err){

          console.warn(
            `[Elegance] No se pudo iniciar "${nombre}":`,
            err.message
          );

        }

      }
    );


    /* ========================================================
       NAVEGACIÓN
       ======================================================== */

    document
      .querySelectorAll(
        'nav a'
      )
      .forEach(
        anchor => {

          anchor.addEventListener(
            'click',
            function(e){

              e.preventDefault();


              const href =
                this.getAttribute(
                  'href'
                );


              if (!href) return;


              const target =
                document.querySelector(
                  href
                );


              if (target){

                const nav =
                  document.querySelector(
                    'nav'
                  );


                const navHeight =
                  nav
                    ? nav.offsetHeight
                    : 0;


                const targetPosition =
                  target.getBoundingClientRect().top +
                  window.pageYOffset -
                  navHeight;


                window.scrollTo({

                  top:
                    targetPosition,

                  behavior:
                    'smooth'

                });

              }

            }
          );

        }
      );


    /* ========================================================
       BOTÓN VOLVER ARRIBA
       ======================================================== */

    window.addEventListener(
      'scroll',
      () => {

        const btnInicio =
          document.getElementById(
            'btnInicio'
          );


        if (!btnInicio)
          return;


        if (
          window.pageYOffset > 300
        ){

          btnInicio.classList.add(
            'visible'
          );

        }else{

          btnInicio.classList.remove(
            'visible'
          );

        }

      }
    );


    /* ========================================================
       BOTONES DEL CARRITO
       ======================================================== */

    bind(
      'cartFab',
      'click',
      openCart
    );


    bind(
      'cartClose',
      'click',
      closeCart
    );


    bind(
      'cartOverlay',
      'click',
      closeCart
    );


    bind(
      'cartClear',
      'click',
      clearCart
    );


    bind(
      'cartCheckout',
      'click',
      checkoutWhatsApp
    );


    console.log(
      '[Elegance] script.js inicializado correctamente.'
    );

  }
);