<?php

require_once __DIR__ . '/../includes/sesion.php';
require_once __DIR__ . '/../includes/conexion.php';

header('Content-Type: application/json; charset=utf-8');


/* =========================
   VERIFICAR SESIÓN
========================= */

if (!isset($_SESSION['usuario_id'])) {

    echo json_encode([
        'ok' => false,
        'mensaje' => 'La sesión ha expirado.'
    ]);

    exit;
}


/* =========================
   RECIBIR DATOS
========================= */

$datos = json_decode(
    file_get_contents('php://input'),
    true
);

$pedidoId = (int)($datos['pedido_id'] ?? 0);

$referencia = trim(
    $datos['referencia'] ?? ''
);


if ($pedidoId <= 0 || !$referencia) {

    echo json_encode([
        'ok' => false,
        'mensaje' => 'Datos de pago inválidos.'
    ]);

    exit;
}


/* =========================
   VERIFICAR REFERENCIA
========================= */

if (
    !preg_match(
        '/^sim_[A-Za-z0-9_-]+$/',
        $referencia
    )
) {

    echo json_encode([
        'ok' => false,
        'mensaje' => 'Referencia de pago inválida.'
    ]);

    exit;
}


try {

    /* =========================
       INICIAR TRANSACCIÓN
    ========================= */

    $conn->begin_transaction();


    /* =========================
       BUSCAR PEDIDO
    ========================= */

    $stmt = $conn->prepare(
        "SELECT
            p.id,
            p.codigo,
            p.estado,
            pg.id AS pago_id,
            pg.estado AS estado_pago,
            pg.metodo
         FROM pedidos p
         INNER JOIN pagos pg
            ON pg.pedido_id = p.id
         INNER JOIN clientes c
            ON c.id = p.cliente_id
         WHERE
            p.id = ?
            AND c.usuario_id = ?
         LIMIT 1
         FOR UPDATE"
    );

    $stmt->bind_param(
        'ii',
        $pedidoId,
        $_SESSION['usuario_id']
    );

    $stmt->execute();

    $pedido = $stmt
        ->get_result()
        ->fetch_assoc();


    if (!$pedido) {

        throw new Exception(
            'No se encontró el pedido.'
        );

    }


    /* =========================
       VERIFICAR MÉTODO
    ========================= */

    if (
        $pedido['metodo'] !==
        'tarjeta_simulada'
    ) {

        throw new Exception(
            'El pedido no corresponde a una tarjeta simulada.'
        );

    }


    /* =========================
       EVITAR DOBLE PAGO
    ========================= */

    if (
        $pedido['estado_pago'] ===
        'confirmado'
    ) {

        $conn->commit();

        echo json_encode([
            'ok' => true,
            'mensaje' =>
                'El pago ya estaba confirmado.',
            'referencia' =>
                $referencia
        ]);

        exit;
    }


    /* =========================
       ACTUALIZAR PAGO
    ========================= */

    /*
       La tabla pagos actual tiene:

       id
       pedido_id
       metodo
       monto
       estado
       creado_en

       Por eso solamente actualizamos
       el campo estado.
    */

    $estadoPago = 'confirmado';

    $stmt = $conn->prepare(
        "UPDATE pagos
         SET estado = ?
         WHERE id = ?"
    );

    $stmt->bind_param(
        'si',
        $estadoPago,
        $pedido['pago_id']
    );

    $stmt->execute();


    if ($stmt->affected_rows < 1) {

        throw new Exception(
            'No se pudo actualizar el pago.'
        );

    }


    /* =========================
       ACTUALIZAR PEDIDO
    ========================= */

    $estadoPedido = 'confirmado';

    $stmt = $conn->prepare(
        "UPDATE pedidos
         SET estado = ?
         WHERE id = ?"
    );

    $stmt->bind_param(
        'si',
        $estadoPedido,
        $pedidoId
    );

    $stmt->execute();


    /* =========================
       CONFIRMAR TRANSACCIÓN
    ========================= */

    $conn->commit();


    /* =========================
       RESPUESTA
    ========================= */

    echo json_encode([
        'ok' => true,
        'mensaje' =>
            'Pago confirmado correctamente.',
        'referencia' =>
            $referencia
    ]);

    exit;


} catch (Throwable $e) {

    $conn->rollback();

    echo json_encode([
        'ok' => false,
        'mensaje' =>
            'No se pudo confirmar el pago: ' .
            $e->getMessage()
    ]);

    exit;
}

?>