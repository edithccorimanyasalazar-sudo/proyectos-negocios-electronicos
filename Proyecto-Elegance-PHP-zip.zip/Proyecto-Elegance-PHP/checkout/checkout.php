<?php

require_once __DIR__ . '/../includes/sesion.php';
require_once __DIR__ . '/../includes/conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../auth/login.php?redirect=checkout');
    exit;
}

$raw = $_POST['carrito'] ?? '[]';
$cart = json_decode($raw, true);

if (!is_array($cart) || !count($cart)) {
    die('El carrito está vacío.');
}

$items = [];
$total = 0;

foreach ($cart as $it) {

    $pid = (int)($it['id'] ?? 0);
    $varianteId = (int)($it['variante_id'] ?? 0);
    $q = (int)($it['qty'] ?? 0);

    if ($pid <= 0 || $varianteId <= 0 || $q <= 0) {
        continue;
    }

    $s = $conn->prepare("
        SELECT
            v.id AS variante_id,
            v.nombre AS variante,
            v.precio,
            v.stock,
            p.nombre AS producto
        FROM variantes v
        JOIN productos p ON p.id = v.producto_id
        WHERE p.id = ?
          AND v.id = ?
          AND v.activo = 1
          AND p.activo = 1
    ");

    $s->bind_param('ii', $pid, $varianteId);
    $s->execute();

    $p = $s->get_result()->fetch_assoc();

    if (!$p) {
        continue;
    }

    $sub = (float)$p['precio'] * $q;

    $items[] = [
        'variante_id' => $p['variante_id'],
        'producto' => $p['producto'],
        'variante' => $p['variante'],
        'precio' => (float)$p['precio'],
        'stock' => (int)$p['stock'],
        'cantidad' => $q,
        'subtotal' => $sub
    ];

    $total += $sub;
}

if (!$items) {
    die('No se encontraron productos válidos.');
}

?>

<!doctype html>
<html lang="es">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">

    <title>Elegance - Finalizar compra</title>

    <link rel="stylesheet" href="../estilos.css">

    <style>

        .checkout-container {
            max-width: 950px;
            margin: 40px auto;
            padding: 20px;
        }

        .checkout-card {
            background: #fff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0,0,0,.08);
        }

        .checkout-title {
            text-align: center;
            margin-bottom: 25px;
        }

        .checkout-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .checkout-table th,
        .checkout-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        .checkout-total {
            text-align: right;
            font-size: 22px;
            margin: 20px 0;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-sizing: border-box;
        }

        .payment-box {
            margin-top: 15px;
            padding: 18px;
            border-radius: 14px;
            background: #faf7f4;
            border: 1px solid #eadfd7;
        }

        .payment-box h4 {
            margin-top: 0;
        }

        .payment-box p {
            margin: 7px 0;
        }

        .card-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .sandbox-note {
            margin-top: 12px;
            padding: 12px;
            border-radius: 10px;
            background: #fff4d6;
            border: 1px solid #f0d58a;
            font-size: 14px;
        }

        .btn-confirmar {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 15px;
        }

        .cancelar {
            display: block;
            text-align: center;
            margin-top: 18px;
        }

        @media(max-width:650px) {

            .checkout-card {
                padding: 20px;
            }

            .checkout-table {
                font-size: 13px;
            }

            .card-grid {
                grid-template-columns: 1fr;
            }

        }
         .qr-yape-container {
              text-align: center;
              margin: 20px auto;
        }

        .qr-yape {
            width: 280px;
           max-width: 100%;
           border-radius: 12px;
           display: block;
           margin: 0 auto 15px;
        }

         .qr-nombre {
           font-weight: 600;
           margin: 8px 0;
        }

        .qr-indicacion {
           font-size: 14px;
           color: #666;
        }

    </style>

</head>

<body>

<main class="checkout-container">

<section class="checkout-card">

    <h2 class="checkout-title">
        Finalizar pedido
    </h2>

    <p>
        Cliente:
        <strong>
            <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
        </strong>
    </p>


    <!-- =========================
         RESUMEN DEL PEDIDO
    ========================== -->

    <h3>Resumen de compra</h3>

    <table class="checkout-table">

        <thead>

            <tr>

                <th>Producto</th>
                <th>Variante</th>
                <th>Cantidad</th>
                <th>Subtotal</th>

            </tr>

        </thead>

        <tbody>

        <?php foreach ($items as $i): ?>

            <tr>

                <td>
                    <?= htmlspecialchars($i['producto']) ?>
                </td>

                <td>
                    <?= htmlspecialchars($i['variante']) ?>
                </td>

                <td>
                    <?= $i['cantidad'] ?>
                </td>

                <td>
                    S/ <?= number_format($i['subtotal'], 2) ?>
                </td>

            </tr>

        <?php endforeach; ?>

        </tbody>

    </table>


    <div class="checkout-total">

        Total:
        <strong>
            S/ <?= number_format($total, 2) ?>
        </strong>

    </div>


    <!-- =========================
         FORMULARIO
    ========================== -->

    <form
        method="post"
        action="procesar_pedido.php"
        id="checkoutForm"
    >

        <input
            type="hidden"
            name="carrito"
            value="<?= htmlspecialchars($raw, ENT_QUOTES, 'UTF-8') ?>"
        >


        <!-- DIRECCIÓN -->

        <div class="form-group">

            <label>
                Dirección de entrega
            </label>

            <input
                type="text"
                name="direccion"
                class="form-control"
                placeholder="Ingrese su dirección"
                required
            >

        </div>


        <!-- MÉTODO DE PAGO -->

        <div class="form-group">

            <label>
                Método de pago
            </label>

            <select
                name="metodo_pago"
                id="metodo_pago"
                class="form-control"
                required
            >

                <option value="">
                    Seleccione un método
                </option>

                <option value="yape">
                    Yape
                </option>

                <option value="plin">
                    Plin
                </option>

                <option value="transferencia">
                    Transferencia bancaria
                </option>

                <option value="tarjeta_simulada">
                    Tarjeta simulada (Sandbox)
                </option>

                <option value="contraentrega">
                    Contraentrega
                </option>

            </select>

        </div>


        <!-- =========================
             YAPE
        ========================== -->
        <div id="info-yape" class="payment-info">
         <h3>Pago con Yape</h3>

         <p>Escanea el código QR para realizar tu pago.</p>

         <div class="qr-yape-container">
         <img src="../img/qr_yape.png"
             alt="QR de pago Yape de Elegance"
             class="qr-yape">

         <p class="qr-nombre">
            Edith Veronica Ccorimanya Salazar
         </p>
         </div>

       <p class="qr-indicacion">
        Después de realizar el pago, continúa con la confirmación de tu pedido.
       </p>
       </div>


        <!-- =========================
             PLIN
        ========================== -->

        <div
            id="info-plin"
            class="payment-box"
            style="display:none"
        >

            <h4>Pago con Plin</h4>

            <p>
                En esta demostración se mostrará aquí
                el código QR de Plin.
            </p>

        </div>


        <!-- =========================
             TRANSFERENCIA
        ========================== -->

        <div
            id="info-transferencia"
            class="payment-box"
            style="display:none"
        >

            <h4>Transferencia bancaria</h4>

            <p>
                Banco: Banco de demostración
            </p>

            <p>
                Cuenta: **** **** ****
            </p>

            <p>
                Titular: Elegance
            </p>

            <p>
                Después de realizar la transferencia,
                la tienda podrá verificar el pago.
            </p>

        </div>


        <!-- =========================
             TARJETA SANDBOX
        ========================== -->

        <div
            id="info-tarjeta"
            class="payment-box"
            style="display:none"
        >

            <h4>
                Pago con tarjeta
            </h4>

            <p>
                Complete los datos de la tarjeta
                de prueba.
            </p>


            <div class="form-group">

                <label>
                    Número de tarjeta
                </label>

                <input
                    type="text"
                    id="numero_tarjeta"
                    name="numero_tarjeta"
                    class="form-control"
                    placeholder="4242 4242 4242 4242"
                    maxlength="19"
                    autocomplete="off"
                >

            </div>


            <div class="form-group">

                <label>
                    Nombre del titular
                </label>

                <input
                    type="text"
                    id="nombre_tarjeta"
                    name="nombre_tarjeta"
                    class="form-control"
                    placeholder="TITULAR DE PRUEBA"
                    autocomplete="off"
                >

            </div>


            <div class="card-grid">

                <div class="form-group">

                    <label>
                        Vencimiento
                    </label>

                    <input
                        type="text"
                        id="vencimiento"
                        name="vencimiento"
                        class="form-control"
                        placeholder="12/30"
                        maxlength="5"
                        autocomplete="off"
                    >

                </div>


                <div class="form-group">

                    <label>
                        CVV
                    </label>

                    <input
                        type="text"
                        id="cvv"
                        name="cvv"
                        class="form-control"
                        placeholder="123"
                        maxlength="4"
                        autocomplete="off"
                    >

                </div>

            </div>


            <div class="sandbox-note">

                <strong>Modo Sandbox / demostración</strong>

                <br><br>

                Tarjeta aprobada:

                <br>

                <strong>4242 4242 4242 4242</strong>

                <br><br>

                Tarjeta rechazada:

                <br>

                <strong>4000 0000 0000 0002</strong>

                <br><br>

                Fondos insuficientes:

                <br>

                <strong>4000 0000 0000 9995</strong>

            </div>

        </div>


        <!-- =========================
             CONTRAENTREGA
        ========================== -->

        <div
            id="info-contraentrega"
            class="payment-box"
            style="display:none"
        >

            <h4>
                Pago contraentrega
            </h4>

            <p>
                El pago se realizará al recibir
                el pedido.
            </p>

        </div>


        <button
            class="btn-add btn-confirmar"
            type="submit"
        >
            Continuar con el pedido
        </button>


        <a
            href="../index.php"
            class="cancelar"
        >
            Cancelar
        </a>

    </form>

</section>

</main>


<script>

const metodoPago = document.getElementById('metodo_pago');

const bloques = {

    yape: document.getElementById('info-yape'),

    plin: document.getElementById('info-plin'),

    transferencia: document.getElementById('info-transferencia'),

    tarjeta_simulada: document.getElementById('info-tarjeta'),

    contraentrega: document.getElementById('info-contraentrega')

};


metodoPago.addEventListener('change', function() {

    Object.values(bloques).forEach(function(bloque) {

        bloque.style.display = 'none';

    });


    const seleccionado = bloques[this.value];

    if (seleccionado) {

        seleccionado.style.display = 'block';

    }

});

</script>

</body>

</html>