<?php

require_once __DIR__ . '/../includes/sesion.php';
require_once __DIR__ . '/../includes/conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

/* =========================
   DATOS RECIBIDOS
========================= */

$cart = json_decode($_POST['carrito'] ?? '[]', true);
$dir = trim($_POST['direccion'] ?? '');
$metodo = $_POST['metodo_pago'] ?? '';

$numeroTarjeta = trim($_POST['numero_tarjeta'] ?? '');

$metodosPermitidos = [
    'yape',
    'plin',
    'transferencia',
    'tarjeta_simulada',
    'contraentrega'
];

if (
    !$dir ||
    !in_array($metodo, $metodosPermitidos, true) ||
    !is_array($cart) ||
    !count($cart)
) {
    die('Datos inválidos.');
}


/* =========================
   VALIDACIÓN TARJETA
========================= */

if ($metodo === 'tarjeta_simulada') {

    if (!$numeroTarjeta) {
        die('Debe ingresar una tarjeta de prueba.');
    }

    // Quitamos espacios y guiones
    $numeroTarjeta = preg_replace('/[\s-]/', '', $numeroTarjeta);

    /*
       Solo aceptamos las tarjetas de prueba
       de nuestra simulación.
    */

    $tarjetasPrueba = [
        '4242424242424242' => 'exito',
        '4000000000000002' => 'rechazada',
        '4000000000009995' => 'fondos_insuficientes'
    ];

    if (!isset($tarjetasPrueba[$numeroTarjeta])) {
        die(
            'Tarjeta no válida para la demostración. ' .
            'Use una de las tarjetas de prueba indicadas.'
        );
    }

    if ($tarjetasPrueba[$numeroTarjeta] !== 'exito') {

        if ($tarjetasPrueba[$numeroTarjeta] === 'rechazada') {
            die('La tarjeta de prueba fue rechazada.');
        }

        if ($tarjetasPrueba[$numeroTarjeta] === 'fondos_insuficientes') {
            die('La tarjeta de prueba no tiene fondos suficientes.');
        }
    }
}


/* =========================
   BUSCAR CLIENTE
========================= */

$stmt = $conn->prepare(
    'SELECT id FROM clientes WHERE usuario_id = ? LIMIT 1'
);

$stmt->bind_param(
    'i',
    $_SESSION['usuario_id']
);

$stmt->execute();

$cliente = $stmt->get_result()->fetch_assoc();

if (!$cliente) {
    die('No existe el perfil del cliente.');
}


/* =========================
   INICIAR TRANSACCIÓN
========================= */

try {

    $conn->begin_transaction();

    $items = [];
    $subtotal = 0;


    /* =========================
       PROCESAR CARRITO
    ========================= */

    foreach ($cart as $item) {

        $productoId = (int)($item['id'] ?? 0);
        $varianteId = (int)($item['variante_id'] ?? 0);
        $cantidad = (int)($item['qty'] ?? 0);

        if (
            $productoId <= 0 ||
            $varianteId <= 0 ||
            $cantidad <= 0
        ) {
            continue;
        }


        /* =========================
           BUSCAR VARIANTE EXACTA
        ========================= */

        $stmt = $conn->prepare(
            "SELECT
                v.id AS variante_id,
                v.nombre AS variante,
                v.precio,
                v.stock,
                p.nombre AS producto
             FROM variantes v
             INNER JOIN productos p
                ON p.id = v.producto_id
             WHERE
                p.id = ?
                AND v.id = ?
                AND v.activo = 1
                AND p.activo = 1
             LIMIT 1
             FOR UPDATE"
        );

        $stmt->bind_param(
            'ii',
            $productoId,
            $varianteId
        );

        $stmt->execute();

        $variante = $stmt->get_result()->fetch_assoc();


        if (!$variante) {

            throw new Exception(
                'La variante seleccionada no está disponible.'
            );

        }


        /* =========================
           COMPROBAR STOCK
        ========================= */

        if ($variante['stock'] < $cantidad) {

            throw new Exception(
                'No hay stock suficiente para ' .
                $variante['producto'] .
                '.'
            );

        }


        /* =========================
           CALCULAR SUBTOTAL
        ========================= */

        $precio = (float)$variante['precio'];

        $subtotalItem = $precio * $cantidad;

        $subtotal += $subtotalItem;


        /* =========================
           GUARDAR ITEM
        ========================= */

        $items[] = [
            'variante_id' => $variante['variante_id'],
            'producto' => $variante['producto'],
            'variante' => $variante['variante'],
            'precio' => $precio,
            'cantidad' => $cantidad,
            'subtotal' => $subtotalItem
        ];
    }


    if (!count($items)) {

        throw new Exception(
            'Carrito vacío.'
        );

    }


    /* =========================
       COSTO DE ENVÍO
    ========================= */

    $costoEnvio = 0;

    $total = $subtotal + $costoEnvio;


    /* =========================
       GENERAR CÓDIGO
    ========================= */

    $codigo =
        'PED-' .
        date('YmdHis') .
        '-' .
        random_int(100, 999);


    /* =========================
       ESTADO INICIAL DEL PEDIDO
    ========================= */

    /*
       Todos los pedidos comienzan como
       pendientes.

       Posteriormente, si el pago con
       tarjeta sandbox es aprobado,
       otro archivo cambiará el pedido
       a confirmado.
    */

    $estadoPedido = 'pendiente';


    /* =========================
       REGISTRAR PEDIDO
    ========================= */

    $stmt = $conn->prepare(
        "INSERT INTO pedidos
        (
            cliente_id,
            codigo,
            direccion_entrega,
            subtotal,
            costo_envio,
            total,
            estado
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )"
    );

    $stmt->bind_param(
        'issddds',
        $cliente['id'],
        $codigo,
        $dir,
        $subtotal,
        $costoEnvio,
        $total,
        $estadoPedido
    );

    $stmt->execute();

    $pedidoId = $stmt->insert_id;


    /* =========================
       DETALLE DEL PEDIDO
    ========================= */

    foreach ($items as $item) {

        $stmt = $conn->prepare(
            "INSERT INTO detalle_pedido
            (
                pedido_id,
                variante_id,
                nombre_producto,
                nombre_variante,
                precio_unitario,
                cantidad,
                subtotal
            )
            VALUES
            (?, ?, ?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            'iissdid',
            $pedidoId,
            $item['variante_id'],
            $item['producto'],
            $item['variante'],
            $item['precio'],
            $item['cantidad'],
            $item['subtotal']
        );

        $stmt->execute();


        /* =========================
           DESCONTAR STOCK
        ========================= */

        $stmt = $conn->prepare(
            'UPDATE variantes
             SET stock = stock - ?
             WHERE id = ?'
        );

        $stmt->bind_param(
            'ii',
            $item['cantidad'],
            $item['variante_id']
        );

        $stmt->execute();
    }


    /* =========================
       REGISTRAR PAGO
    ========================= */

    $estadoPago = 'pendiente';

    $referencia = null;

    /*
       Si es tarjeta simulada, guardamos
       una referencia de demostración.

       NO guardamos el número de tarjeta.
    */

    if ($metodo === 'tarjeta_simulada') {

        $referencia =
            'sim_' .
            date('YmdHis') .
            '_' .
            random_int(1000, 9999);
    }


    $stmt = $conn->prepare(
    "INSERT INTO pagos
    (
        pedido_id,
        metodo,
        monto,
        estado
    )
    VALUES
    (?, ?, ?, ?)"
);

$stmt->bind_param(
    'isds',
    $pedidoId,
    $metodo,
    $total,
    $estadoPago
);

$stmt->execute();


    /* =========================
       CONFIRMAR TRANSACCIÓN
    ========================= */

    $conn->commit();


    /* =========================
       PREPARAR WHATSAPP
    ========================= */

    $whatsapp = '51966376986';

    $nombreCliente =
        $_SESSION['usuario_nombre'] ?? 'cliente';

    $mensaje =
        'Hola, soy ' .
        $nombreCliente .
        '. Acabo de registrar el pedido ' .
        $codigo .
        ' por S/ ' .
        number_format($total, 2) .
        '. Quisiera coordinar la entrega.';


    $urlWhatsApp =
        'https://wa.me/' .
        $whatsapp .
        '?text=' .
        rawurlencode($mensaje);


    /* =========================
       REDIRECCIÓN
    ========================= */

    /*
       Si es tarjeta simulada, vamos a una
       página especial donde se realizará
       la confirmación del pago.
    */

    if ($metodo === 'tarjeta_simulada') {

        header(
            'Location: pago_sandbox.php?' .
            'pedido_id=' . urlencode($pedidoId) .
            '&codigo=' . urlencode($codigo) .
            '&whatsapp=' . urlencode($urlWhatsApp)
        );

        exit;
    }


    /*
       Los demás métodos continúan
       con el flujo normal.
    */

    header(
        'Location: pedido_exitoso.php?' .
        'codigo=' . urlencode($codigo) .
        '&whatsapp=' . urlencode($urlWhatsApp)
    );

    exit;


} catch (Throwable $e) {

    $conn->rollback();

    die(
        'No se pudo registrar el pedido: ' .
        htmlspecialchars($e->getMessage())
    );
}

?>