<?php

require_once __DIR__ . '/../includes/sesion.php';
require_once __DIR__ . '/../includes/conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

$pedidoId = (int)($_GET['pedido_id'] ?? 0);
$codigo = $_GET['codigo'] ?? '';
$whatsapp = $_GET['whatsapp'] ?? '';

if ($pedidoId <= 0 || !$codigo) {
    die('Datos del pedido inválidos.');
}


/* =========================
   VERIFICAR PEDIDO
========================= */
$stmt = $conn->prepare(
    "SELECT
        p.id,
        p.codigo,
        p.total,
        p.estado,
        pg.id AS pago_id,
        pg.metodo,
        pg.estado AS estado_pago
     FROM pedidos p
     INNER JOIN pagos pg
        ON pg.pedido_id = p.id
     INNER JOIN clientes c
        ON c.id = p.cliente_id
     WHERE
        p.id = ?
        AND c.usuario_id = ?
     LIMIT 1"
);

$stmt->bind_param(
    'ii',
    $pedidoId,
    $_SESSION['usuario_id']
);

$stmt->execute();

$pedido = $stmt->get_result()->fetch_assoc();

if (!$pedido) {
    die('No se encontró el pedido.');
}


/* =========================
   COMPROBAR MÉTODO
========================= */

if ($pedido['metodo'] !== 'tarjeta_simulada') {
    die('Este pedido no corresponde a una tarjeta simulada.');
}

?>

<!doctype html>

<html lang="es">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width,initial-scale=1"
    >

    <title>Elegance - Pago Sandbox</title>

    <link
        rel="stylesheet"
        href="../estilos.css"
    >

    <style>

        body {
            background: #f8f5f2;
        }

        .sandbox-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
        }

        .sandbox-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0,0,0,.08);
        }

        .sandbox-title {
            text-align: center;
            margin-bottom: 25px;
        }

        .order-info {
            background: #faf7f4;
            border-radius: 12px;
            padding: 18px;
            margin-bottom: 25px;
        }

        .order-info p {
            margin: 7px 0;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        .form-control {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 10px;
        }

        .card-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .sandbox-info {
            background: #fff4d6;
            border: 1px solid #efd38b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .sandbox-info strong {
            font-weight: bold;
        }

        .btn-pagar {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 16px;
        }

        .mensaje {
            display: none;
            margin-top: 20px;
            padding: 15px;
            border-radius: 12px;
            text-align: center;
        }

        .procesando {
            background: #f4f1ed;
        }

        .error {
            background: #ffe7e7;
            border: 1px solid #e3aaaa;
        }

        @media(max-width:600px) {

            .sandbox-card {
                padding: 20px;
            }

            .card-grid {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>

<main class="sandbox-container">

<section class="sandbox-card">

    <h2 class="sandbox-title">
        Pago con tarjeta
    </h2>


    <!-- =========================
         INFORMACIÓN DEL PEDIDO
    ========================== -->

    <div class="order-info">

        <p>
            Pedido:
            <strong>
                <?= htmlspecialchars($pedido['codigo']) ?>
            </strong>
        </p>

        <p>
            Total:
            <strong>
                S/ <?= number_format($pedido['total'], 2) ?>
            </strong>
        </p>

        <p>
            Estado del pago:
            <strong>
                <?= htmlspecialchars($pedido['estado_pago']) ?>
            </strong>
        </p>

    </div>


    <!-- =========================
         AVISO SANDBOX
    ========================== -->

    <div class="sandbox-info">

        <strong>
            Modo Sandbox / demostración
        </strong>

        <br><br>

        Tarjeta aprobada:

        <br>

        <strong>
            4242 4242 4242 4242
        </strong>

        <br><br>

        Tarjeta rechazada:

        <br>

        <strong>
            4000 0000 0000 0002
        </strong>

        <br><br>

        Fondos insuficientes:

        <br>

        <strong>
            4000 0000 0000 9995
        </strong>

    </div>


    <!-- =========================
         FORMULARIO
    ========================== -->

    <form id="formPago">

        <div class="form-group">

            <label>
                Número de tarjeta
            </label>

            <input
                type="text"
                id="numero_tarjeta"
                class="form-control"
                placeholder="4242 4242 4242 4242"
                maxlength="19"
                autocomplete="off"
                required
            >

        </div>


        <div class="form-group">

            <label>
                Nombre del titular
            </label>

            <input
                type="text"
                id="nombre_tarjeta"
                class="form-control"
                placeholder="TITULAR DE PRUEBA"
                autocomplete="off"
                required
            >

        </div>


        <div class="card-grid">

            <div class="form-group">

                <label>
                    Vencimiento
                </label>

                <input
                    type="text"
                    id="vencimiento"
                    class="form-control"
                    placeholder="12/30"
                    maxlength="5"
                    autocomplete="off"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    CVV
                </label>

                <input
                    type="text"
                    id="cvv"
                    class="form-control"
                    placeholder="123"
                    maxlength="4"
                    autocomplete="off"
                    required
                >

            </div>

        </div>


        <button
            type="submit"
            class="btn-add btn-pagar"
            id="btnPagar"
        >
            Pagar S/ <?= number_format($pedido['total'], 2) ?>
        </button>

    </form>


    <!-- =========================
         MENSAJE
    ========================== -->

    <div
        id="mensaje"
        class="mensaje"
    ></div>


</section>

</main>


<script>

/* =========================
   DATOS DEL PEDIDO
========================= */

const pedidoId = <?= (int)$pedidoId ?>;

const codigo = <?= json_encode($codigo) ?>;

const whatsapp = <?= json_encode($whatsapp) ?>;

const total = <?= json_encode((float)$pedido['total']) ?>;


/* =========================
   ELEMENTOS
========================= */

const form = document.getElementById('formPago');

const numeroInput =
    document.getElementById('numero_tarjeta');

const mensaje =
    document.getElementById('mensaje');

const boton =
    document.getElementById('btnPagar');


/* =========================
   LIMPIAR TARJETA
========================= */

function limpiarNumeroTarjeta(numero) {

    return numero.replace(/[\s-]/g, '');

}


/* =========================
   VALIDAR LUHN
========================= */

function validarLuhn(numero) {

    let suma = 0;

    let duplicar = false;

    for (
        let i = numero.length - 1;
        i >= 0;
        i--
    ) {

        let digito =
            parseInt(numero.charAt(i), 10);

        if (duplicar) {

            digito *= 2;

            if (digito > 9) {
                digito -= 9;
            }

        }

        suma += digito;

        duplicar = !duplicar;
    }

    return suma % 10 === 0;

}


/* =========================
   MOSTRAR MENSAJE
========================= */

function mostrarMensaje(texto, tipo) {

    mensaje.style.display = 'block';

    mensaje.className =
        'mensaje ' + tipo;

    mensaje.textContent = texto;

}


/* =========================
   FORMATEAR TARJETA
========================= */

numeroInput.addEventListener(
    'input',
    function() {

        let numero =
            this.value.replace(/\D/g, '');

        numero =
            numero.substring(0, 16);

        let grupos = [];

        for (
            let i = 0;
            i < numero.length;
            i += 4
        ) {

            grupos.push(
                numero.substring(i, i + 4)
            );

        }

        this.value =
            grupos.join(' ');

    }
);


/* =========================
   PROCESAR PAGO
========================= */

form.addEventListener(
    'submit',
    async function(event) {

        event.preventDefault();


        let numero =
            limpiarNumeroTarjeta(
                numeroInput.value
            );


        /* Validar longitud */

        if (numero.length !== 16) {

            mostrarMensaje(
                'Ingrese una tarjeta de prueba de 16 dígitos.',
                'error'
            );

            return;
        }


        /* Validar algoritmo Luhn */

        if (!validarLuhn(numero)) {

            mostrarMensaje(
                'El número de tarjeta no es válido.',
                'error'
            );

            return;
        }


        /* Mostrar procesamiento */

        boton.disabled = true;

        boton.textContent =
            'Procesando pago...';

        mostrarMensaje(
            'Estamos procesando el pago de prueba...',
            'procesando'
        );


        /*
           Simulamos el tiempo de respuesta
           de una pasarela de pago.
        */

        await new Promise(
            resolve => setTimeout(resolve, 1500)
        );


        /* =========================
           TARJETAS DE PRUEBA
        ========================== */

        if (numero === '4000000000000002') {

            boton.disabled = false;

            boton.textContent =
                'Intentar nuevamente';

            mostrarMensaje(
                'Pago rechazado. La tarjeta de prueba fue rechazada.',
                'error'
            );

            return;
        }


        if (numero === '4000000000009995') {

            boton.disabled = false;

            boton.textContent =
                'Intentar nuevamente';

            mostrarMensaje(
                'Pago rechazado. Fondos insuficientes.',
                'error'
            );

            return;
        }


        if (numero !== '4242424242424242') {

            boton.disabled = false;

            boton.textContent =
                'Intentar nuevamente';

            mostrarMensaje(
                'Tarjeta no reconocida para esta demostración.',
                'error'
            );

            return;
        }


        /* =========================
           PAGO APROBADO
        ========================== */

        const referencia =
            'sim_' +
            Date.now() +
            '_' +
            Math.floor(
                Math.random() * 9000 + 1000
            );


        /*
           Enviamos solamente:

           pedido_id
           referencia

           NO enviamos ni guardamos
           el número de tarjeta.
        */

        try {

            const respuesta =
                await fetch(
                    'procesar_pago_sandbox.php',
                    {
                        method: 'POST',

                        headers: {
                            'Content-Type':
                                'application/json'
                        },

                        body: JSON.stringify({

                            pedido_id: pedidoId,

                            referencia: referencia

                        })
                    }
                );


            const resultado =
                await respuesta.json();


            if (!resultado.ok) {

                boton.disabled = false;

                boton.textContent =
                    'Intentar nuevamente';

                mostrarMensaje(
                    resultado.mensaje ||
                    'No se pudo confirmar el pago.',
                    'error'
                );

                return;
            }


            /* =========================
               ÉXITO
            ========================== */

            mostrarMensaje(
                'Pago aprobado correctamente. Redirigiendo...',
                'procesando'
            );


            setTimeout(
                function() {

                    window.location.href =
                        'pedido_exitoso.php?' +
                        'codigo=' +
                        encodeURIComponent(codigo) +
                        '&whatsapp=' +
                        encodeURIComponent(whatsapp);

                },
                1000
            );


        } catch (error) {

            boton.disabled = false;

            boton.textContent =
                'Intentar nuevamente';

            mostrarMensaje(
                'No se pudo conectar con el servidor.',
                'error'
            );

        }

    }
);

</script>

</body>

</html>