<?php

require_once "includes/conexion.php";

echo "Conexión exitosa con la base de datos Elegance";

?>