# Elegance PHP + MySQL — basado en tu ZIP real

Se conservaron tu `estilos.css`, `script.js` e imágenes originales.

ANTES:
JavaScript → Node/Express → MySQL

AHORA:
JavaScript → `api/productos.php` → PHP → MySQL

Los productos NO se pasan manualmente a HTML. MySQL es la fuente de datos; PHP entrega los productos y JavaScript conserva las interacciones de tu diseño.

## Instalar
1. Copia la carpeta en `C:\xampp\htdocs\Proyecto-Elegance-PHP`
2. Enciende Apache y MySQL.
3. phpMyAdmin → Importar → `sql/elegance_db.sql`
4. Abre `http://localhost/Proyecto-Elegance-PHP/`
5. Registra un usuario.
6. Prueba carrito → Finalizar pedido → checkout.
7. Comprueba el pedido en MySQL.

El backend Node del ZIP original no se elimina de tu ZIP original; esta carpeta PHP ya no lo necesita.

## Qué decir al profesor
"Antes tenía Node y Express como backend. Para la versión final migré el backend a PHP porque PHP puede trabajar directamente con MySQL en este entorno. Los productos pasan a estar almacenados en MySQL; PHP los consulta y JavaScript se usa para la interacción de la interfaz."
