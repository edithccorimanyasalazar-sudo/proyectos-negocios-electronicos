<?php
$host='127.0.0.1'; $usuario='root'; $password=''; $baseDatos='elegance_db';
$conn=new mysqli($host,$usuario,$password,$baseDatos);
if($conn->connect_error){http_response_code(500);die('Error de conexión con MySQL: '.$conn->connect_error);}
$conn->set_charset('utf8mb4');
?>