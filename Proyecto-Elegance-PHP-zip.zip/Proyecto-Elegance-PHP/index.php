<?php require_once __DIR__.'/includes/sesion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Joyería Elegance | Colección Celestial</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="estilos.css">
</head>
<body><?php if(isset($_SESSION['usuario_id'])): ?><div style="position:fixed;top:12px;right:20px;z-index:1000;font-size:.85rem">Hola, <?=htmlspecialchars($_SESSION['usuario_nombre'])?> · <a href="auth/logout.php">Salir</a></div><?php else: ?><div style="position:fixed;top:12px;right:20px;z-index:1000;font-size:.85rem"><a href="auth/login.php">Iniciar sesión</a></div><?php endif; ?>

<div class="estrellas-container" id="lluviaContainer"></div>

<header>
  <img class="logo" src="img/logo.jpg" alt="Logo Joyería Elegance">
  <p>Piezas únicas para momentos únicos. Envíos a todo el país.</p>
  <div class="currency-bar">
    <label class="currency-label" for="currencySelect">Ver precios en:</label>
    <select class="currency-select" id="currencySelect"></select>
    <span class="moneda-badge" id="monedaBadge">Obteniendo tipo de cambio…</span>
  </div>
</header>

<nav>
  <a href="#inicio">Inicio</a>
  <a href="#collares">Collares</a>
  <a href="#aretes">Aretes</a>
  <a href="#anillos">Anillos</a>
  <a href="#pulseras">Pulseras</a>
  <a href="#pedidos">Mis pedidos <span class="nav-badge" id="navPedidosCount" hidden>0</span></a>
  <a href="#clientes">Clientes</a>
  <a href="#contacto">Contacto</a>
</nav>

<section id="inicio">
  <div class="carousel">
    <div class="carousel-inner">
      <div class="carousel-item">
        <img loading="lazy" src="img/carrusel2.jpg" alt="Colección Verano">
        <div class="carousel-overlay">
          <span class="eyebrow">Nueva colección</span>
          <h2>Un cielo hecho joya</h2>
          <p>Piezas exclusivas en oro, plata y piedras naturales, inspiradas en el firmamento.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img loading="lazy" src="img/carrusel3.jpg" alt="Anillos de Compromiso">
        <div class="carousel-overlay">
          <span class="eyebrow">Para siempre</span>
          <h2>Anillos de Compromiso</h2>
          <p>El símbolo perfecto para un para siempre.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img loading="lazy" src="img/carrusel1.jpg" alt="Envío Gratis">
        <div class="carousel-overlay">
          <span class="eyebrow">Beneficio</span>
          <h2>Envío gratis</h2>
          <p>En compras mayores a S/ 300 a nivel nacional.</p>
        </div>
      </div>
    </div>

    <div class="carousel-controls">
      <button class="carousel-btn prev" onclick="previousSlide()" aria-label="Anterior">‹</button>
      <button class="carousel-btn next" onclick="nextSlide()" aria-label="Siguiente">›</button>
    </div>

    <div class="carousel-indicators">
      <span class="indicator active" onclick="goToSlide(0)"></span>
      <span class="indicator" onclick="goToSlide(1)"></span>
      <span class="indicator" onclick="goToSlide(2)"></span>
    </div>
  </div>
</section>

<div class="productos">
  <section id="productos">
    <h2>Nuestro Catálogo</h2>
    <p class="subtitle">20 piezas seleccionadas para ti, organizadas por tipo</p>

    <div class="buscador-wrap">
      <div class="buscador-caja">
        <svg class="buscador-icono" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.7.7l.27.28v.79l5 5L20.49 19l-5-5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/></svg>
        <input type="text" id="buscadorInput" placeholder="Buscar por nombre, material o categoría..." autocomplete="off">
        <button type="button" id="buscadorLimpiar" class="buscador-limpiar" aria-label="Limpiar búsqueda" hidden>&times;</button>
      </div>
      <p class="buscador-resultado" id="buscadorResultado" hidden></p>
    </div>

    <div id="catalogo"></div>
  </section>
</div>

<section id="pedidos" class="pedidos-section">
  <div class="pedidos-wrap">
    <h2>Mis pedidos</h2>
    <p class="subtitle">Historial de los pedidos que enviaste durante esta visita</p>
    <div id="pedidosList">
      <p class="pedidos-empty">Todavía no has enviado ningún pedido. Cuando finalices una compra desde el carrito, aparecerá aquí. &#10023;</p>
    </div>
  </div>
</section>

<section id="clientes" class="clientes-section">
  <h2>Clientes que confían en nosotros</h2>
  <p class="clientes-subtitle">Marcas y negocios que ya lucen nuestras piezas</p>
  <div class="logos-carousel-container">
    <div class="logos-track">
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+1" alt="Cliente 1"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+2" alt="Cliente 2"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+3" alt="Cliente 3"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+4" alt="Cliente 4"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+5" alt="Cliente 5"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+1" alt="Cliente 1"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+2" alt="Cliente 2"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+3" alt="Cliente 3"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+4" alt="Cliente 4"></div>
      <div class="logo-item"><img loading="lazy" src="https://via.placeholder.com/160x80.png?text=Cliente+5" alt="Cliente 5"></div>
    </div>
  </div>
</section>

<footer id="contacto">
  <p>Joyería Elegance</p>
  <p>Escríbenos por WhatsApp o visita nuestra tienda física.</p>
  <p>&copy; 2026 Joyería Elegance. Todos los derechos reservados.</p>
</footer>

<button id="btnInicio" class="btn-inicio-flotante" onclick="irAlInicio()" aria-label="Ir al inicio"></button>

<!-- ===== CARRITO ===== -->
<button class="cart-fab" id="cartFab" aria-label="Ver carrito">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M7 4h-2l-1 2v1h2l3.6 7.59-1.35 2.44c-.16.28-.25.61-.25.97 0 1.1.9 2 2 2h12v-2h-11.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1h-14.79l-.94-2zm2.5 16c1.1 0 1.99.9 1.99 2s-.89 2-1.99 2-2-.9-2-2 .9-2 2-2zm10 0c1.1 0 1.99.9 1.99 2s-.89 2-1.99 2-2-.9-2-2 .9-2 2-2z"/></svg>
  <span class="cart-count" id="cartCount">0</span>
</button>

<div class="cart-overlay" id="cartOverlay"></div>
<aside class="cart-drawer" id="cartDrawer" aria-hidden="true">
  <div class="cart-header">
    <h3>Tu joyero <span>· carrito</span></h3>
    <button class="cart-close" id="cartClose" aria-label="Cerrar carrito">&times;</button>
  </div>
  <div class="cart-items" id="cartItems">
    <p class="cart-empty">Tu joyero está vacío por ahora. Explora el catálogo y añade tus piezas favoritas ✧</p>
  </div>
  <div class="cart-footer">
    <div class="cart-total-row"><span>Total</span><span id="cartTotal">S/ 0.00</span></div>
    <button class="btn-checkout" id="cartCheckout">Finalizar pedido por WhatsApp</button>
    <button class="btn-clear" id="cartClear">Vaciar carrito</button>
  </div>
</aside>

<!-- ===== POP-UP DE BIENVENIDA ===== -->
<div class="promo-overlay" id="promoOverlay"></div>
<div class="promo-modal" id="promoModal" role="dialog" aria-hidden="true">
  <button class="promo-close" id="promoClose" aria-label="Cerrar aviso">&times;</button>
  <span class="promo-eyebrow">Bienvenida &#10023;</span>
  <h3>10% de descuento en tu primera compra</h3>
  <p>Usa el codigo <strong>ELEGANCE10</strong> al escribirnos por WhatsApp y te lo aplicamos al instante.</p>
  <button class="promo-cta" id="promoCta">Quiero mi descuento</button>
  <button class="promo-later" id="promoLater">Seguir viendo el catalogo</button>
</div>

<!-- ===== AVISO DE PRUEBA SOCIAL ===== -->
<div class="social-toast" id="socialToast" aria-hidden="true">
  <div class="social-toast-icon">&#128142;</div>
  <div class="social-toast-text">
    <strong id="socialToastTitle">&mdash;</strong>
    <span id="socialToastMsg">&mdash;</span>
  </div>
  <button class="social-toast-close" id="socialToastClose" aria-label="Cerrar aviso">&times;</button>
</div>

<!-- ===== ASISTENTE VIRTUAL ===== -->
<button class="chat-fab" id="chatFab" aria-label="Abrir asistente virtual">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.03 2 11c0 2.6 1.28 4.94 3.3 6.6-.14 1.1-.55 2.5-1.3 3.9 1.6-.2 3.2-.9 4.5-1.8 1.1.3 2.3.5 3.5.5 5.52 0 10-4.03 10-9S17.52 2 12 2z"/></svg>
  <span class="chat-dot" id="chatDot"></span>
</button>

<div class="chat-window" id="chatWindow" aria-hidden="true">
  <div class="chat-header">
    <div class="chat-header-info">
      <span class="chat-avatar">&#10023;</span>
      <div>
        <h4>Asistente de Elegance</h4>
        <span class="chat-status">Respuestas automaticas &middot; en linea</span>
      </div>
    </div>
    <button class="chat-close" id="chatClose" aria-label="Cerrar asistente">&times;</button>
  </div>
  <div class="chat-messages" id="chatMessages"></div>
  <div class="chat-quick" id="chatQuick"></div>
  <form class="chat-input-row" id="chatForm">
    <input type="text" id="chatInput" placeholder="Escribe tu pregunta..." autocomplete="off">
    <button type="submit" aria-label="Enviar">&#10148;</button>
  </form>
</div>

<script src="script.js"></script>
</body>
</html>