<?php
require_once __DIR__.'/../includes/sesion.php';require_once __DIR__.'/../includes/conexion.php';
if(isset($_SESSION['usuario_id'])){header('Location: ../index.php');exit;}
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
$email=trim($_POST['email']??'');$pass=$_POST['password']??'';
$s=$conn->prepare('SELECT id,nombre,password_hash,rol FROM usuarios WHERE email=? LIMIT 1');$s->bind_param('s',$email);$s->execute();$u=$s->get_result()->fetch_assoc();
if(password_verify($pass,$u['password_hash'])){$_SESSION['usuario_id']=$u['id'];$_SESSION['usuario_nombre']=$u['nombre'];$_SESSION['rol']=$u['rol'];header('Location: ../index.php');exit;}
$msg='Correo o contraseña incorrectos.';
}?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Elegance - Iniciar sesión</title><link rel="stylesheet" href="../estilos.css"></head><body><main style="max-width:520px;margin:80px auto;padding:25px"><section style="background:#fff;padding:30px;border-radius:18px"><h2>Iniciar sesión</h2><?php if($msg):?><p><?=htmlspecialchars($msg)?></p><?php endif;?><form method="post"><label>Correo</label><input style="width:100%;padding:12px;margin:8px 0 16px" type="email" name="email" required><label>Contraseña</label><input style="width:100%;padding:12px;margin:8px 0 16px" type="password" name="password" required><button class="btn-add" type="submit">Ingresar</button></form><p><a href="registro.php">Crear una cuenta</a> · <a href="../index.php">Volver</a></p></section></main></body></html>