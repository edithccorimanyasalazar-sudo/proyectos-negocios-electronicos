<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$usuarioId = $_SESSION['usuario_id'];

/* Buscar cliente */
$sqlCliente = "SELECT id FROM clientes WHERE usuario_id = ?";
$stmtCliente = $conn->prepare($sqlCliente);
$stmtCliente->bind_param("i", $usuarioId);
$stmtCliente->execute();

$resultCliente = $stmtCliente->get_result();
$cliente = $resultCliente->fetch_assoc();

if (!$cliente) {
    die("No se encontró información del cliente.");
}

$clienteId = $cliente['id'];


/* Buscar pedidos junto con información del pago */
$sqlPedidos = "
    SELECT 
        p.id,
        p.codigo,
        p.direccion_entrega,
        p.subtotal,
        p.costo_envio,
        p.total,
        p.estado,
        p.creado_en,
        pg.metodo AS metodo_pago,
        pg.estado AS estado_pago
    FROM pedidos p
    LEFT JOIN pagos pg ON pg.pedido_id = p.id
    WHERE p.cliente_id = ?
    ORDER BY p.id DESC
";

$stmtPedidos = $conn->prepare($sqlPedidos);
$stmtPedidos->bind_param("i", $clienteId);
$stmtPedidos->execute();

$resultPedidos = $stmtPedidos->get_result();

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Mis pedidos - Elegance</title>

    <link rel="stylesheet" href="../estilos.css">

    <style>

        body {
            background: #f8f5f2;
        }

        .contenedor-pedidos {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }

        .titulo-pedidos {
            text-align: center;
            margin-bottom: 30px;
        }

        .pedido {
            background: white;
            border-radius: 18px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .pedido-cabecera {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        .pedido-codigo {
            font-size: 18px;
            font-weight: bold;
        }

        .estado {
            padding: 7px 14px;
            border-radius: 20px;
            background: #f1e5d8;
            font-size: 14px;
        }

        .pedido-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .info-box {
            background: #fafafa;
            padding: 15px;
            border-radius: 12px;
        }

        .info-box strong {
            display: block;
            margin-bottom: 5px;
        }

        .productos {
            border-top: 1px solid #eee;
            padding-top: 15px;
        }

        .producto {
            display: flex;
            justify-content: space-between;
            gap: 15px;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .producto:last-child {
            border-bottom: none;
        }

        .totales {
            margin-top: 20px;
            text-align: right;
        }

        .total {
            font-size: 20px;
            font-weight: bold;
        }

        .sin-pedidos {
            background: white;
            padding: 40px;
            text-align: center;
            border-radius: 18px;
        }

        .volver {
            display: inline-block;
            margin-top: 25px;
            text-decoration: none;
        }

    </style>

</head>

<body>

<div class="contenedor-pedidos">

    <h1 class="titulo-pedidos">Mis pedidos</h1>

    <?php if ($resultPedidos->num_rows === 0): ?>

        <div class="sin-pedidos">

            <h2>Aún no tienes pedidos</h2>

            <p>
                Cuando realices una compra, aquí podrás consultar
                la información de tus pedidos.
            </p>

            <a href="../index.php" class="volver">
                Volver a la tienda
            </a>

        </div>

    <?php else: ?>

        <?php while ($pedido = $resultPedidos->fetch_assoc()): ?>

            <div class="pedido">

                <!-- CABECERA -->

                <div class="pedido-cabecera">

                    <div>

                        <div class="pedido-codigo">
                            Pedido:
                            <?= htmlspecialchars($pedido['codigo']) ?>
                        </div>

                        <small>
                            Fecha:
                            <?= htmlspecialchars($pedido['creado_en']) ?>
                        </small>

                    </div>

                    <div class="estado">

                        Estado:
                        <?= htmlspecialchars($pedido['estado']) ?>

                    </div>

                </div>


                <!-- INFORMACIÓN -->

                <div class="pedido-info">

                    <div class="info-box">

                        <strong>Dirección de entrega</strong>

                        <?= htmlspecialchars($pedido['direccion_entrega']) ?>

                    </div>


                    <div class="info-box">

                        <strong>Método de pago</strong>

                        <?php

                        $metodo = $pedido['metodo_pago'];

                        if ($metodo === 'yape') {

                            echo "Yape";

                        } elseif ($metodo === 'plin') {

                            echo "Plin";

                        } elseif ($metodo === 'transferencia') {

                            echo "Transferencia bancaria";

                        } elseif ($metodo === 'tarjeta_simulada') {

                            echo "Tarjeta";

                        } elseif ($metodo === 'contraentrega') {

                            echo "Contra entrega";

                        } elseif ($metodo) {

                            echo htmlspecialchars($metodo);

                        } else {

                            echo "No registrado";

                        }

                        ?>

                    </div>


                    <div class="info-box">

                        <strong>Estado del pago</strong>

                        <?php

                        if ($pedido['estado_pago']) {

                            echo htmlspecialchars($pedido['estado_pago']);

                        } else {

                            echo "No registrado";

                        }

                        ?>

                    </div>

                </div>


                <!-- PRODUCTOS -->

                <div class="productos">

                    <h3>Productos</h3>

                    <?php

                    $sqlDetalle = "
                        SELECT 
                            nombre_producto,
                            nombre_variante,
                            precio_unitario,
                            cantidad,
                            subtotal
                        FROM detalle_pedido
                        WHERE pedido_id = ?
                    ";

                    $stmtDetalle = $conn->prepare($sqlDetalle);

                    $stmtDetalle->bind_param("i", $pedido['id']);

                    $stmtDetalle->execute();

                    $resultDetalle = $stmtDetalle->get_result();

                    ?>

                    <?php while ($detalle = $resultDetalle->fetch_assoc()): ?>

                        <div class="producto">

                            <div>

                                <strong>
                                    <?= htmlspecialchars(
                                        $detalle['nombre_producto']
                                    ) ?>
                                </strong>

                                <?php if (!empty($detalle['nombre_variante'])): ?>

                                    <br>

                                    <small>
                                        <?= htmlspecialchars(
                                            $detalle['nombre_variante']
                                        ) ?>
                                    </small>

                                <?php endif; ?>

                                <br>

                                <small>
                                    Cantidad:
                                    <?= (int)$detalle['cantidad'] ?>
                                </small>

                            </div>


                            <div>

                                S/
                                <?= number_format(
                                    $detalle['subtotal'],
                                    2
                                ) ?>

                            </div>

                        </div>

                    <?php endwhile; ?>

                </div>


                <!-- TOTALES -->
                              <a
                               href="detalle.php?id=<?= (int)$pedido['id'] ?>"
                             style="
                                display:inline-block;
                                margin-top:15px;
                                padding:10px 18px;
                                background:#333;
                                color:white;
                                text-decoration:none;
                                border-radius:10px;
    "
>
    Ver detalle
</a>

                <div class="totales">

                    <p>
                        Subtotal:
                        S/
                        <?= number_format(
                            $pedido['subtotal'],
                            2
                        ) ?>
                    </p>

                    <p>
                        Envío:
                        S/
                        <?= number_format(
                            $pedido['costo_envio'],
                            2
                        ) ?>
                    </p>

                    <p class="total">

                        Total:
                        S/
                        <?= number_format(
                            $pedido['total'],
                            2
                        ) ?>

                    </p>

                </div>

            </div>

        <?php endwhile; ?>

    <?php endif; ?>

</div>

</body>

</html>