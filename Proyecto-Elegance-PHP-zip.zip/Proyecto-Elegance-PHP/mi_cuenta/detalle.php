<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";


// Verificar que el usuario haya iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}


$usuarioId = $_SESSION['usuario_id'];


// Obtener el ID del pedido desde la URL
$pedidoId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($pedidoId <= 0) {
    die("Pedido no válido.");
}


// Buscar el cliente relacionado con el usuario
$sqlCliente = "
    SELECT id
    FROM clientes
    WHERE usuario_id = ?
";

$stmtCliente = $conn->prepare($sqlCliente);
$stmtCliente->bind_param("i", $usuarioId);
$stmtCliente->execute();

$resultCliente = $stmtCliente->get_result();
$cliente = $resultCliente->fetch_assoc();


if (!$cliente) {
    die("No se encontró información del cliente.");
}

$clienteId = $cliente['id'];


// Buscar el pedido
// Importante: también comprobamos cliente_id
// para evitar que un usuario vea el pedido de otra persona.
$sqlPedido = "
    SELECT
        p.id,
        p.codigo,
        p.direccion_entrega,
        p.subtotal,
        p.costo_envio,
        p.total,
        p.estado,
        p.creado_en,
        pg.metodo AS metodo_pago,
        pg.estado AS estado_pago
    FROM pedidos p
    LEFT JOIN pagos pg
        ON pg.pedido_id = p.id
    WHERE p.id = ?
      AND p.cliente_id = ?
    LIMIT 1
";

$stmtPedido = $conn->prepare($sqlPedido);
$stmtPedido->bind_param("ii", $pedidoId, $clienteId);
$stmtPedido->execute();

$resultPedido = $stmtPedido->get_result();
$pedido = $resultPedido->fetch_assoc();


if (!$pedido) {
    die("No se encontró el pedido o no tienes permiso para verlo.");
}


// Buscar los productos del pedido
$sqlDetalle = "
    SELECT
        nombre_producto,
        nombre_variante,
        precio_unitario,
        cantidad,
        subtotal
    FROM detalle_pedido
    WHERE pedido_id = ?
    ORDER BY id ASC
";

$stmtDetalle = $conn->prepare($sqlDetalle);
$stmtDetalle->bind_param("i", $pedidoId);
$stmtDetalle->execute();

$resultDetalle = $stmtDetalle->get_result();

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Detalle del pedido - Elegance
    </title>

    <link
        rel="stylesheet"
        href="../estilos.css"
    >

    <style>

        body {
            background: #f8f5f2;
        }

        .contenedor-detalle {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            text-decoration: none;
        }

        .pedido-detalle {
            background: white;
            border-radius: 18px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        .cabecera {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            border-bottom: 1px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 25px;
        }

        .codigo {
            font-size: 22px;
            font-weight: bold;
        }

        .estado {
            background: #f1e5d8;
            padding: 8px 16px;
            border-radius: 20px;
        }

        .informacion {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(220px, 1fr)
            );
            gap: 15px;
            margin-bottom: 30px;
        }

        .info-box {
            background: #fafafa;
            padding: 16px;
            border-radius: 12px;
        }

        .info-box strong {
            display: block;
            margin-bottom: 7px;
        }

        .productos {
            margin-top: 20px;
        }

        .producto {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }

        .producto:last-child {
            border-bottom: none;
        }

        .producto-nombre {
            font-weight: bold;
        }

        .producto-precio {
            white-space: nowrap;
            font-weight: bold;
        }

        .totales {
            margin-top: 25px;
            border-top: 1px solid #eee;
            padding-top: 20px;
            text-align: right;
        }

        .total {
            font-size: 22px;
            font-weight: bold;
        }

        .boton-whatsapp {
            display: inline-block;
            margin-top: 25px;
            padding: 12px 20px;
            background: #25D366;
            color: white;
            text-decoration: none;
            border-radius: 10px;
        }

    </style>

</head>


<body>


<div class="contenedor-detalle">


    <a
        href="pedidos.php"
        class="volver"
    >
        ← Volver a mis pedidos
    </a>


    <div class="pedido-detalle">


        <!-- CABECERA -->

        <div class="cabecera">

            <div>

                <div class="codigo">

                    Pedido:
                    <?= htmlspecialchars($pedido['codigo']) ?>

                </div>

                <small>

                    Fecha:
                    <?= htmlspecialchars($pedido['creado_en']) ?>

                </small>

            </div>


            <div class="estado">

                Estado:
                <?= htmlspecialchars($pedido['estado']) ?>

            </div>

        </div>



        <!-- INFORMACIÓN DEL PEDIDO -->

        <div class="informacion">


            <div class="info-box">

                <strong>
                    Dirección de entrega
                </strong>

                <?= htmlspecialchars(
                    $pedido['direccion_entrega']
                ) ?>

            </div>


            <div class="info-box">

                <strong>
                    Método de pago
                </strong>

                <?php

                $metodo = $pedido['metodo_pago'];

                if ($metodo === 'yape') {

                    echo "Yape";

                } elseif ($metodo === 'plin') {

                    echo "Plin";

                } elseif ($metodo === 'transferencia') {

                    echo "Transferencia bancaria";

                } elseif ($metodo === 'tarjeta_simulada') {

                    echo "Tarjeta";

                } elseif ($metodo === 'contraentrega') {

                    echo "Contra entrega";

                } elseif ($metodo) {

                    echo htmlspecialchars($metodo);

                } else {

                    echo "No registrado";

                }

                ?>

            </div>


            <div class="info-box">

                <strong>
                    Estado del pago
                </strong>

                <?php

                if ($pedido['estado_pago']) {

                    echo htmlspecialchars(
                        $pedido['estado_pago']
                    );

                } else {

                    echo "No registrado";

                }

                ?>

            </div>


        </div>



        <!-- PRODUCTOS -->

        <div class="productos">

            <h2>
                Productos del pedido
            </h2>


            <?php while ($detalle = $resultDetalle->fetch_assoc()): ?>


                <div class="producto">


                    <div>

                        <div class="producto-nombre">

                            <?= htmlspecialchars(
                                $detalle['nombre_producto']
                            ) ?>

                        </div>


                        <?php if (!empty(
                            $detalle['nombre_variante']
                        )): ?>

                            <small>

                                Variante:
                                <?= htmlspecialchars(
                                    $detalle['nombre_variante']
                                ) ?>

                            </small>

                        <?php endif; ?>


                        <br>


                        <small>

                            Cantidad:
                            <?= (int)$detalle['cantidad'] ?>

                        </small>


                        <br>


                        <small>

                            Precio unitario:
                            S/
                            <?= number_format(
                                $detalle['precio_unitario'],
                                2
                            ) ?>

                        </small>

                    </div>


                    <div class="producto-precio">

                        S/
                        <?= number_format(
                            $detalle['subtotal'],
                            2
                        ) ?>

                    </div>


                </div>


            <?php endwhile; ?>


        </div>



        <!-- TOTALES -->

        <div class="totales">


            <p>

                Subtotal:
                S/
                <?= number_format(
                    $pedido['subtotal'],
                    2
                ) ?>

            </p>


            <p>

                Envío:
                S/
                <?= number_format(
                    $pedido['costo_envio'],
                    2
                ) ?>

            </p>


            <p class="total">

                Total:
                S/
                <?= number_format(
                    $pedido['total'],
                    2
                ) ?>

            </p>


        </div>


    </div>


</div>


</body>

</html>