<?php

require_once "../includes/conexion.php";

header("Content-Type: application/json; charset=utf-8");

$sql = "
    SELECT id, pregunta, respuesta
    FROM preguntas_frecuentes
    WHERE activo = 1
    ORDER BY id ASC
";

$resultado = $conn->query($sql);

$preguntas = [];

if ($resultado) {

    while ($fila = $resultado->fetch_assoc()) {
        $preguntas[] = [
            "id" => (int)$fila["id"],
            "pregunta" => $fila["pregunta"],
            "respuesta" => $fila["respuesta"]
        ];
    }

    echo json_encode($preguntas, JSON_UNESCAPED_UNICODE);

} else {

    echo json_encode([
        "error" => "No se pudieron obtener las preguntas frecuentes."
    ], JSON_UNESCAPED_UNICODE);
}