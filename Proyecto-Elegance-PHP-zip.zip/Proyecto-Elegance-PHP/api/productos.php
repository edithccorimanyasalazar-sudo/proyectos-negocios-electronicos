<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../includes/conexion.php';
try{
$sql="SELECT p.id producto_id,p.nombre producto,p.descripcion,c.nombre categoria,
v.id variante_id,v.nombre variante,v.material,v.talla,v.color,v.precio,v.stock,
GROUP_CONCAT(DISTINCT pi.url ORDER BY pi.orden SEPARATOR '|') imagenes
FROM productos p JOIN categorias c ON c.id=p.categoria_id JOIN variantes v ON v.producto_id=p.id
LEFT JOIN producto_imagenes pi ON pi.producto_id=p.id
WHERE p.activo=1 AND v.activo=1
GROUP BY p.id,p.nombre,p.descripcion,c.nombre,v.id,v.nombre,v.material,v.talla,v.color,v.precio,v.stock
ORDER BY p.id,v.id";
$r=$conn->query($sql);$productos=[];
while($f=$r->fetch_assoc()){
$id=(int)$f['producto_id'];
if(!isset($productos[$id]))$productos[$id]=['id'=>$id,'cat'=>strtolower($f['categoria']),'name'=>$f['producto'],'price'=>(float)$f['precio'],'images'=>$f['imagenes']?explode('|',$f['imagenes']):[],'variants'=>[]];
$productos[$id]['variants'][]=['id'=>(int)$f['variante_id'],'title'=>$f['variante'],'medida'=>$f['talla']??'','material'=>$f['material']??'','colors'=>$f['color']?array_map('trim',explode(',',$f['color'])):[],'price'=>(float)$f['precio'],'stock'=>(int)$f['stock']];
}
echo json_encode(array_values($productos),JSON_UNESCAPED_UNICODE);
}catch(Throwable $e){http_response_code(500);echo json_encode(['mensaje'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);}