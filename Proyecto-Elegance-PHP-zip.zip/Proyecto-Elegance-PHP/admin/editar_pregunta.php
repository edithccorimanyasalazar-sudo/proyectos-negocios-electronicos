<?php

require_once "../includes/conexion.php";
require_once "../includes/sesion.php";

// Verificar sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar que sea administrador
$usuarioId = $_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$resultadoUsuario = $stmtUsuario->get_result();
$usuario = $resultadoUsuario->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso no autorizado.");
}


// Obtener ID de la pregunta
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    die("Pregunta no válida.");
}


// Buscar la pregunta
$stmt = $conn->prepare("
    SELECT id, pregunta, respuesta
    FROM preguntas_frecuentes
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$resultado = $stmt->get_result();
$pregunta = $resultado->fetch_assoc();

if (!$pregunta) {
    die("La pregunta no existe.");
}

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Editar pregunta - Elegance</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f8f5f2;
            margin: 0;
            padding: 30px;
        }

        .contenedor {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
        }

        h1 {
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 20px;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input,
        textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        button {
            margin-top: 20px;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background: #222;
            color: white;
        }

        .volver {
            display: inline-block;
            margin-left: 10px;
            text-decoration: none;
            color: #555;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <h1>Editar pregunta</h1>

    <form action="actualizar_pregunta.php"
          method="POST">

        <input
            type="hidden"
            name="id"
            value="<?= $pregunta['id'] ?>"
        >

        <label for="pregunta">
            Pregunta
        </label>

        <input
            type="text"
            id="pregunta"
            name="pregunta"
            maxlength="255"
            required
            value="<?= htmlspecialchars($pregunta['pregunta']) ?>"
        >

        <label for="respuesta">
            Respuesta
        </label>

        <textarea
            id="respuesta"
            name="respuesta"
            required
        ><?= htmlspecialchars($pregunta['respuesta']) ?></textarea>

        <button type="submit">
            Guardar cambios
        </button>

        <a
            href="preguntas.php"
            class="volver"
        >
            Cancelar
        </a>

    </form>

</div>

</body>

</html>