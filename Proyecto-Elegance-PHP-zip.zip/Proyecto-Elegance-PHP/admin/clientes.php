```php
<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

$usuarioId = (int)$_SESSION['usuario_id'];

/* Verificar que el usuario sea administrador */
$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || trim($usuario['rol']) !== 'admin') {
    die("Acceso denegado.");
}


/* Obtener clientes */
$sql = "
SELECT
    c.id AS cliente_id,
    u.nombre,
    u.email,
    u.creado_en,
    COUNT(p.id) AS cantidad_pedidos

FROM clientes c

INNER JOIN usuarios u
    ON u.id = c.usuario_id

LEFT JOIN pedidos p
    ON p.cliente_id = c.id

GROUP BY
    c.id,
    u.nombre,
    u.email,
    u.creado_en

ORDER BY c.id DESC
";

$resultado = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Clientes | Elegance Admin</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f7f3f5;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .contenedor {
            max-width: 1100px;
            margin: auto;
        }

        h1 {
            color: #7d5260;
            margin-bottom: 25px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            color: #7d5260;
            text-decoration: none;
            font-weight: bold;
        }

        .tarjeta {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #f8eef2;
            color: #7d5260;
        }

        .cantidad {
            font-weight: bold;
            color: #7d5260;
        }

        .sin-pedidos {
            color: #777;
        }

        .boton {
            display: inline-block;
            background: #7d5260;
            color: white;
            padding: 8px 12px;
            border-radius: 7px;
            text-decoration: none;
        }

        .boton:hover {
            opacity: 0.9;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <a class="volver" href="index.php">
        ← Volver al panel
    </a>

    <h1>
        👥 Clientes
    </h1>

    <div class="tarjeta">

        <table>

            <thead>

                <tr>

                    <th>Nombre</th>

                    <th>Correo</th>

                    <th>Fecha de registro</th>

                    <th>Pedidos</th>

                    <th>Acción</th>

                </tr>

            </thead>

            <tbody>

            <?php if ($resultado && $resultado->num_rows > 0): ?>

                <?php while ($cliente = $resultado->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= htmlspecialchars(
                                $cliente['nombre']
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $cliente['email']
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $cliente['creado_en']
                            ) ?>
                        </td>

                        <td>

                            <?php if (
                                (int)$cliente['cantidad_pedidos'] > 0
                            ): ?>

                                <span class="cantidad">
                                    <?= (int)$cliente['cantidad_pedidos'] ?>
                                </span>

                            <?php else: ?>

                                <span class="sin-pedidos">
                                    0
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <a
                                class="boton"
                                href="detalle_cliente.php?id=<?= (int)$cliente['cliente_id'] ?>"
                            >
                                Ver cliente
                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="5">
                        No hay clientes registrados.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>
```
