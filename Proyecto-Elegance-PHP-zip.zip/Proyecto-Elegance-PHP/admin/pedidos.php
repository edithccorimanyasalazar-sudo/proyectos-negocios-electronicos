<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";


/* =========================================
   VERIFICAR SESIÓN
========================================= */

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}


$usuarioId = $_SESSION['usuario_id'];


/* =========================================
   VERIFICAR QUE SEA ADMIN
========================================= */

$sqlUsuario = "
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
";

$stmtUsuario = $conn->prepare($sqlUsuario);
$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$resultUsuario = $stmtUsuario->get_result();
$usuario = $resultUsuario->fetch_assoc();


if (!$usuario) {
    session_destroy();

    header("Location: ../auth/login.php");

    exit;
}


if ($usuario['rol'] !== 'admin') {

    http_response_code(403);

    die("
        <h2>Acceso denegado</h2>
        <p>Esta sección es solo para administradores.</p>
    ");
}


/* =========================================
   OBTENER TODOS LOS PEDIDOS
========================================= */

$sqlPedidos = "
    SELECT
        p.id,
        p.codigo,
        p.direccion_entrega,
        p.subtotal,
        p.costo_envio,
        p.total,
        p.estado,
        p.creado_en,

        u.nombre AS cliente_nombre,
        u.email AS cliente_email,

        pg.metodo AS metodo_pago,
        pg.estado AS estado_pago

    FROM pedidos p

    INNER JOIN clientes c
        ON c.id = p.cliente_id

    INNER JOIN usuarios u
        ON u.id = c.usuario_id

    LEFT JOIN pagos pg
        ON pg.pedido_id = p.id

    ORDER BY p.id DESC
";


$resultPedidos = $conn->query($sqlPedidos);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Administrar pedidos - Elegance
    </title>

    <link
        rel="stylesheet"
        href="../estilos.css"
    >

    <style>

        body {
            background: #f8f5f2;
        }

        .admin-contenedor {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
        }

        .encabezado {
            background: white;
            padding: 25px;
            border-radius: 18px;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .encabezado h1 {
            margin-top: 0;
        }

        .tabla-contenedor {
            background: white;
            border-radius: 18px;
            padding: 20px;
            overflow-x: auto;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 900px;
        }

        th {
            background: #f1e5d8;
            padding: 14px;
            text-align: left;
        }

        td {
            padding: 14px;
            border-bottom: 1px solid #eee;
            vertical-align: top;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .estado {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            background: #f1e5d8;
            font-size: 13px;
        }

        .pago {
            font-size: 13px;
            color: #555;
        }

        .boton {
            display: inline-block;
            padding: 8px 13px;
            background: #333;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 13px;
        }

        .boton:hover {
            opacity: 0.85;
        }

        .sin-pedidos {
            text-align: center;
            padding: 40px;
        }

        .volver {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
        }

    </style>

</head>


<body>


<div class="admin-contenedor">


    <!-- ENCABEZADO -->

    <div class="encabezado">

        <h1>
            📦 Pedidos
        </h1>

        <p>
            Desde aquí puedes consultar los pedidos
            realizados por los clientes.
        </p>

        <p>
            Administrador:
            <strong>
                <?= htmlspecialchars($usuario['nombre']) ?>
            </strong>
        </p>

    </div>


    <!-- TABLA -->

    <div class="tabla-contenedor">


        <?php if ($resultPedidos->num_rows === 0): ?>


            <div class="sin-pedidos">

                <h2>
                    No hay pedidos registrados
                </h2>

                <p>
                    Cuando un cliente realice una compra,
                    aparecerá aquí.
                </p>

            </div>


        <?php else: ?>


            <table>


                <thead>

                    <tr>

                        <th>
                            Pedido
                        </th>

                        <th>
                            Cliente
                        </th>

                        <th>
                            Fecha
                        </th>

                        <th>
                            Total
                        </th>

                        <th>
                            Pago
                        </th>

                        <th>
                            Estado
                        </th>

                        <th>
                            Acción
                        </th>

                    </tr>

                </thead>


                <tbody>


                    <?php while (
                        $pedido = $resultPedidos->fetch_assoc()
                    ): ?>


                        <tr>


                            <!-- PEDIDO -->

                            <td>

                                <strong>
                                    <?= htmlspecialchars(
                                        $pedido['codigo']
                                    ) ?>
                                </strong>

                                <br>

                                <small>
                                    ID:
                                    <?= (int)$pedido['id'] ?>
                                </small>

                            </td>


                            <!-- CLIENTE -->

                            <td>

                                <strong>
                                    <?= htmlspecialchars(
                                        $pedido['cliente_nombre']
                                    ) ?>
                                </strong>

                                <br>

                                <small>
                                    <?= htmlspecialchars(
                                        $pedido['cliente_email']
                                    ) ?>
                                </small>

                            </td>


                            <!-- FECHA -->

                            <td>

                                <?= htmlspecialchars(
                                    $pedido['creado_en']
                                ) ?>

                            </td>


                            <!-- TOTAL -->

                            <td>

                                <strong>
                                    S/
                                    <?= number_format(
                                        $pedido['total'],
                                        2
                                    ) ?>
                                </strong>

                            </td>


                            <!-- PAGO -->

                            <td>

                                <div class="pago">

                                    <?php

                                    $metodo =
                                        $pedido['metodo_pago'];

                                    if ($metodo === 'yape') {

                                        echo "Yape";

                                    } elseif (
                                        $metodo === 'plin'
                                    ) {

                                        echo "Plin";

                                    } elseif (
                                        $metodo === 'transferencia'
                                    ) {

                                        echo "Transferencia";

                                    } elseif (
                                        $metodo === 'tarjeta_simulada'
                                    ) {

                                        echo "Tarjeta";

                                    } elseif (
                                        $metodo === 'contraentrega'
                                    ) {

                                        echo "Contra entrega";

                                    } elseif ($metodo) {

                                        echo htmlspecialchars(
                                            $metodo
                                        );

                                    } else {

                                        echo "No registrado";

                                    }

                                    ?>

                                    <br>

                                    Estado:

                                    <?= $pedido['estado_pago']
                                        ? htmlspecialchars(
                                            $pedido['estado_pago']
                                        )
                                        : 'No registrado'
                                    ?>

                                </div>

                            </td>


                            <!-- ESTADO -->

                            <td>

                                <span class="estado">

                                    <?= htmlspecialchars(
                                        $pedido['estado']
                                    ) ?>

                                </span>

                            </td>


                            <!-- ACCIÓN -->

                            <td>

                                <a
                                    class="boton"
                                    href="detalle_pedido.php?id=<?= (int)$pedido['id'] ?>"
                                >
                                    Ver detalle
                                </a>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                </tbody>


            </table>


        <?php endif; ?>


    </div>


    <a
        href="index.php"
        class="volver"
    >
        ← Volver al panel
    </a>


</div>


</body>

</html>