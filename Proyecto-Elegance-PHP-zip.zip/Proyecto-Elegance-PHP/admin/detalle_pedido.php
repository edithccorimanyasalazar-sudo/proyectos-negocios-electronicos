<?php
require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar que sea administrador
$usuarioId = (int)$_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("SELECT nombre, email, rol FROM usuarios WHERE id = ? LIMIT 1");
$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}

// Obtener ID del pedido
$pedidoId = isset($_GET['id'])
    ? (int)$_GET['id']
    : (int)($_POST['pedido_id'] ?? 0);

if ($pedidoId <= 0) {
    die("Pedido no válido.");
}


// ==========================================
// CAMBIAR ESTADO DEL PEDIDO
// ==========================================

$estadosPermitidos = [
    'pendiente',
    'confirmado',
    'preparando',
    'enviado',
    'entregado',
    'cancelado'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nuevoEstado = $_POST['estado'] ?? '';

    if (!in_array($nuevoEstado, $estadosPermitidos, true)) {
        die("Estado no válido.");
    }

    $sqlActualizar = "UPDATE pedidos SET estado = ? WHERE id = ?";

    $stmtActualizar = $conn->prepare($sqlActualizar);
    $stmtActualizar->bind_param("si", $nuevoEstado, $pedidoId);
    $stmtActualizar->execute();

    header("Location: detalle_pedido.php?id=" . $pedidoId . "&actualizado=1");
    exit;
}


// ==========================================
// OBTENER INFORMACIÓN DEL PEDIDO
// ==========================================

$sqlPedido = "
SELECT 
    p.id,
    p.codigo,
    p.direccion_entrega,
    p.subtotal,
    p.costo_envio,
    p.total,
    p.estado,
    p.creado_en,

    u.nombre AS cliente_nombre,
    u.email AS cliente_email,

    pg.metodo AS metodo_pago,
    pg.estado AS estado_pago

FROM pedidos p

INNER JOIN clientes c 
    ON c.id = p.cliente_id

INNER JOIN usuarios u 
    ON u.id = c.usuario_id

LEFT JOIN pagos pg 
    ON pg.pedido_id = p.id

WHERE p.id = ?

LIMIT 1
";

$stmtPedido = $conn->prepare($sqlPedido);
$stmtPedido->bind_param("i", $pedidoId);
$stmtPedido->execute();

$pedido = $stmtPedido->get_result()->fetch_assoc();

if (!$pedido) {
    die("El pedido no existe.");
}


// ==========================================
// OBTENER PRODUCTOS DEL PEDIDO
// ==========================================

$sqlDetalle = "
SELECT
    nombre_producto,
    nombre_variante,
    precio_unitario,
    cantidad,
    subtotal
FROM detalle_pedido
WHERE pedido_id = ?
ORDER BY id ASC
";

$stmtDetalle = $conn->prepare($sqlDetalle);
$stmtDetalle->bind_param("i", $pedidoId);
$stmtDetalle->execute();

$detalles = $stmtDetalle->get_result();


// Nombres de métodos de pago
$metodosPago = [
    'yape' => 'Yape',
    'plin' => 'Plin',
    'transferencia' => 'Transferencia',
    'tarjeta_simulada' => 'Tarjeta',
    'contraentrega' => 'Contra entrega'
];
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detalle del pedido | Elegance Admin</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f7f3f5;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .contenedor {
            max-width: 1000px;
            margin: auto;
        }

        h1 {
            color: #7d5260;
            margin-bottom: 25px;
        }

        .tarjeta {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .tarjeta h2 {
            margin-top: 0;
            color: #7d5260;
        }

        .dato {
            margin: 8px 0;
        }

        .estado {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 20px;
            background: #f0e1e7;
            color: #7d5260;
            font-weight: bold;
        }

        select {
            width: 100%;
            max-width: 350px;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
            margin-bottom: 12px;
        }

        button {
            background: #7d5260;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
        }

        button:hover {
            opacity: 0.9;
        }

        .mensaje-exito {
            background: #dff3e4;
            color: #246b3c;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #f8eef2;
            color: #7d5260;
        }

        .total {
            text-align: right;
            margin-top: 20px;
            font-size: 18px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            color: #7d5260;
            text-decoration: none;
            font-weight: bold;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <a class="volver" href="pedidos.php">
        ← Volver a pedidos
    </a>

    <h1>Detalle del pedido</h1>


    <?php if (isset($_GET['actualizado'])): ?>

        <div class="mensaje-exito">
            Estado del pedido actualizado correctamente.
        </div>

    <?php endif; ?>


    <!-- INFORMACIÓN DEL PEDIDO -->

    <div class="tarjeta">

        <h2>📦 Información del pedido</h2>

        <p class="dato">
            <strong>Código:</strong>
            <?= htmlspecialchars($pedido['codigo']) ?>
        </p>

        <p class="dato">
            <strong>Fecha:</strong>
            <?= htmlspecialchars($pedido['creado_en']) ?>
        </p>

        <p class="dato">
            <strong>Estado actual:</strong>

            <span class="estado">
                <?= htmlspecialchars($pedido['estado']) ?>
            </span>
        </p>

        <p class="dato">
            <strong>Dirección:</strong>
            <?= htmlspecialchars($pedido['direccion_entrega']) ?>
        </p>

    </div>


    <!-- CAMBIAR ESTADO -->

    <div class="tarjeta">

        <h2>⚙️ Cambiar estado del pedido</h2>

        <form method="POST">

            <input
                type="hidden"
                name="pedido_id"
                value="<?= (int)$pedido['id'] ?>"
            >

            <select name="estado" required>

                <?php foreach ($estadosPermitidos as $estado): ?>

                    <option
                        value="<?= htmlspecialchars($estado) ?>"
                        <?= $pedido['estado'] === $estado ? 'selected' : '' ?>
                    >
                        <?= ucfirst($estado) ?>
                    </option>

                <?php endforeach; ?>

            </select>

            <br>

            <button type="submit">
                Guardar estado
            </button>

        </form>

    </div>


    <!-- CLIENTE -->

    <div class="tarjeta">

        <h2>👤 Cliente</h2>

        <p class="dato">
            <strong>Nombre:</strong>
            <?= htmlspecialchars($pedido['cliente_nombre']) ?>
        </p>

        <p class="dato">
            <strong>Email:</strong>
            <?= htmlspecialchars($pedido['cliente_email']) ?>
        </p>

    </div>


    <!-- PAGO -->

    <div class="tarjeta">

        <h2>💳 Pago</h2>

        <p class="dato">
            <strong>Método:</strong>

            <?= htmlspecialchars(
                $metodosPago[$pedido['metodo_pago']] 
                ?? $pedido['metodo_pago']
            ) ?>
        </p>

        <p class="dato">
            <strong>Estado del pago:</strong>

            <?= htmlspecialchars($pedido['estado_pago'] ?? 'Sin registro') ?>
        </p>

    </div>


    <!-- PRODUCTOS -->

    <div class="tarjeta">

        <h2>🛍️ Productos</h2>

        <table>

            <thead>

                <tr>
                    <th>Producto</th>
                    <th>Variante</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>

            </thead>

            <tbody>

                <?php while ($detalle = $detalles->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= htmlspecialchars($detalle['nombre_producto']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($detalle['nombre_variante']) ?>
                        </td>

                        <td>
                            S/ <?= number_format($detalle['precio_unitario'], 2) ?>
                        </td>

                        <td>
                            <?= (int)$detalle['cantidad'] ?>
                        </td>

                        <td>
                            S/ <?= number_format($detalle['subtotal'], 2) ?>
                        </td>

                    </tr>

                <?php endwhile; ?>

            </tbody>

        </table>

    </div>


    <!-- TOTALES -->

    <div class="tarjeta">

        <h2>💰 Resumen</h2>

        <p class="dato">
            <strong>Subtotal:</strong>
            S/ <?= number_format($pedido['subtotal'], 2) ?>
        </p>

        <p class="dato">
            <strong>Envío:</strong>
            S/ <?= number_format($pedido['costo_envio'], 2) ?>
        </p>

        <div class="total">

            <strong>
                Total:
                S/ <?= number_format($pedido['total'], 2) ?>
            </strong>

        </div>

    </div>

</div>

</body>

</html>