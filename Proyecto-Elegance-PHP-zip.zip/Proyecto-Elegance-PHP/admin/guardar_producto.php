<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

// ==========================================
// VERIFICAR SESIÓN
// ==========================================

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// ==========================================
// VERIFICAR ADMIN
// ==========================================

$usuarioId = (int)$_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}

// ==========================================
// VERIFICAR POST
// ==========================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: productos.php");
    exit;
}

// ==========================================
// RECIBIR DATOS
// ==========================================

$nombre = trim($_POST['nombre'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$categoriaId = (int)($_POST['categoria_id'] ?? 0);

$varianteNombre = trim($_POST['variante_nombre'] ?? '');
$sku = trim($_POST['sku'] ?? '');

$precio = (float)($_POST['precio'] ?? 0);
$stock = (int)($_POST['stock'] ?? 0);

$material = trim($_POST['material'] ?? '');
$talla = trim($_POST['talla'] ?? '');
$color = trim($_POST['color'] ?? '');


// ==========================================
// VALIDAR DATOS
// ==========================================

if (
    $nombre === '' ||
    $categoriaId <= 0 ||
    $varianteNombre === '' ||
    $sku === '' ||
    $precio < 0 ||
    $stock < 0
) {
    die("Faltan datos obligatorios.");
}


// ==========================================
// VERIFICAR CATEGORÍA
// ==========================================

$stmtCategoria = $conn->prepare("
    SELECT id
    FROM categorias
    WHERE id = ?
    LIMIT 1
");

$stmtCategoria->bind_param("i", $categoriaId);
$stmtCategoria->execute();

$categoria = $stmtCategoria->get_result()->fetch_assoc();

if (!$categoria) {
    die("La categoría seleccionada no existe.");
}


// ==========================================
// VERIFICAR SKU
// ==========================================

$stmtSku = $conn->prepare("
    SELECT id
    FROM variantes
    WHERE sku = ?
    LIMIT 1
");

$stmtSku->bind_param("s", $sku);
$stmtSku->execute();

$skuExistente = $stmtSku->get_result()->fetch_assoc();

if ($skuExistente) {
    die("El SKU ya existe. Utiliza otro SKU.");
}


// ==========================================
// INICIAR TRANSACCIÓN
// ==========================================

$conn->begin_transaction();

try {

    // ======================================
    // 1. INSERTAR PRODUCTO
    // ======================================

    $stmtProducto = $conn->prepare("
        INSERT INTO productos
        (
            categoria_id,
            nombre,
            descripcion,
            activo
        )
        VALUES
        (
            ?,
            ?,
            ?,
            1
        )
    ");

    $stmtProducto->bind_param(
        "iss",
        $categoriaId,
        $nombre,
        $descripcion
    );

    if (!$stmtProducto->execute()) {
        throw new Exception(
            "No se pudo guardar el producto."
        );
    }

    // Obtener ID generado
    $productoId = $conn->insert_id;


    // ======================================
    // 2. INSERTAR VARIANTE
    // ======================================

    $stmtVariante = $conn->prepare("
        INSERT INTO variantes
        (
            producto_id,
            nombre,
            sku,
            material,
            talla,
            color,
            precio,
            stock,
            activo
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            1
        )
    ");

    $stmtVariante->bind_param(
        "isssssdi",
        $productoId,
        $varianteNombre,
        $sku,
        $material,
        $talla,
        $color,
        $precio,
        $stock
    );

    if (!$stmtVariante->execute()) {
        throw new Exception(
            "No se pudo guardar la variante."
        );
    }


    // ======================================
    // 3. GUARDAR IMÁGENES
    // ======================================

    if (
        isset($_FILES['imagenes']) &&
        !empty($_FILES['imagenes']['name'][0])
    ) {

        $carpetaImagenes = "../img/";

        if (!is_dir($carpetaImagenes)) {
            mkdir($carpetaImagenes, 0755, true);
        }

        $cantidadImagenes =
            count($_FILES['imagenes']['name']);

        for ($i = 0; $i < $cantidadImagenes; $i++) {

            // Comprobar error de subida
            if (
                $_FILES['imagenes']['error'][$i]
                !== UPLOAD_ERR_OK
            ) {
                continue;
            }

            $nombreOriginal =
                $_FILES['imagenes']['name'][$i];

            $archivoTemporal =
                $_FILES['imagenes']['tmp_name'][$i];

            // Obtener extensión
            $extension = strtolower(
                pathinfo(
                    $nombreOriginal,
                    PATHINFO_EXTENSION
                )
            );

            // Extensiones permitidas
            $permitidas = [
                'jpg',
                'jpeg',
                'png',
                'webp'
            ];

            if (!in_array($extension, $permitidas)) {
                continue;
            }

            // Crear nombre único
            $nombreArchivo =
                "producto_" .
                $productoId .
                "_" .
                time() .
                "_" .
                $i .
                "." .
                $extension;

            $rutaFisica =
                $carpetaImagenes .
                $nombreArchivo;

            // Mover archivo
            if (
                move_uploaded_file(
                    $archivoTemporal,
                    $rutaFisica
                )
            ) {

                // Ruta que se guardará en BD
                $urlImagen =
                    "img/" .
                    $nombreArchivo;

                // Orden de la imagen
                $orden = $i + 1;

                // Guardar en producto_imagenes
                $stmtImagen = $conn->prepare("
                    INSERT INTO producto_imagenes
                    (
                        producto_id,
                        url,
                        orden
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?
                    )
                ");

                $stmtImagen->bind_param(
                    "isi",
                    $productoId,
                    $urlImagen,
                    $orden
                );

                if (!$stmtImagen->execute()) {
                    throw new Exception(
                        "No se pudo guardar la imagen."
                    );
                }
            }
        }
    }


    // ======================================
    // CONFIRMAR
    // ======================================

    $conn->commit();


    // ======================================
    // VOLVER AL LISTADO
    // ======================================

    header(
        "Location: productos.php?creado=1"
    );

    exit;


} catch (Exception $e) {

    // Si algo falla, deshacer todo
    $conn->rollback();

    die(
        "Error al guardar el producto: " .
        htmlspecialchars($e->getMessage())
    );
}
?>
