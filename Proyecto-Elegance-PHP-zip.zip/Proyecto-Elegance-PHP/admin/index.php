<?php
require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

/* Si no hay sesión, ir al login (está dentro de auth/) */
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

$usuarioId = (int)$_SESSION['usuario_id'];

/* Verificar administrador */
$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");
$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();
$usuario = $stmtUsuario->get_result()->fetch_assoc();


if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}

/* Estadísticas */
$totalPedidos   = (int)$conn->query("SELECT COUNT(*) AS total FROM pedidos")->fetch_assoc()['total'];
$totalProductos = (int)$conn->query("SELECT COUNT(*) AS total FROM productos WHERE activo = 1")->fetch_assoc()['total'];
$totalClientes  = (int)$conn->query("SELECT COUNT(*) AS total FROM clientes")->fetch_assoc()['total'];
$totalPagos     = (int)$conn->query("SELECT COUNT(*) AS total FROM pagos")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel administrador | Elegance</title>
    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f3f5;
            color: #333;
        }

        .encabezado {
            background: #7d5260;
            color: white;
            padding: 25px 30px;
        }
        .encabezado-contenido { max-width: 1100px; margin: auto; }
        .encabezado h1 { margin: 0 0 8px; }
        .encabezado p { margin: 0; opacity: 0.9; }

        .contenedor {
            max-width: 1100px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .estadisticas {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 35px;
        }
        .estadistica {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            text-align: center;
        }
        .estadistica-icono { font-size: 35px; margin-bottom: 10px; }
        .estadistica-numero { font-size: 30px; font-weight: bold; color: #7d5260; }
        .estadistica-titulo { margin-top: 5px; color: #666; }

        h2 { color: #7d5260; margin-bottom: 20px; }

        .opciones {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        .opcion {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            text-decoration: none;
            color: #333;
            transition: 0.2s;
        }
        .opcion:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 18px rgba(0,0,0,0.12);
        }
        .opcion-icono { font-size: 35px; margin-bottom: 10px; }
        .opcion h3 { margin: 5px 0; color: #7d5260; }
        .opcion p { margin: 0; color: #666; line-height: 1.5; }

        .salir {
            display: inline-block;
            margin-top: 30px;
            background: #777;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
        }
        .salir:hover { opacity: 0.9; }

        @media (max-width: 800px) {
            .estadisticas { grid-template-columns: repeat(2, 1fr); }
            .opciones { grid-template-columns: 1fr; }
        }
        @media (max-width: 500px) {
            .estadisticas { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<header class="encabezado">
    <div class="encabezado-contenido">
        <h1>👑 Elegance</h1>
        <p>Panel de administración</p>
    </div>
</header>

<div class="contenedor">

    <h2>Hola, <?= htmlspecialchars($usuario['nombre']) ?> 👋</h2>

    <div class="estadisticas">
        <div class="estadistica">
            <div class="estadistica-icono">🛍️</div>
            <div class="estadistica-numero"><?= $totalPedidos ?></div>
            <div class="estadistica-titulo">Pedidos</div>
        </div>

        <div class="estadistica">
            <div class="estadistica-icono">📦</div>
            <div class="estadistica-numero"><?= $totalProductos ?></div>
            <div class="estadistica-titulo">Productos activos</div>
        </div>

        <div class="estadistica">
            <div class="estadistica-icono">👥</div>
            <div class="estadistica-numero"><?= $totalClientes ?></div>
            <div class="estadistica-titulo">Clientes</div>
        </div>

        <div class="estadistica">
            <div class="estadistica-icono">💳</div>
            <div class="estadistica-numero"><?= $totalPagos ?></div>
            <div class="estadistica-titulo">Pagos</div>
        </div>
    </div>

    <h2>Administración</h2>

    <div class="opciones">
        <a class="opcion" href="pedidos.php">
            <div class="opcion-icono">🛍️</div>
            <h3>Pedidos</h3>
            <p>Consultar pedidos, clientes, pagos y estados de cada compra.</p>
        </a>

        <a class="opcion" href="productos.php">
            <div class="opcion-icono">📦</div>
            <h3>Productos</h3>
            <p>Editar precios, controlar stock y activar o desactivar variantes.</p>
        </a>

        <a class="opcion" href="clientes.php">
            <div class="opcion-icono">👥</div>
            <h3>Clientes</h3>
            <p>Consultar clientes registrados y sus pedidos.</p>
        </a>

        <a class="opcion" href="pagos.php">
            <div class="opcion-icono">💳</div>
            <h3>Pagos</h3>
            <p>Consultar métodos, montos y estados de los pagos.</p>
        </a>
    </div>

    <a class="salir" href="../auth/logout.php">Cerrar sesión</a>

</div>

</body>
</html>