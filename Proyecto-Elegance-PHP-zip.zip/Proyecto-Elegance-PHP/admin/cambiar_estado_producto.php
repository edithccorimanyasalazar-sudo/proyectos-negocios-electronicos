<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";


// ==========================================
// VERIFICAR SESIÓN
// ==========================================

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}


// ==========================================
// VERIFICAR QUE SEA ADMIN
// ==========================================

$usuarioId = (int)$_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}


// ==========================================
// OBTENER ID DE LA VARIANTE
// ==========================================

$varianteId = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;

if ($varianteId <= 0) {
    die("Variante no válida.");
}


// ==========================================
// OBTENER ESTADO ACTUAL
// ==========================================

$sql = "
    SELECT activo
    FROM variantes
    WHERE id = ?
    LIMIT 1
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $varianteId);
$stmt->execute();

$resultado = $stmt->get_result();
$variante = $resultado->fetch_assoc();

if (!$variante) {
    die("La variante no existe.");
}


// ==========================================
// CAMBIAR ESTADO
// ==========================================

$estadoActual = (int)$variante['activo'];

$nuevoEstado = $estadoActual === 1 ? 0 : 1;

$sqlActualizar = "
    UPDATE variantes
    SET activo = ?
    WHERE id = ?
";

$stmtActualizar = $conn->prepare($sqlActualizar);

$stmtActualizar->bind_param(
    "ii",
    $nuevoEstado,
    $varianteId
);

$stmtActualizar->execute();


// ==========================================
// VOLVER A PRODUCTOS
// ==========================================

header("Location: productos.php?actualizado=1");

exit;

?>