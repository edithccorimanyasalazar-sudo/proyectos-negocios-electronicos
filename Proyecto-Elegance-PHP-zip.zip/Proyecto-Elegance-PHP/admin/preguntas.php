<?php
require_once "../includes/conexion.php";
require_once "../includes/sesion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar que sea administrador
$usuarioId = $_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$resultadoUsuario = $stmtUsuario->get_result();
$usuario = $resultadoUsuario->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso no autorizado.");
}

// Obtener preguntas
$resultado = $conn->query("
    SELECT id, pregunta, respuesta, activo, creado_en
    FROM preguntas_frecuentes
    ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Preguntas frecuentes - Administración</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 30px;
        }

        .contenedor {
            max-width: 1100px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
        }

        h1 {
            margin-top: 0;
        }

        .boton {
            display: inline-block;
            background: #222;
            color: white;
            padding: 10px 16px;
            text-decoration: none;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .tabla {
            width: 100%;
            border-collapse: collapse;
        }

        .tabla th,
        .tabla td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            vertical-align: top;
        }

        .tabla th {
            background: #eee;
        }

        .activo {
            color: green;
            font-weight: bold;
        }

        .inactivo {
            color: red;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="contenedor">

    <h1>Preguntas frecuentes del chatbot</h1>

    <a href="agregar_pregunta.php" class="boton">
        + Agregar pregunta
    </a>

    <?php if ($resultado && $resultado->num_rows > 0): ?>

        <table class="tabla">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Pregunta</th>
                    <th>Respuesta</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                </tr>
            </thead>

            <tbody>

                <?php while ($fila = $resultado->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <?= htmlspecialchars($fila['id']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($fila['pregunta']) ?>
                        </td>

                        <td>
                            <?= nl2br(htmlspecialchars($fila['respuesta'])) ?>
                        </td>

                        <td>

                            <?php if ($fila['activo'] == 1): ?>

                                <span class="activo">
                                    Activa
                                </span>

                            <?php else: ?>

                                <span class="inactivo">
                                    Inactiva
                                </span>

                            <?php endif; ?>

                        </td>

                        <td>
                            <?= htmlspecialchars($fila['creado_en']) ?>
                        </td>

                    </tr>

                <?php endwhile; ?>

            </tbody>

        </table>

    <?php else: ?>

        <p>
            Todavía no hay preguntas registradas.
        </p>

    <?php endif; ?>

</div>

</body>
</html>