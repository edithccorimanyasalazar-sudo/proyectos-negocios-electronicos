
<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

$usuarioId = (int)$_SESSION['usuario_id'];


/* Verificar que el usuario sea administrador */

$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}


/* Obtener pagos */

$sql = "
SELECT
    pg.id AS pago_id,
    pg.pedido_id,
    pg.metodo,
    pg.monto,
    pg.estado AS estado_pago,
    pg.creado_en,

    p.codigo AS codigo_pedido,
    p.estado AS estado_pedido,

    u.nombre AS cliente

FROM pagos pg

INNER JOIN pedidos p
    ON p.id = pg.pedido_id

INNER JOIN clientes c
    ON c.id = p.cliente_id

INNER JOIN usuarios u
    ON u.id = c.usuario_id

ORDER BY pg.id DESC
";

$resultado = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Pagos | Elegance Admin
    </title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f7f3f5;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .contenedor {
            max-width: 1200px;
            margin: auto;
        }

        h1 {
            color: #7d5260;
            margin-bottom: 25px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            color: #7d5260;
            text-decoration: none;
            font-weight: bold;
        }

        .tarjeta {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #f8eef2;
            color: #7d5260;
        }

        .monto {
            font-weight: bold;
        }

        .pendiente {
            color: #b7791f;
            font-weight: bold;
        }

        .pagado {
            color: #277a42;
            font-weight: bold;
        }

        .rechazado,
        .cancelado {
            color: #c0392b;
            font-weight: bold;
        }

        .boton {
            display: inline-block;
            background: #7d5260;
            color: white;
            padding: 8px 12px;
            border-radius: 7px;
            text-decoration: none;
        }

        .boton:hover {
            opacity: 0.9;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <a
        class="volver"
        href="index.php"
    >
        ← Volver al panel
    </a>


    <h1>
        💳 Pagos
    </h1>


    <div class="tarjeta">

        <table>

            <thead>

                <tr>

                    <th>
                        Pedido
                    </th>

                    <th>
                        Cliente
                    </th>

                    <th>
                        Método
                    </th>

                    <th>
                        Monto
                    </th>

                    <th>
                        Estado del pago
                    </th>

                    <th>
                        Fecha
                    </th>

                    <th>
                        Acción
                    </th>

                </tr>

            </thead>


            <tbody>

            <?php if (
                $resultado &&
                $resultado->num_rows > 0
            ): ?>

                <?php while (
                    $pago = $resultado->fetch_assoc()
                ): ?>

                    <tr>

                        <td>

                            <?= htmlspecialchars(
                                $pago['codigo_pedido']
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $pago['cliente']
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $pago['metodo']
                            ) ?>

                        </td>


                        <td class="monto">

                            S/

                            <?= number_format(
                                $pago['monto'],
                                2
                            ) ?>

                        </td>


                        <td>

                            <?php

                            $estadoPago = strtolower(
                                $pago['estado_pago']
                            );

                            ?>

                            <span
                                class="<?= htmlspecialchars(
                                    $estadoPago
                                ) ?>"
                            >

                                <?= htmlspecialchars(
                                    $pago['estado_pago']
                                ) ?>

                            </span>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $pago['creado_en']
                            ) ?>

                        </td>


                        <td>

                            <a
                                class="boton"
                                href="detalle_pedido.php?id=<?= (int)$pago['pedido_id'] ?>"
                            >
                                Ver pedido
                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td colspan="7">

                        No hay pagos registrados.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>
```
