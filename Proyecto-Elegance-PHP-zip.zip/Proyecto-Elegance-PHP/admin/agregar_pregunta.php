<?php
require_once "../includes/conexion.php";
require_once "../includes/sesion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar administrador
$usuarioId = $_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$resultadoUsuario = $stmtUsuario->get_result();
$usuario = $resultadoUsuario->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso no autorizado.");
}
?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Agregar pregunta</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 30px;
        }

        .contenedor {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }

        h1 {
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 20px;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input,
        textarea {
            width: 100%;
            padding: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        .botones {
            margin-top: 25px;
        }

        button,
        .cancelar {
            padding: 11px 18px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        button {
            background: #222;
            color: white;
        }

        .cancelar {
            background: #ddd;
            color: #222;
            margin-left: 8px;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <h1>Agregar pregunta al chatbot</h1>

    <form action="guardar_pregunta.php"
          method="POST">

        <label for="pregunta">
            Pregunta
        </label>

        <input
            type="text"
            id="pregunta"
            name="pregunta"
            maxlength="255"
            placeholder="Ejemplo: ¿Cuánto cuesta el envío?"
            required
        >

        <label for="respuesta">
            Respuesta
        </label>

        <textarea
            id="respuesta"
            name="respuesta"
            placeholder="Escribe la respuesta que dará el chatbot..."
            required
        ></textarea>

        <div class="botones">

            <button type="submit">
                Guardar pregunta
            </button>

            <a
                href="preguntas.php"
                class="cancelar"
            >
                Cancelar
            </a>

        </div>

    </form>

</div>

</body>

</html>