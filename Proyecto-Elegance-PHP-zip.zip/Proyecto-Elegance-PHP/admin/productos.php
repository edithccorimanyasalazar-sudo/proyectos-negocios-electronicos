<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";


// ==========================================
// VERIFICAR SESIÓN
// ==========================================

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}


// ==========================================
// VERIFICAR ADMIN
// ==========================================

$usuarioId = (int)$_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}


// ==========================================
// OBTENER PRODUCTOS Y VARIANTES
// ==========================================

$sql = "
SELECT
    p.id AS producto_id,
    p.nombre AS producto_nombre,
    p.descripcion,

    v.id AS variante_id,
    v.nombre AS variante_nombre,
    v.sku,
    v.precio,
    v.stock,
    v.activo

FROM productos p

INNER JOIN variantes v
    ON v.producto_id = p.id

ORDER BY p.id DESC, v.id ASC
";

$resultado = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Productos | Elegance Admin</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f7f3f5;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .contenedor {
            max-width: 1100px;
            margin: auto;
        }

        h1 {
            color: #7d5260;
            margin-bottom: 25px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            color: #7d5260;
            text-decoration: none;
            font-weight: bold;
        }

        .tarjeta {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        .mensaje {
            background: #dff3e4;
            color: #246b3c;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #f8eef2;
            color: #7d5260;
        }

        .stock {
            font-weight: bold;
        }

        .stock-bajo {
            color: #c0392b;
        }

        .stock-normal {
            color: #277a42;
        }

        .activo {
            color: #277a42;
            font-weight: bold;
        }

        .inactivo {
            color: #c0392b;
            font-weight: bold;
        }

        .precio {
            font-weight: bold;
        }

        .botones {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-editar {
            display: inline-block;
            background: #7d5260;
            color: white;
            padding: 8px 12px;
            border-radius: 7px;
            text-decoration: none;
        }

        .btn-estado {
            display: inline-block;
            background: #777;
            color: white;
            padding: 8px 12px;
            border-radius: 7px;
            text-decoration: none;
        }

        .btn-estado:hover,
        .btn-editar:hover {
            opacity: 0.9;
        }

    </style>

</head>

<body>

<div class="contenedor">


    <!-- VOLVER -->

    <a class="volver" href="index.php">
        ← Volver al panel
    </a>


    <!-- TÍTULO -->

    <h1>
        🛍️ Productos
    </h1>
    <a
    href="agregar_producto.php"
    style="
        display:inline-block;
        background:#7d5260;
        color:white;
        padding:10px 16px;
        border-radius:8px;
        text-decoration:none;
        margin-bottom:20px;
    "
>
    ➕ Nuevo producto
</a>


    <?php if (isset($_GET['creado'])): ?>

    <div class="mensaje">
        Producto agregado correctamente.
    </div>

    <?php endif; ?>


    <?php if (isset($_GET['actualizado'])): ?>

    <div class="mensaje">
        Producto actualizado correctamente.
    </div>

    <?php endif; ?>

    <div class="tarjeta">

        <table>

            <thead>

                <tr>

                    <th>Producto</th>

                    <th>Variante</th>

                    <th>SKU</th>

                    <th>Precio</th>

                    <th>Stock</th>

                    <th>Estado</th>

                    <th>Acción</th>

                </tr>

            </thead>


            <tbody>


            <?php if ($resultado->num_rows > 0): ?>


                <?php while ($producto = $resultado->fetch_assoc()): ?>


                    <tr>


                        <!-- PRODUCTO -->

                        <td>

                            <?= htmlspecialchars(
                                $producto['producto_nombre']
                            ) ?>

                        </td>


                        <!-- VARIANTE -->

                        <td>

                            <?= htmlspecialchars(
                                $producto['variante_nombre']
                            ) ?>

                        </td>


                        <!-- SKU -->

                        <td>

                            <?= htmlspecialchars(
                                $producto['sku']
                            ) ?>

                        </td>


                        <!-- PRECIO -->

                        <td class="precio">

                            S/
                            <?= number_format(
                                $producto['precio'],
                                2
                            ) ?>

                        </td>


                        <!-- STOCK -->

                        <td>

                            <?php if (
                                (int)$producto['stock'] <= 3
                            ): ?>

                                <span class="stock stock-bajo">

                                    <?= (int)$producto['stock'] ?>

                                    ⚠️

                                </span>

                            <?php else: ?>

                                <span class="stock stock-normal">

                                    <?= (int)$producto['stock'] ?>

                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- ESTADO -->

                        <td>

                            <?php if (
                                (int)$producto['activo'] === 1
                            ): ?>

                                <span class="activo">
                                    Activo
                                </span>

                            <?php else: ?>

                                <span class="inactivo">
                                    Inactivo
                                </span>

                            <?php endif; ?>

                        </td>


                        <!-- ACCIONES -->

                        <td>

                            <div class="botones">


                                <!-- EDITAR -->

                                <a
                                    class="btn-editar"
                                    href="editar_producto.php?id=<?= (int)$producto['variante_id'] ?>"
                                >
                                    Editar
                                </a>


                                <!-- ACTIVAR / DESACTIVAR -->

                                <a
                                    class="btn-estado"
                                    href="cambiar_estado_producto.php?id=<?= (int)$producto['variante_id'] ?>"
                                    onclick="return confirm('¿Deseas cambiar el estado de este producto?');"
                                >

                                    <?php if (
                                        (int)$producto['activo'] === 1
                                    ): ?>

                                        Desactivar

                                    <?php else: ?>

                                        Activar

                                    <?php endif; ?>

                                </a>


                            </div>

                        </td>


                    </tr>


                <?php endwhile; ?>


            <?php else: ?>


                <tr>

                    <td colspan="7">

                        No hay productos registrados.

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>

        </table>

    </div>

</div>

</body>

</html>