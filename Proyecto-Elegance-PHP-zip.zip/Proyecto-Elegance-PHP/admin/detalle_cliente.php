```php
<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

$usuarioId = (int)$_SESSION['usuario_id'];


/* Verificar administrador */

$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}


/* Obtener ID del cliente */

$clienteId = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;

if ($clienteId <= 0) {
    die("Cliente no válido.");
}


/* Obtener datos del cliente */

$stmtCliente = $conn->prepare("
    SELECT
        c.id AS cliente_id,
        u.nombre,
        u.email,
        u.creado_en

    FROM clientes c

    INNER JOIN usuarios u
        ON u.id = c.usuario_id

    WHERE c.id = ?

    LIMIT 1
");

$stmtCliente->bind_param("i", $clienteId);
$stmtCliente->execute();

$cliente = $stmtCliente->get_result()->fetch_assoc();

if (!$cliente) {
    die("Cliente no encontrado.");
}


/* Obtener pedidos */

$stmtPedidos = $conn->prepare("
    SELECT
        p.id,
        p.codigo,
        p.direccion_entrega,
        p.subtotal,
        p.costo_envio,
        p.total,
        p.estado,
        p.creado_en,

        pg.metodo AS metodo_pago,
        pg.estado AS estado_pago

    FROM pedidos p

    LEFT JOIN pagos pg
        ON pg.pedido_id = p.id

    WHERE p.cliente_id = ?

    ORDER BY p.id DESC
");

$stmtPedidos->bind_param("i", $clienteId);
$stmtPedidos->execute();

$pedidos = $stmtPedidos->get_result();

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Detalle del cliente | Elegance Admin
    </title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f7f3f5;
            margin: 0;
            padding: 30px;
            color: #333;
        }

        .contenedor {
            max-width: 1100px;
            margin: auto;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            color: #7d5260;
            text-decoration: none;
            font-weight: bold;
        }

        h1 {
            color: #7d5260;
            margin-bottom: 25px;
        }

        h2 {
            color: #7d5260;
        }

        .tarjeta {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
            margin-bottom: 25px;
            overflow-x: auto;
        }

        .datos p {
            margin: 10px 0;
        }

        .datos strong {
            color: #7d5260;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background: #f8eef2;
            color: #7d5260;
        }

        .estado {
            font-weight: bold;
        }

        .boton {
            display: inline-block;
            background: #7d5260;
            color: white;
            padding: 8px 12px;
            border-radius: 7px;
            text-decoration: none;
        }

        .boton:hover {
            opacity: 0.9;
        }

        .sin-pedidos {
            color: #777;
        }

    </style>

</head>

<body>

<div class="contenedor">

    <a
        class="volver"
        href="clientes.php"
    >
        ← Volver a clientes
    </a>


    <h1>
        👤 Detalle del cliente
    </h1>


    <!-- Datos del cliente -->

    <div class="tarjeta">

        <div class="datos">

            <p>

                <strong>
                    Nombre:
                </strong>

                <?= htmlspecialchars(
                    $cliente['nombre']
                ) ?>

            </p>


            <p>

                <strong>
                    Correo:
                </strong>

                <?= htmlspecialchars(
                    $cliente['email']
                ) ?>

            </p>


            <p>

                <strong>
                    Fecha de registro:
                </strong>

                <?= htmlspecialchars(
                    $cliente['creado_en']
                ) ?>

            </p>

        </div>

    </div>


    <!-- Pedidos del cliente -->

    <div class="tarjeta">

        <h2>
            🛍️ Pedidos realizados
        </h2>


        <?php if ($pedidos->num_rows > 0): ?>

            <table>

                <thead>

                    <tr>

                        <th>
                            Código
                        </th>

                        <th>
                            Fecha
                        </th>

                        <th>
                            Total
                        </th>

                        <th>
                            Pago
                        </th>

                        <th>
                            Estado
                        </th>

                        <th>
                            Acción
                        </th>

                    </tr>

                </thead>


                <tbody>

                <?php while (
                    $pedido = $pedidos->fetch_assoc()
                ): ?>

                    <tr>

                        <td>

                            <?= htmlspecialchars(
                                $pedido['codigo']
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $pedido['creado_en']
                            ) ?>

                        </td>


                        <td>

                            S/

                            <?= number_format(
                                $pedido['total'],
                                2
                            ) ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $pedido['metodo_pago']
                                ?? 'No registrado'
                            ) ?>

                        </td>


                        <td>

                            <span class="estado">

                                <?= htmlspecialchars(
                                    $pedido['estado']
                                ) ?>

                            </span>

                        </td>


                        <td>

                            <a
                                class="boton"
                                href="detalle_pedido.php?id=<?= (int)$pedido['id'] ?>"
                            >
                                Ver pedido
                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        <?php else: ?>

            <p class="sin-pedidos">

                Este cliente todavía no tiene
                pedidos registrados.

            </p>

        <?php endif; ?>

    </div>

</div>

</body>

</html>
```
