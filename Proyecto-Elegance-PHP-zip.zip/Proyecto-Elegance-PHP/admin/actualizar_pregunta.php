<?php

require_once "../includes/conexion.php";
require_once "../includes/sesion.php";

// Verificar sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar que sea administrador
$usuarioId = $_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$resultadoUsuario = $stmtUsuario->get_result();
$usuario = $resultadoUsuario->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso no autorizado.");
}


// Verificar que el formulario fue enviado
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: preguntas.php");
    exit;
}


// Obtener datos
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

$pregunta = trim($_POST['pregunta'] ?? '');

$respuesta = trim($_POST['respuesta'] ?? '');


// Validar
if ($id <= 0) {
    die("Pregunta no válida.");
}

if ($pregunta === '' || $respuesta === '') {
    die("La pregunta y la respuesta son obligatorias.");
}


// Actualizar
$stmt = $conn->prepare("
    UPDATE preguntas_frecuentes
    SET pregunta = ?, respuesta = ?
    WHERE id = ?
");

$stmt->bind_param(
    "ssi",
    $pregunta,
    $respuesta,
    $id
);


if (!$stmt->execute()) {
    die("Error al actualizar la pregunta: " . $stmt->error);
}


// Volver al listado
header("Location: preguntas.php?actualizado=1");
exit;