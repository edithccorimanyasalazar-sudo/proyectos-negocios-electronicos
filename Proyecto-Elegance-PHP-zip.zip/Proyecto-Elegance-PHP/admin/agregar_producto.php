<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

// ==========================================
// VERIFICAR SESIÓN
// ==========================================

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// ==========================================
// VERIFICAR ADMIN
// ==========================================

$usuarioId = (int)$_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}

// ==========================================
// OBTENER CATEGORÍAS
// ==========================================

$categorias = $conn->query("
    SELECT id, nombre
    FROM categorias
    ORDER BY nombre ASC
");

?>

<!DOCTYPE html>

<html lang="es">

<head>


<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Agregar producto | Elegance Admin</title>

<style>

    body {
        font-family: Arial, sans-serif;
        background: #f7f3f5;
        margin: 0;
        padding: 30px;
        color: #333;
    }

    .contenedor {
        max-width: 850px;
        margin: auto;
    }

    .volver {
        display: inline-block;
        margin-bottom: 20px;
        color: #7d5260;
        text-decoration: none;
        font-weight: bold;
    }

    h1 {
        color: #7d5260;
        margin-bottom: 25px;
    }

    .tarjeta {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    }

    .campo {
        margin-bottom: 18px;
    }

    label {
        display: block;
        margin-bottom: 7px;
        font-weight: bold;
        color: #555;
    }

    input,
    textarea,
    select {
        width: 100%;
        box-sizing: border-box;
        padding: 11px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 15px;
    }

    textarea {
        min-height: 100px;
        resize: vertical;
    }

    .fila {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .botones {
        display: flex;
        gap: 10px;
        margin-top: 25px;
    }

    .btn-guardar {
        border: none;
        background: #7d5260;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 15px;
    }

    .btn-cancelar {
        background: #777;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        text-decoration: none;
    }

    .btn-guardar:hover,
    .btn-cancelar:hover {
        opacity: 0.9;
    }

    .nota {
        background: #f8eef2;
        padding: 12px;
        border-radius: 8px;
        margin-bottom: 20px;
        color: #7d5260;
    }

    @media (max-width: 700px) {

        .fila {
            grid-template-columns: 1fr;
        }

    }

</style>


</head>

<body>

<div class="contenedor">

<a class="volver" href="productos.php">
    ← Volver a productos
</a>

<h1>
    ➕ Agregar nuevo producto
</h1>

<div class="tarjeta">

    <div class="nota">
        Completa los datos del nuevo producto. 
        Las imágenes se agregarán posteriormente.
    </div>

    <form
        action="guardar_producto.php"
        method="POST"
        enctype="multipart/form-data"
    >

        <!-- NOMBRE -->

        <div class="campo">

            <label for="nombre">
                Nombre del producto
            </label>

            <input
                type="text"
                id="nombre"
                name="nombre"
                placeholder="Ejemplo: Collar Estrella"
                required
            >

        </div>


        <!-- DESCRIPCIÓN -->

        <div class="campo">

            <label for="descripcion">
                Descripción
            </label>

            <textarea
                id="descripcion"
                name="descripcion"
                placeholder="Describe el producto..."
            ></textarea>

        </div>


        <!-- CATEGORÍA -->

        <div class="campo">

            <label for="categoria_id">
                Categoría
            </label>

            <select
                id="categoria_id"
                name="categoria_id"
                required
            >

                <option value="">
                    Seleccionar categoría
                </option>

                <?php while ($categoria = $categorias->fetch_assoc()): ?>

                    <option value="<?= (int)$categoria['id'] ?>">

                        <?= htmlspecialchars($categoria['nombre']) ?>

                    </option>

                <?php endwhile; ?>

            </select>

        </div>


        <!-- DATOS DE LA VARIANTE -->

        <div class="fila">

            <div class="campo">

                <label for="variante_nombre">
                    Nombre de la variante
                </label>

                <input
                    type="text"
                    id="variante_nombre"
                    name="variante_nombre"
                    placeholder="Ejemplo: Dorado"
                    required
                >

            </div>


            <div class="campo">

                <label for="sku">
                    SKU
                </label>

                <input
                    type="text"
                    id="sku"
                    name="sku"
                    placeholder="Ejemplo: SKU-021"
                    required
                >

            </div>

        </div>


        <!-- PRECIO Y STOCK -->

        <div class="fila">

            <div class="campo">

                <label for="precio">
                    Precio (S/)
                </label>

                <input
                    type="number"
                    id="precio"
                    name="precio"
                    step="0.01"
                    min="0"
                    placeholder="99.00"
                    required
                >

            </div>


            <div class="campo">

                <label for="stock">
                    Stock
                </label>

                <input
                    type="number"
                    id="stock"
                    name="stock"
                    min="0"
                    placeholder="10"
                    required
                >

            </div>

        </div>


        <!-- MATERIAL Y TALLA -->

        <div class="fila">

            <div class="campo">

                <label for="material">
                    Material
                </label>

                <input
                    type="text"
                    id="material"
                    name="material"
                    placeholder="Ejemplo: Acero"
                >

            </div>


            <div class="campo">

                <label for="talla">
                    Talla
                </label>

                <input
                    type="text"
                    id="talla"
                    name="talla"
                    placeholder="Ejemplo: Única"
                >

            </div>

        </div>


        <!-- COLOR -->

        <div class="campo">

            <label for="color">
                Color
            </label>

            <input
                type="text"
                id="color"
                name="color"
                placeholder="Ejemplo: Dorado"
            >

        </div>


        <!-- IMÁGENES -->

        <div class="campo">

            <label for="imagenes">
                Imágenes del producto
            </label>

            <input
                type="file"
                id="imagenes"
                name="imagenes[]"
                accept="image/*"
                multiple
            >

        </div>


        <!-- BOTONES -->

        <div class="botones">

            <button
                type="submit"
                class="btn-guardar"
            >
                💾 Guardar producto
            </button>

            <a
                href="productos.php"
                class="btn-cancelar"
            >
                Cancelar
            </a>

        </div>

    </form>

</div>
```

</div>

</body>

</html>
