<?php

require_once "../includes/conexion.php";
require_once "../includes/sesion.php";

// Verificar sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

// Verificar que sea administrador
$usuarioId = $_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$resultadoUsuario = $stmtUsuario->get_result();
$usuario = $resultadoUsuario->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso no autorizado.");
}


// Verificar que el formulario fue enviado
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: preguntas.php");
    exit;
}


// Obtener datos del formulario
$pregunta = trim($_POST['pregunta'] ?? '');
$respuesta = trim($_POST['respuesta'] ?? '');


// Validar
if ($pregunta === '' || $respuesta === '') {
    die("La pregunta y la respuesta son obligatorias.");
}


// Guardar en la base de datos
$stmt = $conn->prepare("
    INSERT INTO preguntas_frecuentes
    (pregunta, respuesta, activo)
    VALUES (?, ?, 1)
");

$stmt->bind_param(
    "ss",
    $pregunta,
    $respuesta
);


if (!$stmt->execute()) {
    die("Error al guardar la pregunta: " . $stmt->error);
}


// Volver al listado
header("Location: preguntas.php?guardado=1");
exit;