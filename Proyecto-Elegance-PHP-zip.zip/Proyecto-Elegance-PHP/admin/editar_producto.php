<?php

require_once "../includes/sesion.php";
require_once "../includes/conexion.php";

// ==========================================
// VERIFICAR SESIÓN
// ==========================================

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../auth/login.php");
    exit;
}

// ==========================================
// VERIFICAR ADMIN
// ==========================================

$usuarioId = (int)$_SESSION['usuario_id'];

$stmtUsuario = $conn->prepare("
    SELECT nombre, email, rol
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmtUsuario->bind_param("i", $usuarioId);
$stmtUsuario->execute();

$usuario = $stmtUsuario->get_result()->fetch_assoc();

if (!$usuario || $usuario['rol'] !== 'admin') {
    die("Acceso denegado.");
}

// ==========================================
// OBTENER ID DE VARIANTE
// ==========================================

$varianteId = (int)($_GET['id'] ?? $_POST['variante_id'] ?? 0);

if ($varianteId <= 0) {
    die("Producto no válido.");
}

// ==========================================
// ACTUALIZAR PRODUCTO
// ==========================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');

    $sku = trim($_POST['sku'] ?? '');
    $varianteNombre = trim($_POST['variante_nombre'] ?? '');

    $material = trim($_POST['material'] ?? '');
    $talla = trim($_POST['talla'] ?? '');
    $color = trim($_POST['color'] ?? '');

    $precio = (float)($_POST['precio'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);

    $categoriaId = (int)($_POST['categoria_id'] ?? 0);


    // ======================================
    // OBTENER PRODUCTO RELACIONADO
    // ======================================

    $stmtProductoId = $conn->prepare("
        SELECT producto_id
        FROM variantes
        WHERE id = ?
        LIMIT 1
    ");

    $stmtProductoId->bind_param("i", $varianteId);
    $stmtProductoId->execute();

    $datoProducto = $stmtProductoId
        ->get_result()
        ->fetch_assoc();

    if (!$datoProducto) {
        die("La variante no existe.");
    }

    $productoId = (int)$datoProducto['producto_id'];


    // ======================================
    // VALIDAR DATOS
    // ======================================

    if (
        $nombre === '' ||
        $varianteNombre === '' ||
        $sku === '' ||
        $precio < 0 ||
        $stock < 0 ||
        $categoriaId <= 0
    ) {
        die("Completa correctamente los campos obligatorios.");
    }


    // ======================================
    // VERIFICAR SKU
    // ======================================

    $stmtSku = $conn->prepare("
        SELECT id
        FROM variantes
        WHERE sku = ?
        AND id <> ?
        LIMIT 1
    ");

    $stmtSku->bind_param(
        "si",
        $sku,
        $varianteId
    );

    $stmtSku->execute();

    $skuExistente = $stmtSku
        ->get_result()
        ->fetch_assoc();

    if ($skuExistente) {
        die("El SKU ya está utilizado por otro producto.");
    }


    // ======================================
    // INICIAR TRANSACCIÓN
    // ======================================

    $conn->begin_transaction();

    try {

        // ==================================
        // ACTUALIZAR PRODUCTO
        // ==================================

        $stmtProducto = $conn->prepare("
            UPDATE productos
            SET
                categoria_id = ?,
                nombre = ?,
                descripcion = ?
            WHERE id = ?
        ");

        $stmtProducto->bind_param(
            "issi",
            $categoriaId,
            $nombre,
            $descripcion,
            $productoId
        );

        if (!$stmtProducto->execute()) {
            throw new Exception(
                "No se pudo actualizar el producto."
            );
        }


        // ==================================
        // ACTUALIZAR VARIANTE
        // ==================================

       $stmtVariante = $conn->prepare("
    UPDATE variantes
    SET
        nombre = ?,
        sku = ?,
        material = ?,
        talla = ?,
        color = ?,
        precio = ?,
        stock = ?
    WHERE id = ?
");

       $stmtVariante->bind_param(
       "sssssdii",
        $varianteNombre,
        $sku,
        $material,
        $talla,
        $color,
        $precio,
        $stock,
        $varianteId
);
        if (!$stmtVariante->execute()) {
            throw new Exception(
                "No se pudo actualizar la variante."
            );
        }


        // ==================================
        // CONFIRMAR
        // ==================================

        $conn->commit();


        header(
            "Location: editar_producto.php?id=" .
            $varianteId .
            "&actualizado=1"
        );

        exit;

    } catch (Exception $e) {

        $conn->rollback();

        die(
            "Error al actualizar: " .
            htmlspecialchars($e->getMessage())
        );
    }
}


// ==========================================
// OBTENER DATOS DEL PRODUCTO
// ==========================================

$stmt = $conn->prepare("
    SELECT
        p.id AS producto_id,
        p.nombre AS producto_nombre,
        p.descripcion,
        p.categoria_id,

        v.id AS variante_id,
        v.nombre AS variante_nombre,
        v.sku,
        v.material,
        v.talla,
        v.color,
        v.precio,
        v.stock,
        v.activo

    FROM variantes v

    INNER JOIN productos p
        ON p.id = v.producto_id

    WHERE v.id = ?

    LIMIT 1
");

$stmt->bind_param("i", $varianteId);
$stmt->execute();

$producto = $stmt->get_result()->fetch_assoc();

if (!$producto) {
    die("Producto no encontrado.");
}


// ==========================================
// OBTENER CATEGORÍAS
// ==========================================

$categorias = $conn->query("
    SELECT id, nombre
    FROM categorias
    ORDER BY nombre ASC
");

?>

<!DOCTYPE html>

<html lang="es">

<head>


<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Editar producto | Elegance Admin</title>

<style>

    body {
        font-family: Arial, sans-serif;
        background: #f7f3f5;
        margin: 0;
        padding: 30px;
        color: #333;
    }

    .contenedor {
        max-width: 850px;
        margin: auto;
    }

    .volver {
        display: inline-block;
        margin-bottom: 20px;
        color: #7d5260;
        text-decoration: none;
        font-weight: bold;
    }

    h1 {
        color: #7d5260;
        margin-bottom: 25px;
    }

    .tarjeta {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 3px 12px rgba(0,0,0,0.08);
    }

    .mensaje {
        background: #dff3e4;
        color: #246b3c;
        padding: 12px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .campo {
        margin-bottom: 18px;
    }

    label {
        display: block;
        margin-bottom: 7px;
        font-weight: bold;
        color: #555;
    }

    input,
    textarea,
    select {
        width: 100%;
        box-sizing: border-box;
        padding: 11px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 15px;
    }

    textarea {
        min-height: 100px;
        resize: vertical;
    }

    .fila {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
    }

    .botones {
        display: flex;
        gap: 10px;
        margin-top: 25px;
    }

    .btn-guardar {
        border: none;
        background: #7d5260;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 15px;
    }

    .btn-cancelar {
        background: #777;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        text-decoration: none;
    }

    .btn-guardar:hover,
    .btn-cancelar:hover {
        opacity: 0.9;
    }

    @media (max-width: 700px) {

        .fila {
            grid-template-columns: 1fr;
        }

    }

</style>


</head>

<body>

<div class="contenedor">

<a
    class="volver"
    href="productos.php"
>
    ← Volver a productos
</a>


<h1>
    ✏️ Editar producto
</h1>


<?php if (isset($_GET['actualizado'])): ?>

    <div class="mensaje">
        Producto actualizado correctamente.
    </div>

<?php endif; ?>


<div class="tarjeta">

    <form
        method="POST"
        action="editar_producto.php?id=<?= $varianteId ?>"
    >

        <input
            type="hidden"
            name="variante_id"
            value="<?= $varianteId ?>"
        >


        <!-- NOMBRE -->

        <div class="campo">

            <label for="nombre">
                Nombre del producto
            </label>

            <input
                type="text"
                id="nombre"
                name="nombre"
                value="<?= htmlspecialchars($producto['producto_nombre']) ?>"
                required
            >

        </div>


        <!-- DESCRIPCIÓN -->

        <div class="campo">

            <label for="descripcion">
                Descripción
            </label>

            <textarea
                id="descripcion"
                name="descripcion"
            ><?= htmlspecialchars($producto['descripcion'] ?? '') ?></textarea>

        </div>


        <!-- CATEGORÍA -->

        <div class="campo">

            <label for="categoria_id">
                Categoría
            </label>

            <select
                id="categoria_id"
                name="categoria_id"
                required
            >

                <?php while ($categoria = $categorias->fetch_assoc()): ?>

                    <option
                        value="<?= (int)$categoria['id'] ?>"
                        <?= ((int)$categoria['id'] === (int)$producto['categoria_id']) ? 'selected' : '' ?>
                    >
                        <?= htmlspecialchars($categoria['nombre']) ?>
                    </option>

                <?php endwhile; ?>

            </select>

        </div>


        <!-- VARIANTE Y SKU -->

        <div class="fila">

            <div class="campo">

                <label for="variante_nombre">
                    Nombre de la variante
                </label>

                <input
                    type="text"
                    id="variante_nombre"
                    name="variante_nombre"
                    value="<?= htmlspecialchars($producto['variante_nombre']) ?>"
                    required
                >

            </div>


            <div class="campo">

                <label for="sku">
                    SKU
                </label>

                <input
                    type="text"
                    id="sku"
                    name="sku"
                    value="<?= htmlspecialchars($producto['sku']) ?>"
                    required
                >

            </div>

        </div>


        <!-- PRECIO Y STOCK -->

        <div class="fila">

            <div class="campo">

                <label for="precio">
                    Precio (S/)
                </label>

                <input
                    type="number"
                    id="precio"
                    name="precio"
                    step="0.01"
                    min="0"
                    value="<?= htmlspecialchars($producto['precio']) ?>"
                    required
                >

            </div>


            <div class="campo">

                <label for="stock">
                    Stock
                </label>

                <input
                    type="number"
                    id="stock"
                    name="stock"
                    min="0"
                    value="<?= htmlspecialchars($producto['stock']) ?>"
                    required
                >

            </div>

        </div>


        <!-- MATERIAL Y TALLA -->

        <div class="fila">

            <div class="campo">

                <label for="material">
                    Material
                </label>

                <input
                    type="text"
                    id="material"
                    name="material"
                    value="<?= htmlspecialchars($producto['material'] ?? '') ?>"
                >

            </div>


            <div class="campo">

                <label for="talla">
                    Talla
                </label>

                <input
                    type="text"
                    id="talla"
                    name="talla"
                    value="<?= htmlspecialchars($producto['talla'] ?? '') ?>"
                >

            </div>

        </div>


        <!-- COLOR -->

        <div class="campo">

            <label for="color">
                Color
            </label>

            <input
                type="text"
                id="color"
                name="color"
                value="<?= htmlspecialchars($producto['color'] ?? '') ?>"
            >

        </div>


        <!-- BOTONES -->

        <div class="botones">

            <button
                type="submit"
                class="btn-guardar"
            >
                💾 Guardar cambios
            </button>

            <a
                href="productos.php"
                class="btn-cancelar"
            >
                Cancelar
            </a>

        </div>

    </form>

</div>


</div>

</body>

</html>
