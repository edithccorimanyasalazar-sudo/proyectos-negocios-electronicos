const express = require('express');
const pool = require('../db');

const router = express.Router();

router.post('/', async (req, res) => {
  const { cliente, items, metodo_pago } = req.body;

  if (!cliente?.nombre || !cliente?.telefono) {
    return res.status(400).json({
      mensaje: 'Debes enviar nombre y teléfono del cliente.'
    });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({
      mensaje: 'El carrito está vacío.'
    });
  }

  const metodosPermitidos = [
    'yape',
    'plin',
    'transferencia',
    'tarjeta_simulada',
    'contraentrega'
  ];

  if (!metodosPermitidos.includes(metodo_pago)) {
    return res.status(400).json({
      mensaje: 'El método de pago no es válido.'
    });
  }

  const itemsAgrupados = new Map();

  for (const item of items) {
    const varianteId = Number(item.variante_id);
    const cantidad = Number(item.cantidad);

    if (!Number.isInteger(varianteId) ||
        !Number.isInteger(cantidad) ||
        cantidad <= 0) {
      return res.status(400).json({
        mensaje: 'Una variante o cantidad es inválida.'
      });
    }

    const anterior = itemsAgrupados.get(varianteId) || 0;

    itemsAgrupados.set(varianteId, anterior + cantidad);
  }

  const conexion = await pool.getConnection();

  try {
    await conexion.beginTransaction();

    const [clientesEncontrados] = await conexion.query(`
      SELECT id
      FROM clientes
      WHERE telefono = ?
      LIMIT 1
      FOR UPDATE
    `, [cliente.telefono]);

    let clienteId;

    if (clientesEncontrados.length) {
      clienteId = clientesEncontrados[0].id;

      await conexion.query(`
        UPDATE clientes
        SET nombre = ?,
            email = ?,
            direccion = ?
        WHERE id = ?
      `, [
        cliente.nombre,
        cliente.email || null,
        cliente.direccion || null,
        clienteId
      ]);
    } else {
      const [clienteCreado] = await conexion.query(`
        INSERT INTO clientes (
          nombre,
          email,
          telefono,
          direccion
        )
        VALUES (?, ?, ?, ?)
      `, [
        cliente.nombre,
        cliente.email || null,
        cliente.telefono,
        cliente.direccion || null
      ]);

      clienteId = clienteCreado.insertId;
    }

    let subtotal = 0;
    const detallePedido = [];

    for (const [varianteId, cantidad] of itemsAgrupados) {
      const [variantes] = await conexion.query(`
        SELECT
          v.id,
          v.nombre AS nombre_variante,
          v.precio,
          v.stock,
          p.nombre AS nombre_producto
        FROM variantes v
        JOIN productos p ON p.id = v.producto_id
        WHERE v.id = ?
          AND v.activo = TRUE
          AND p.activo = TRUE
        FOR UPDATE
      `, [varianteId]);

      if (!variantes.length) {
        throw new Error('La variante seleccionada no existe.');
      }

      const variante = variantes[0];

      if (variante.stock < cantidad) {
        throw new Error(
          `No hay stock suficiente para ${variante.nombre_producto}.`
        );
      }

      const precio = Number(variante.precio);
      const subtotalLinea = precio * cantidad;

      subtotal += subtotalLinea;

      detallePedido.push({
        varianteId,
        nombreProducto: variante.nombre_producto,
        nombreVariante: variante.nombre_variante,
        precio,
        cantidad,
        subtotal: subtotalLinea
      });
    }

    const costoEnvio = subtotal >= 300 ? 0 : 15;
    const total = subtotal + costoEnvio;
    const codigo = `PED-${Date.now()}`;

    const [pedidoCreado] = await conexion.query(`
      INSERT INTO pedidos (
        cliente_id,
        codigo,
        direccion_entrega,
        subtotal,
        costo_envio,
        total,
        estado
      )
      VALUES (?, ?, ?, ?, ?, ?, 'pendiente')
    `, [
      clienteId,
      codigo,
      cliente.direccion || null,
      subtotal,
      costoEnvio,
      total
    ]);

    const pedidoId = pedidoCreado.insertId;

    for (const linea of detallePedido) {
      await conexion.query(`
        INSERT INTO detalle_pedido (
          pedido_id,
          variante_id,
          nombre_producto,
          nombre_variante,
          precio_unitario,
          cantidad,
          subtotal
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [
        pedidoId,
        linea.varianteId,
        linea.nombreProducto,
        linea.nombreVariante,
        linea.precio,
        linea.cantidad,
        linea.subtotal
      ]);

      await conexion.query(`
        UPDATE variantes
        SET stock = stock - ?
        WHERE id = ?
      `, [linea.cantidad, linea.varianteId]);
    }

    const [pagoCreado] = await conexion.query(`
      INSERT INTO pagos (
        pedido_id,
        metodo,
        monto,
        estado
      )
      VALUES (?, ?, ?, 'pendiente')
    `, [
      pedidoId,
      metodo_pago,
      total
    ]);

    await conexion.commit();

    res.status(201).json({
      mensaje: 'Pedido creado correctamente.',
      pedido: {
        id: pedidoId,
        codigo,
        subtotal,
        costo_envio: costoEnvio,
        total,
        estado: 'pendiente'
      },
      pago: {
        id: pagoCreado.insertId,
        estado: 'pendiente'
      }
    });
  } catch (error) {
    await conexion.rollback();

    console.error(error);

    res.status(400).json({
      mensaje: error.message || 'No se pudo crear el pedido.'
    });
  } finally {
    conexion.release();
  }
});

module.exports = router;