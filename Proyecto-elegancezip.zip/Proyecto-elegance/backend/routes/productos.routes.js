const express = require('express');
const pool = require('../db');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const [filas] = await pool.query(`
      SELECT
        p.id AS producto_id,
        p.nombre AS producto,
        p.descripcion,
        c.nombre AS categoria,

        v.id AS variante_id,
        v.nombre AS variante,
        v.material,
        v.talla,
        v.color,
        v.precio,
        v.stock,

        GROUP_CONCAT(
          DISTINCT pi.url
          ORDER BY pi.orden
          SEPARATOR '|'
        ) AS imagenes

      FROM productos p
      JOIN categorias c ON c.id = p.categoria_id
      JOIN variantes v ON v.producto_id = p.id
      LEFT JOIN producto_imagenes pi ON pi.producto_id = p.id

      WHERE p.activo = TRUE
        AND v.activo = TRUE

      GROUP BY
        p.id, p.nombre, p.descripcion, c.nombre,
        v.id, v.nombre, v.material,
        v.talla, v.color, v.precio, v.stock

      ORDER BY p.id, v.id
    `);

    const productos = [];

    filas.forEach(fila => {
      let producto = productos.find(
        item => item.id === fila.producto_id
      );

      if (!producto) {
        producto = {
          id: fila.producto_id,
          cat: fila.categoria.toLowerCase(),
          name: fila.producto,
          price: Number(fila.precio),
          images: fila.imagenes
            ? fila.imagenes.split('|')
            : [],
          variants: []
        };

        productos.push(producto);
      }

      producto.variants.push({
        id: fila.variante_id,
        title: fila.variante,
        medida: fila.talla || '',
        material: fila.material || '',
        colors: fila.color
          ? fila.color.split(',').map(color => color.trim())
          : [],
        price: Number(fila.precio),
        stock: fila.stock
      });
    });

    res.json(productos);
  } catch (error) {
    console.error(error);

    res.status(500).json({
      mensaje: 'No se pudieron obtener los productos.'
    });
  }
});

module.exports = router;