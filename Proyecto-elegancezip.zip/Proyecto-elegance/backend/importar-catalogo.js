const fs = require('fs');
const path = require('path');
const vm = require('vm');
const pool = require('./db');

function obtenerCatalogoDesdeScript() {
  const rutaScript = path.join(__dirname, '..', 'script.js');
  const codigo = fs.readFileSync(rutaScript, 'utf8');

  const inicio = codigo.indexOf('const RUTA_IMG');
  const fin = codigo.indexOf('const CATEGORIAS');

  if (inicio === -1 || fin === -1) {
    throw new Error(
      'No se encontró el catálogo dentro de script.js.'
    );
  }

  let bloqueCatalogo = codigo.slice(inicio, fin);

  bloqueCatalogo = bloqueCatalogo.replace(
    /const\s+PRODUCTS(?:_LOCAL)?\s*=/,
    'globalThis.CATALOGO ='
  );

  const contexto = {};
  vm.createContext(contexto);
  vm.runInContext(bloqueCatalogo, contexto);

  if (!Array.isArray(contexto.CATALOGO)) {
    throw new Error(
      'No se pudo leer el arreglo de productos.'
    );
  }

  return contexto.CATALOGO;
}

const nombresCategorias = {
  collares: 'Collares',
  aretes: 'Aretes',
  anillos: 'Anillos',
  pulseras: 'Pulseras'
};

async function importarCatalogo() {
  const catalogo = obtenerCatalogoDesdeScript();
  const conexion = await pool.getConnection();

  try {
    await conexion.beginTransaction();

    for (const producto of catalogo) {
      const categoria = nombresCategorias[producto.cat];

      const [categorias] = await conexion.query(
        'SELECT id FROM categorias WHERE nombre = ?',
        [categoria]
      );

      if (!categorias.length) {
        throw new Error(
          `No existe la categoría: ${categoria}`
        );
      }

      const categoriaId = categorias[0].id;

      const [productosExistentes] = await conexion.query(
        'SELECT id FROM productos WHERE nombre = ?',
        [producto.name]
      );

      let productoId;

      if (productosExistentes.length) {
        productoId = productosExistentes[0].id;
      } else {
        const [productoCreado] = await conexion.query(`
          INSERT INTO productos (
            categoria_id,
            nombre,
            descripcion
          )
          VALUES (?, ?, ?)
        `, [
          categoriaId,
          producto.name,
          'Producto del catálogo Joyería Elegance.'
        ]);

        productoId = productoCreado.insertId;
      }

      for (let indice = 0; indice < producto.variants.length; indice++) {
        const variante = producto.variants[indice];

        const sku =
          `ELEG-${String(producto.id).padStart(3, '0')}` +
          `-${String(indice + 1).padStart(2, '0')}`;

        const [varianteExistente] = await conexion.query(
          'SELECT id FROM variantes WHERE sku = ?',
          [sku]
        );

        if (!varianteExistente.length) {
          await conexion.query(`
            INSERT INTO variantes (
              producto_id,
              nombre,
              sku,
              material,
              talla,
              color,
              precio,
              stock
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            productoId,
            variante.title,
            sku,
            variante.material,
            variante.medida,
            variante.colors.join(', '),
            producto.price,
            10
          ]);
        }
      }

      for (let indice = 0; indice < producto.images.length; indice++) {
        const rutaImagen = producto.images[indice]
          .replace('../', '');

        const [imagenExistente] = await conexion.query(`
          SELECT id
          FROM producto_imagenes
          WHERE producto_id = ?
            AND url = ?
        `, [productoId, rutaImagen]);

        if (!imagenExistente.length) {
          await conexion.query(`
            INSERT INTO producto_imagenes (
              producto_id,
              url,
              orden
            )
            VALUES (?, ?, ?)
          `, [
            productoId,
            rutaImagen,
            indice + 1
          ]);
        }
      }

      console.log(`Importado: ${producto.name}`);
    }

    await conexion.commit();

    console.log(
      `\nImportación terminada: ${catalogo.length} productos.`
    );
  } catch (error) {
    await conexion.rollback();
    console.error('\nError durante la importación:', error.message);
  } finally {
    conexion.release();
    await pool.end();
  }
}

importarCatalogo();