const express = require('express');
const cors = require('cors');
const pool = require('./db');
const productosRoutes = require('./routes/productos.routes');
const pedidosRoutes = require('./routes/pedidos.routes');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/salud', async (req, res) => {
  try {
    const [resultado] = await pool.query('SELECT 1 AS conexion');

    res.json({
      mensaje: 'Backend conectado correctamente a MySQL',
      baseDeDatos: process.env.DB_NAME,
      conexion: resultado[0].conexion
    });
  } catch (error) {
    res.status(500).json({
      mensaje: 'No se pudo conectar a MySQL.'
    });
  }
});

app.use('/api/productos', productosRoutes);
app.use('/api/pedidos', pedidosRoutes);

app.listen(process.env.PORT || 3000, () => {
  console.log(
    `Servidor activo en http://localhost:${process.env.PORT || 3000}`
  );
});